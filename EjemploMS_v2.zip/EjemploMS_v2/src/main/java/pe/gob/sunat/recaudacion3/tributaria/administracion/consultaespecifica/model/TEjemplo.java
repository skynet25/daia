package pe.gob.sunat.recaudacion3.tributaria.administracion.consultaespecifica.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.Setter;


@Entity
@Table(name = "t_ejemplo")
@XmlRootElement
/*ClaseEntidad*/
@Getter
@Setter
public class TEjemplo  {
    private static final long serialVersionUID = 1L;
    @Id
    //@GeneratedValue(strategy=GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "nombre")
    private String nombre;
    @Column(name = "apellido")
    private String apellido;
    @Column(name = "ind_del")
    private Character indDel;
    
}
