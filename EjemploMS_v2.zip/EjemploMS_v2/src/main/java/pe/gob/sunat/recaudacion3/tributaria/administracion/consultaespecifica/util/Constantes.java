package pe.gob.sunat.recaudacion3.tributaria.administracion.consultaespecifica.util;

/**
 * @author 
 * @clase: Constantes.java
 * @descripcion Clase que obtiene los valores utilitarios en las clases
 * @author_company: SUNAT
 * @fecha_de_creacion: 12-10-2016.
 * @version 1.0
 */
public class Constantes {
	public static final String CODIGO_IDF0="0";
	public static final String MENSAJE_IDF0="Datos Recuperados correctamente";
	public static final String CODIGO_IDF1="1";
	public static final String MENSAJE_IDF1="Los datos esperados son nulos o vacios";
	public static final String CODIGO_IDF2="2";
	public static final String MENSAJE_IDF2="No existe informacion en la tabla {0}";
	static final String FORM_FECHA_DIA_MES_ANIO_GUI = "dd-MM-yyyy";

	public static final String CODIGO_IDT1="-1";
	public static final String MENSAJE_IDT1="Ocurrio un error al obtener informacion de la tabla {0}";
	public static final String CODIGO_IDT2="-2";
	public static final String MENSAJE_IDT2="Ocurrio un error generico";
	
	public static final String NOMBRE_T7798MEDPAGPASARE="T7798MEDPAGPASARE";
	public static final String NOMBRE_T7799ENTFINMEDPAG="T7799ENTFINMEDPAG";
	public static final String NOMBRE_T7814ENTIDADFINAN="T7814ENTIDADFINAN";
	public static final String NOMBRE_T7815HORATENENTFIN="T7815HORATENENTFIN";
	
}

