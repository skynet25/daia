package pe.gob.sunat.recaudacion3.tributaria.administracion.consultaespecifica.service;

import java.util.List;

import pe.gob.sunat.framework.plataformaunica.recauda.model.Ddp;


public interface EjemploMSService {

  public List<Ddp> getContribuyentesXTipo(String codTipo);

public Ddp obtenerContribuyenteXRuc(String numRuc);


}