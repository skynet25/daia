package pe.gob.sunat.recaudacion3.tributaria.administracion.consultaespecifica.main.config;

import pe.gob.sunat.framework.plataformaunica.config.EntityManagerInitializer;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Named;
import javax.persistence.EntityManager;

import static pe.gob.sunat.framework.plataformaunica.config.EntityManagerInitializer.*;

/**
 * Created by domix on 12/6/16.
 */
public class EntityManagerInit {
  @Produces
  @Named(EMRECAUDA)
  @RequestScoped
  public EntityManager getEMRecauda() {
    return EntityManagerInitializer.getEMRecauda();
  }

}
