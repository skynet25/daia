package pe.gob.sunat.recaudacion3.tributaria.administracion.consultaespecifica.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RespuestaBean{

	private String codRespuesta;
	private String desRespuesta;
	private int CodGenerado;

}