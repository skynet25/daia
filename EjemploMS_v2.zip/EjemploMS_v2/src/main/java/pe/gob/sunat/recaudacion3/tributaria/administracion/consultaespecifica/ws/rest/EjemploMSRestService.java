package pe.gob.sunat.recaudacion3.tributaria.administracion.consultaespecifica.ws.rest;


import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
//import static javax.ws.rs.core.Response.created;
import static javax.ws.rs.core.Response.ok;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.recaudacion3.tributaria.administracion.consultaespecifica.service.EjemploMSService;


@Slf4j
@Path(EjemploMSRestService.INTEGRADOR_PATH)
@Produces(value = APPLICATION_JSON)
public class EjemploMSRestService {
	@Context
	private UriInfo uriInfo;

	@Inject
	private EjemploMSService ejemploService;
	
	
	public static final String INTEGRADOR_PATH = "/v1/recaudacion/tributaria";


	
	@GET
	@Path("/formulario/t/consulta/contribuyentes")
	@Produces({ MediaType.APPLICATION_JSON})
	public Response listaContribuyentesXTipo(@Context HttpHeaders headers, @PathParam("codtipo") String codTipo) {

		 return ok(ejemploService.getContribuyentesXTipo(codTipo)).build();
		
	 }
	
	@GET
	@Path("/formulario/t/consulta/contribuyente/{numruc}")
	@Produces({ MediaType.APPLICATION_JSON})
	public Response obtenerContribuyenteXRuc(@Context HttpHeaders headers, @PathParam("numruc") String numRuc) {

		 return ok(ejemploService.obtenerContribuyenteXRuc(numRuc)).build();
		
	 }



}
