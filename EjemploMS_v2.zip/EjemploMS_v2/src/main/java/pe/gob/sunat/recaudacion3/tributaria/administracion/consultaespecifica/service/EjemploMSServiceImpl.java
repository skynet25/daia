package pe.gob.sunat.recaudacion3.tributaria.administracion.consultaespecifica.service;

import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.framework.plataformaunica.config.PersistenceConfig;
import pe.gob.sunat.framework.plataformaunica.recauda.model.Ddp;
import pe.gob.sunat.framework.plataformaunica.recauda.model.dao.DdpDAO;
import pe.gob.sunat.recaudacion3.tributaria.administracion.consultaespecifica.service.EjemploMSService;

import javax.inject.Inject;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;
import javax.transaction.Transactional;
import java.util.List;

@Slf4j
@Transactional
public class EjemploMSServiceImpl implements EjemploMSService{
  @Inject
  private DdpDAO ddpDAO;

  @Inject
  private PersistenceConfig persistenceConfig;


  @SuppressWarnings("unchecked")
  
  public List<Ddp> getContribuyentesXTipo(String codTipo) {
	  
		
	Query query = ddpDAO.createNamedQuery("Ddp.findByDdpTpoemp");
	query.setParameter("ddpTpoemp", codTipo);
	
	List<Ddp> lstEjemplo = null;
	
	 try {
		 lstEjemplo = (List<Ddp>) query.getResultList();
   } catch (NoResultException nre) {
       // Code for handling NoResultException
	   lstEjemplo = null;
   } catch (NonUniqueResultException nure) {
       // Code for handling NonUniqueResultException
	   lstEjemplo = null;
   }

    return lstEjemplo;
  }


@Override
public Ddp obtenerContribuyenteXRuc(String numRuc) {
	// TODO Auto-generated method stub
		
	Query query = ddpDAO.createNamedQuery("Ddp.findByDdpNumruc");
	query.setParameter("ddpNumruc", numRuc);
	
	Ddp contribuyente = null;
	
	 try {
		 contribuyente = (Ddp) query.getSingleResult();
     } catch (NoResultException nre) {
         // Code for handling NoResultException
    	 contribuyente = null;
     } catch (NonUniqueResultException nure) {
         // Code for handling NonUniqueResultException
    	 contribuyente = null;
     }

	 return contribuyente;
}



}