package pe.gob.sunat.recaudacion3.tributaria.administracion.consultaespecifica.util;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;
import java.net.URI;

public class UriHelper {

  public static URI getUriForId(@Context UriInfo uriInfo, Integer id) {
    UriBuilder builder = uriInfo.getAbsolutePathBuilder();
    builder.path(Integer.toString(id));
    return builder.build();
  }

  public static URI getUriForId(@Context UriInfo uriInfo, String id) {
    UriBuilder builder = uriInfo.getAbsolutePathBuilder();
    builder.path(id);
    return builder.build();
  }
}
