package pe.gob.sunat.recaudacion3.tributaria.administracion.consultaespecifica.main;

import java.util.EnumSet;

import javax.servlet.DispatcherType;

import io.dropwizard.setup.Environment;
import pe.gob.sunat.framework.plataformaunica.SunatApplication;
import pe.gob.sunat.framework.plataformaunica.config.PersistenceConfig;
import pe.gob.sunat.framework.plataformaunica.exception.GenericExceptionMapper;
import pe.gob.sunat.framework.plataformaunica.exception.ObjectNotFoundExceptionMapper;
import pe.gob.sunat.framework.plataformaunica.exception.ValidationViolationExceptionMapper;
//import pe.gob.sunat.java.filter.servicios.JavaFilter;
import pe.gob.sunat.recaudacion3.tributaria.administracion.consultaespecifica.ws.rest.EjemploMSRestService;

public class EjemploMSApp extends SunatApplication<PersistenceConfig> {

  @Override
  public void onRun(PersistenceConfig myConfig, Environment environment) throws Exception {
    environment.jersey().register(EjemploMSRestService.class);
	environment.jersey().register(ValidationViolationExceptionMapper.class);
    environment.jersey().register(ObjectNotFoundExceptionMapper.class);
    environment.jersey().register(GenericExceptionMapper.class);
    
	//environment.servlets().addFilter("JavaFilter", new JavaFilter()).addMappingForUrlPatterns(EnumSet.of(DispatcherType.REQUEST), true, "/*");
    
    
  }

  public static void main(String... params) throws Exception {
    new EjemploMSApp().run(params);
  }

}


