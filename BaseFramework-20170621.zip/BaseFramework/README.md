# Framework aplicativo para desarrollo de Microservicios en COSAPI/SUNAT

[![Build Status](http://civ.cosapidata.com.pe/buildStatus/icon?job=BaseFramework/master)](http://civ.cosapidata.com.pe/job/BaseFramework/job/master/)

## Generalidades

Framework aplicativo para desarrollo del proyecto de `Plataforma Única de SUNAT`.

### Requerimientos Técnicos y no funcionales

* Java 8
* JAX-RX para desarrollo de APIs REST
* Jackson para procesamiento de JSON
* JPA para persistencia
* CDI para inyección de dependencias y servicios de IoC
* Jetty como servidor de HTTP
* Manejo de transacciones ACID
* Tolerancia a la caída de sistemas de terceros (Resiliencia)
* Comunicación asíncrona
* Mecanismo de verificación de salud del servicio (keepAlive)
* Reporte de métricas de estado de la JVM y Maquina Virtual, SO.


### Principios de desarrollo

Los principios de desarrollo se buscan para elegir un framework moderno, maduro y robusto deben cumplir con:

* Facilidad de integración
* Esfuerzo minimo para ser usado por el equipo de desarrollo
* Basado en estandares Java


## Propuesta de Framework

La siguiente propuesta tiene como intención abarcar en mayor medida un conjunto de herramientas que permitan cumplir con los requerimientos antes mencionados. Cabe mencionar que dado el tiempo asignado a la elaboración de esta propuesta, se tiene una propuesta parcial debido a que falta integrar en la totalidad todas las herramientas necesarias, además de la consideración de que ciertas dependencias (agentes) aún no están definidos al 100%.

### Detalle de requerimientos especificos

1. JAX-RS
2. JPA
3. Transacciones
4. Manejo de Excepciones
5. Bitacora
6. Procesamiento asincrono
7. Tolerancia a caidas de sistemas externos
8. Seguridad
9. Validación
10. Manejo de Cache
11. Servicio de descubrimiento/registro
12. Metricas
13. Reporte de Salud
14. Despliegue
15. Cliente HTTP
16. Bitacora de eventos distribuido y traceable



