package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices

import spock.lang.Specification

/**
 * Created by domix on 1/26/17.
 */
class FooSpec extends Specification {

  def foo() {
    expect:
      true
  }
}
