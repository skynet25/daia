package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception

import spock.lang.Specification

/**
 * Created by domix on 5/4/17.
 */
class GenericExceptionSpec extends Specification {

  def foo() {
    given:
      def exception = new GenericException([key: 'value'])
    expect:
      exception.data
      !exception.codError
  }

  def defaultMessage() {
    def mensaje = 'mensaje'
    given:
      def exception = new GenericException(mensaje)
    expect:
      !exception.data
      !exception.codError
      exception.message == mensaje
  }
}
