package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util;

import lombok.extern.slf4j.Slf4j;

import javax.enterprise.inject.Vetoed;
import java.io.ByteArrayInputStream;

/**
 * @autor: jyauyo [09-2016]
 * @descripción: {Clase utilitaria para el manejo de String.}
 */
@Vetoed
@Slf4j
public class Cadena {

  private Cadena() {
    log.debug("Completamente privado");
  }

  /**
   * Convierte un arreglo de cadenas, a una sola cadena con
   * delimitador.
   *
   * @param data        String[]
   * @param delimitador String
   * @return String
   * @since framework 1.2
   */
  public static String unSplit(String[] data, char delimitador) {
    StringBuilder sbRespuesta = new StringBuilder();
    for (int i = 0; i < data.length; i++) {
      sbRespuesta.append(data[i]).append(delimitador);
    }
    return sbRespuesta.toString();
  }

  /**
   * Indica si el valor de la cadena es un numero
   *
   * @param cadena String
   * @return boolean
   */
  public static boolean isNumeric(String cadena) {
    try {
      new Integer(cadena);
      return true;
    } catch (NumberFormatException e) {
      return false;
    }
  }

  /**
   * Convierte una cadena a un ByteArray
   *
   * @param datos String
   * @return ByteArrayInputStream
   */
  public static ByteArrayInputStream toByteArray(String datos) {
    return toByteArray(datos.getBytes());
  }

  /**
   * Convierte un arreglo de bytes a ByteArray
   *
   * @param datos byte[]
   * @return ByteArrayInputStream
   */
  public static ByteArrayInputStream toByteArray(byte[] datos) {
    return new ByteArrayInputStream(datos);
  }

  /**
   * Convierte un ByteArray a String
   *
   * @param bais ByteArrayInputStream
   * @return String
   */
  public static String getStringFromByteArray(ByteArrayInputStream bais) {
    bais.reset();
    byte[] buf = new byte[bais.available()];
    bais.read(buf, 0, bais.available());
    return new String(buf);
  }

  /**
   * Rellena la cantidad de n de c caracteres a la izquierda de
   * la cadena s.
   *
   * @param s String
   * @param n int
   * @param c char
   * @return String
   * @since util 1.6
   */
  public static String padLeft(String s, int n, char c) {
    return padding(s, n, c, true);
  }

  /**
   * Rellena la cantidad de n de c caracteres a la derecha de
   * la cadena s.
   *
   * @param s String
   * @param n int
   * @param c char
   * @return String
   * @since util 1.6
   */
  public static String padRight(String s, int n, char c) {
    return padding(s, n, c, false);
  }

  /**
   * Completa la cadena con caracteres a la derecha o izquierda segun
   * indique el flag.
   *
   * @param <b>s</b>           <code>String</code>, cadena original.
   * @param <b>n</b>           <code>int</code>, longitud total de la cadena.
   * @param <b>c</b>           <code>char</code>, caracter de relleno.
   * @param <b>paddingLeft</b> <code>boolean</code>, flag que indica si se
   *                           completa a la izquierda o derecha.
   * @return String, cadena resultante.
   * @since util 1.6
   */
  private static String padding(String s, int n, char c, boolean paddingLeft) {
    StringBuilder str = new StringBuilder(s);
    int strLength = str.length();
    if (n > 0 && n > strLength) {
      for (int i = 0; i <= n; i++) {
        if (paddingLeft) {
          if (i < n - strLength)
            str.insert(0, c);
        } else {
          if (i > strLength)
            str.append(c);
        }
      }
    }
    return str.toString();
  }

  public static String replace(String str, String pattern, String replace) {
    int s = 0;
    int e;
    StringBuilder result = new StringBuilder();

    while ((e = str.indexOf(pattern, s)) >= 0) {
      result.append(str.substring(s, e));
      result.append(replace);
      s = e + pattern.length();
    }
    result.append(str.substring(s));
    return result.toString();
  }

  public static int countChar(String text, char caracter) {
    int n = 0;
    char[] textoChar = text.toCharArray();

    for (int p = 0; p < textoChar.length; p++) {
      if (textoChar[p] == caracter)
        n++;
    }

    return n;
  }

  public static boolean validarFormatoEmail(String email) {
    String emailRegex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
    return email.matches(emailRegex);
  }

  public static String removerCharacter(String strCadena, char character) {

    char[] caracter;
    caracter = strCadena.toCharArray();
    int i = 0;
    StringBuilder cadenaFinal = new StringBuilder();
    do {
      if (caracter[i] == character) {
        cadenaFinal = cadenaFinal.append(caracter[i]).append((char) 39);
      } else {
        cadenaFinal = cadenaFinal.append(caracter[i]);
      }
      i++;
    } while (i < caracter.length);

    return cadenaFinal.toString();
  }

}
