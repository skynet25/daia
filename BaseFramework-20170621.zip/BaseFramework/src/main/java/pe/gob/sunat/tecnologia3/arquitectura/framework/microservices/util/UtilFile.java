package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util;

import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.batch.ClaveRC4;

import javax.enterprise.inject.Vetoed;
import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@Vetoed
@Slf4j
public class UtilFile {
  /* Tomado de: "receptorpdt\\trunk\\src\\pe\\gob\\sunat\\recaudacion2\\util"
  *			  ClaveRC4.java
	*/

  private String generaKey(String identificador) {
    return new ClaveRC4().generaKey(identificador);
  }

  /**
   * @autor: BTG [07/09/2016]
   * @descripcion: { Metodo que permite calcular la contrasena a partir del nombre del archivo
   * Se utiliza la clase ClaveRC4, obtenida de aplicativo ReceptorPDT de SUNAT
   * }
   * nroCon: Cadena de texto a ser procesado (para obtener contrasena valida)
   */
  public String getSemilla(String nroCon) {
    String mod11 = generaKey(nroCon.substring(1, 16)).substring(1);
    log.debug("mod11: {}", mod11);
    return nroCon.substring(0, 1) + mod11 +
      nroCon.substring(16, nroCon.length() - 1);
  }

  public String getHash(InputStream contenido) throws NoSuchAlgorithmException, IOException {
    ByteArrayOutputStream buffer = new ByteArrayOutputStream();

    int nRead;
    byte[] data = new byte[1024];

    while ((nRead = contenido.read(data, 0, data.length)) != -1) {
      buffer.write(data, 0, nRead);
    }
    buffer.flush();

    MessageDigest digest = MessageDigest.getInstance("SHA1");
    digest.update(buffer.toString().getBytes());
    byte[] digestBytes = digest.digest();

    return javax.xml.bind.DatatypeConverter.printHexBinary(digestBytes);

  }


  public String readHeaderFromFile(InputStream uploadedInputStream) {
    String dataHeader = "";
    try {
      int read;
      byte[] bytes = new byte[1024];

      while ((read = uploadedInputStream.read(bytes)) != -1) {
        log.debug("Readed {}", read);
        dataHeader = new String(bytes);
        break;
      }
    } catch (IOException e) {
      log.warn("Problemas al leer", e);
    }
    return dataHeader;

  }


  public void writeToFile(InputStream uploadedInputStream, String uploadedFileLocation) {

    try (OutputStream out = new FileOutputStream(new File(uploadedFileLocation))) {
      int read = 0;
      byte[] bytes = new byte[1024];

      while ((read = uploadedInputStream.read(bytes)) != -1) {
        out.write(bytes, 0, read);
      }
    } catch (IOException e) {
      log.warn("Problemas al escribir", e);
    }

  }

  public byte[] getBytesFromInputStream(InputStream is) throws IOException {
    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
    int nRead;
    byte[] data = new byte[1024];
    while ((nRead = is.read(data, 0, data.length)) != -1) {
      buffer.write(data, 0, nRead);
    }

    buffer.flush();
    return buffer.toByteArray();
  }


}