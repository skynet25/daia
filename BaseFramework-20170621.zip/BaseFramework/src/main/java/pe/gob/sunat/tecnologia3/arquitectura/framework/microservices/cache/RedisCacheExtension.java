package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.cache;

import lombok.extern.slf4j.Slf4j;

import javax.cache.CacheManager;
import javax.cache.Caching;
import javax.cache.spi.CachingProvider;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.Vetoed;
import javax.enterprise.inject.spi.*;
import java.util.Properties;

/**
 * Created by domix on 2/24/17.
 */
@Slf4j
@Vetoed
public class RedisCacheExtension implements Extension {
  private static final boolean ACTIVATED = "true".equals(System.getProperty("org.apache.jcs.extra.cdi", "true"));

  private boolean cacheManagerFound = false;
  private boolean cacheProviderFound = false;
  private CacheManager cacheManager;
  private CachingProvider cachingProvider;

  public <A> void processBean(@Observes final ProcessBean<A> processBeanEvent) {
    log.debug("CDI ProcessBean Event {}", processBeanEvent.getBean().getName());
    if (!ACTIVATED) {
      return;
    }

    if (cacheManagerFound && cacheProviderFound) {
      return;
    }

    final Bean<A> bean = processBeanEvent.getBean();
    if (CacheManagerBean.class.isInstance(bean) || CacheProviderBean.class.isInstance(bean)) {
      return;
    }

    if (!cacheManagerFound) {
      cacheManagerFound = bean.getTypes().contains(CacheManager.class);
    }
    if (!cacheProviderFound) {
      cacheProviderFound = bean.getTypes().contains(CachingProvider.class);
    }
    log.debug("cacheManagerFound: {}", cacheManagerFound);
    log.debug("cacheProviderFound: {}", cacheProviderFound);
  }

  public void addRedisBeans(@Observes final AfterBeanDiscovery afterBeanDiscovery) {
    log.debug("CDI AfterBeanDiscovery Event");
    if (!ACTIVATED) {
      return;
    }

    if (cacheManagerFound && cacheProviderFound) {
      return;
    }

    cachingProvider = Caching.getCachingProvider();
    if (!cacheManagerFound) {
      cacheManager = cachingProvider.getCacheManager(
        cachingProvider.getDefaultURI(),
        cachingProvider.getDefaultClassLoader(),
        new Properties());
      afterBeanDiscovery.addBean(new CacheManagerBean(cacheManager));
    }
    if (!cacheProviderFound) {
      afterBeanDiscovery.addBean(new CacheProviderBean(cachingProvider));
    }
  }

  public void destroyIfCreated(@Observes final BeforeShutdown beforeShutdown) {
    log.debug("CDI BeforeShutdown Event");
    if (cacheManager != null) {
      log.debug("About to close CacheManager");
      cacheManager.close();
    }
    if (cachingProvider != null) {
      log.debug("About to close CachingProvider");
      cachingProvider.close();
    }
  }
}
