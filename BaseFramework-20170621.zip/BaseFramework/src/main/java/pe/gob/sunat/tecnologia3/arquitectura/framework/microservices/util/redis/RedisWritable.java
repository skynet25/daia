package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.redis;

import javax.inject.Qualifier;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;

import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Qualifier
@Documented
@Retention(RUNTIME)
public @interface RedisWritable {
}
