package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception;

import lombok.Getter;

/**
 * @author TJPIZARROIP
 *         Class Exception (BD, WS)
 */
@Getter
public class BaseException extends Exception {

  private static final long serialVersionUID = 1L;

  private final String codError;

  public BaseException(String codError, String msjError,
                       Throwable cause) {
    super(msjError, cause);
    this.codError = codError;
  }

  public BaseException(String codError, String msjError) {
    super(msjError);
    this.codError = codError;
  }

  public BaseException(String msjError, Throwable cause) {
    this("", msjError, cause);
  }
  public BaseException(String msjError) {
    this("", msjError);
  }

}
