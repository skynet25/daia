package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.redis;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixCommandKey;
import com.netflix.hystrix.HystrixCommandProperties;
import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.Jedis;
import redis.clients.util.Pool;

import java.util.function.Function;

import static com.netflix.hystrix.HystrixCommandProperties.ExecutionIsolationStrategy.SEMAPHORE;

/**
 * Created by domix on 5/26/17.
 */
@Slf4j
public class RedisWriteOperationCommand<T> extends HystrixCommand<T> {

  private final Pool<Jedis> pool;
  private final Function<Jedis, T> callback;

  public RedisWriteOperationCommand(Pool<Jedis> pool, Function<Jedis, T> callback, Integer timeout, Integer maxConcurrentRequests) {
    super(Setter
      .withGroupKey(HystrixCommandGroupKey.Factory.asKey("RedisCluster"))
      .andCommandKey(HystrixCommandKey.Factory.asKey("RedisOperationCommand"))
      .andCommandPropertiesDefaults(
        HystrixCommandProperties.Setter()
          .withExecutionIsolationStrategy(SEMAPHORE)
          .withExecutionTimeoutInMilliseconds(timeout)
          .withExecutionIsolationSemaphoreMaxConcurrentRequests(maxConcurrentRequests)));

    this.pool = pool;
    this.callback = callback;
  }

  @Override
  protected T run() throws Exception {
    try (Jedis jedis = pool.getResource()) {
      return callback.apply(jedis);
    }
  }

  @Override
  protected T getFallback() {
    log.warn("Problema al ejecutar la operación con Redis.");

    if (getFailedExecutionException() != null) {
      log.warn(getFailedExecutionException().getMessage(), getFailedExecutionException());
    }
    if (getExecutionException() != null) {
      log.warn(getExecutionException().getMessage(), getExecutionException());
    }

    return null;
  }
}
