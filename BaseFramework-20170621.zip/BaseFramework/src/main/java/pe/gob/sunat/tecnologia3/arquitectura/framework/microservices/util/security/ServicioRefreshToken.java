package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.security;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Clase modelo que representa toda la configuracion del DataPower.
 *
 * @author Sapia
 * @version 1.0
 * @since 22-01-2016
 */
@Getter
@Setter
@ToString
public class ServicioRefreshToken {

	private String protocolo;
	private String host;
	private String puerto;
	private String path;

}
