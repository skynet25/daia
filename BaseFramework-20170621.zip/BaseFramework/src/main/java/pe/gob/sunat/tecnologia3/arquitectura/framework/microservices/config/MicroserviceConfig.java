package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config;

import io.dropwizard.Configuration;
import lombok.Getter;
import lombok.Setter;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.RemoteServiceLocation;

import javax.enterprise.inject.Vetoed;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Map;

import static java.lang.Boolean.TRUE;

/**
 * Created by domix on 6/9/17.
 */
@Getter
@Setter
@Vetoed
public class MicroserviceConfig extends Configuration {
  public static final String JNDI_CONFIG = "java:/SunatAppConfig";
  private List<DataSourceConfig> dataSources;
  @NotNull
  private RedisCluster redis = new RedisCluster();
  private Boolean includeServiceInfoInResponses = TRUE;
  private String serviceName = "noName";
  private String instanceId = "";
  private String version = "";
  private String environment = "LOCAL_DEV";
  private MetricsConfig metricsConfig = new MetricsConfig();
  private Boolean registerServiceDataHealthChecks = true;
  private Boolean cdiResource = false;
  private RemoteServiceLocation remoteServiceLocation = new RemoteServiceLocation();

  private SecurityFilterConfig security = new SecurityFilterConfig();

  /**
   * @deprecated No se deberia usar de esta manera la configuración, se deben tipear los parametros
   */
  @Deprecated
  private Map<String, String> parametros;
}
