package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.service;

import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.MensajeBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.MensajeDetalladoBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.MensajePersonalizadoBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.ParametroBean;

import java.util.List;

import javax.ws.rs.ServerErrorException;

/**
 * Created by domix on 4/24/17.
 */
public interface MensajeService {

	ParametroBean obtenerMensaje(String codTabla);

	MensajePersonalizadoBean obtenerListaMensaje(String codTabla, List<String> listaCodParam);

	MensajeDetalladoBean obtenerMensajeDetalle(String codTabla, RuntimeException exc);

	ParametroBean obtenerMensajeDetalle(String codTabla, String codParam);
}
