package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.metrics;

import com.codahale.metrics.MetricRegistry;
import lombok.Setter;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Default;
import javax.enterprise.inject.Produces;

/**
 * Created by domix on 2/15/17.
 */
public class MetricsCdi {
  @Setter
  private static MetricRegistry registry = null;

  @Produces
  @ApplicationScoped
  @Default
  public MetricRegistry getMetricRegistry() {
    return registry;
  }


}
