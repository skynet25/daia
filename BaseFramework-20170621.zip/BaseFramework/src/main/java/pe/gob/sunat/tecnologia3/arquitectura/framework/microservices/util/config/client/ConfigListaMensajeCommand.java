package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.client;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import lombok.extern.slf4j.Slf4j;
import okhttp3.ResponseBody;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.JsonUtilParser;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.MensajePersonalizadoBean;
import retrofit2.Call;

/**
 * Created by domix on 5/15/17.
 */
@Slf4j
public class ConfigListaMensajeCommand extends HystrixCommand<MensajePersonalizadoBean> {
  private final ServicioConfiguracionRemoto servicioConfiguracionRemoto;
  private final JsonUtilParser jsonUtilParser;
  private final String codTabla;
  private final String codParam;

  public ConfigListaMensajeCommand(ServicioConfiguracionRemoto servicioConfiguracionRemoto, JsonUtilParser jsonUtilParser, String codTabla, String codParam) {
    super(HystrixCommandGroupKey.Factory.asKey("ConfigService"));
    this.servicioConfiguracionRemoto = servicioConfiguracionRemoto;
    this.jsonUtilParser = jsonUtilParser;
    this.codTabla = codTabla;
    this.codParam = codParam;
  }

  @Override
  protected MensajePersonalizadoBean run() throws Exception {
    Call<MensajePersonalizadoBean> callResumen = servicioConfiguracionRemoto.obtenerListaMensaje(codTabla, codParam);
    return ConfigServiceRestClient.getMensajePersonalizadoBean(callResumen);
  }

  @Override
  protected MensajePersonalizadoBean getFallback() {
    return new MensajePersonalizadoBean(codTabla, "");
  }
}
