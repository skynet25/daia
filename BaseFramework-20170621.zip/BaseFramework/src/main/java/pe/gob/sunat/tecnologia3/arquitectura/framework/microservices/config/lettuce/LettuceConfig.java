package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.lettuce;

import com.lambdaworks.redis.RedisClient;
import com.lambdaworks.redis.RedisURI;
import com.lambdaworks.redis.api.StatefulRedisConnection;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Created by domix on 5/31/17.
 */
@Setter
@Getter
public class LettuceConfig {
  public static final Integer MAX_PRIORITY = BigDecimal.ZERO.toBigInteger().intValue();
  private RedisURI uri;
  private RedisClient client;
  private StatefulRedisConnection<String, String> connect;
  private Integer priority = MAX_PRIORITY;
}
