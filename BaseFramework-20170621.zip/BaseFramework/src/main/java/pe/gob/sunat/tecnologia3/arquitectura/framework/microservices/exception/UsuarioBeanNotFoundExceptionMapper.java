package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception;

import javax.enterprise.inject.Vetoed;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import static javax.ws.rs.core.Response.Status.UNAUTHORIZED;
import static javax.ws.rs.core.Response.status;

/**
 * Created by domix on 2/23/17.
 */
@Vetoed
@Provider
public class UsuarioBeanNotFoundExceptionMapper implements ExceptionMapper<UsuarioBeanNotFoundException> {
  @Override
  public Response toResponse(UsuarioBeanNotFoundException exception) {
    return status(UNAUTHORIZED)
      .entity(exception.getMessage() + " Attribute: " + exception.getAttributeName()).build();
  }
}
