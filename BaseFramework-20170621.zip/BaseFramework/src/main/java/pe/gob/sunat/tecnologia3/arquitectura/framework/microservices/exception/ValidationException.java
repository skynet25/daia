package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception;

import lombok.Getter;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.Set;

public class ValidationException extends RuntimeException {
  @Getter
  private final transient Set<ConstraintViolation<?>> constraintViolations;

  public ValidationException(ConstraintViolationException cause) {
    this("Error de validacion", cause);
  }

  public ValidationException(String message, ConstraintViolationException cause) {
    super(message, cause);
    this.constraintViolations = cause.getConstraintViolations();
  }

}