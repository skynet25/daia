package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.redis;

import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.RedisPoolRegistry;

import javax.inject.Inject;

@Slf4j
public class JedisConnectionFactory {

  @Inject
  private RedisPoolRegistry redisPoolRegistry;


}
