package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.model.dao;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.model.jpa.BaseDao;

import java.util.Collections;
import java.util.List;

@Slf4j
public class ListAllCommand extends HystrixCommand<List> {

  private final BaseDao dao;

  public ListAllCommand(BaseDao dao, String groupKey) {
    super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey(groupKey)));
    this.dao = dao;
  }

  public ListAllCommand(BaseDao dao) {
    this(dao, "DatabaseGroup");
  }

  @Override
  protected List run() throws Exception {
    //incorrecto poner codigo aplicativo
    return dao.findAll();
  }

  @Override
  protected List getFallback() {
    log.error("Problemas al consultar la base de datos");

    return Collections.emptyList();
  }
}
