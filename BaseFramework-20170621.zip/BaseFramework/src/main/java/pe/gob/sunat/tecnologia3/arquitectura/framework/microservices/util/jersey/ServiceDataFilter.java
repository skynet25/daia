package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.jersey;

import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.ConfigService;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.PersistenceConfig;

import javax.inject.Inject;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import java.io.IOException;

import static java.util.Optional.ofNullable;

/**
 * Created by domix on 5/15/17.
 */
@Slf4j
public class ServiceDataFilter implements ContainerResponseFilter {
  @Inject
  private ConfigService configService;

  @Override
  public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext) throws IOException {
    log.debug("Aplicando headers del servicio");

    ofNullable(configService).ifPresent(theConfigService -> {
      if (theConfigService.getConfig().getIncludeServiceInfoInResponses()) {
        PersistenceConfig config = theConfigService.getConfig();
        responseContext.getHeaders().add("X-ServiceName", config.getServiceName());
        responseContext.getHeaders().add("X-ServiceEnvironment", config.getEnvironment());
        responseContext.getHeaders().add("X-ServiceVersion", config.getVersion());
        responseContext.getHeaders().add("X-ServiceInstanceId", config.getInstanceId());
      }
    });
  }
}
