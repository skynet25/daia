package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config;

import lombok.Getter;
import lombok.Setter;

import javax.enterprise.inject.Vetoed;
import java.util.List;

import static java.util.Collections.emptyList;

/**
 * Created by domix on 2/27/17.
 */
@Setter
@Getter
@Vetoed
public class MetricsConfig {
  private List<String> elasticsearchNodes = emptyList();
  private Integer periodToReportInSeconds = 60;
  private Boolean includeServiceName = true;
  private Boolean includeRandomReplicaId = true;
  private Integer lenghtRandomReplicaId = 5;
  private String index = null;

  private Boolean includeConsoleReporter = false;
}
