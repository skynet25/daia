package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.model.jpa;

import javax.persistence.Query;
import java.util.List;
import java.util.Optional;

/**
 * Created by domix on 12/1/16.
 */
public interface BaseDao<T, Id> {
  T save(T object);

  T save(T object, Boolean flush);

  T findById(Id id);

  List<T> findAll();

  Optional<T> findSingle(Query query);

  List<T> findByQuery(Query query);

  List<T> findByNamedQuery(String queryName, String paramName, Object paramValue);

  List<T> find(Integer pageNumber, Integer pageSize);

  Query createNativeQuery(String queryStr);

  void delete(T object);

  <Id> void deleteById(Id id);

  <T> T update(T entity);

  Query createQuery(String qlString);

  Query createNamedQuery(String name);

  Query createNativeQuery(String sqlString, Class resultClass);

  <T> T find(Class<T> entityClass, Object primaryKey);

  javax.persistence.EntityManager getEntityManager();

  Class<T> getEntityClass();

  void clear();
}
