package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.client;

import okhttp3.ResponseBody;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.MensajeBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.MensajePersonalizadoBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.ParametroBean;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ServicioConfiguracionRemoto {

  @GET("obtenermensajecabecera")
  Call<ParametroBean> obtenerMensajeCabecera(@Query("codTabla") String codTabla);

  @GET("obtenerlistamensaje")
  Call<MensajePersonalizadoBean> obtenerListaMensaje(@Query("codTabla") String codTabla, @Query("codParam") String codParam);

  @GET("obtenermensajedetalle")
  Call<ParametroBean> obtenerMensajeDetalle(@Query("codTabla") String codTabla, @Query("codParam") String codParam);

}
