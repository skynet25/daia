package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MensajePersonalizadoBean extends MensajeBean {

	private List<ParametroBean> errors;

	public MensajePersonalizadoBean(String cod, String msg, List<ParametroBean> listaErrores) {
		super(cod, msg);
		this.errors = listaErrores;
	}

	public MensajePersonalizadoBean(String cod, String msg) {
		super(cod, msg);
	}

	public MensajePersonalizadoBean() {
		super();
	}

}
