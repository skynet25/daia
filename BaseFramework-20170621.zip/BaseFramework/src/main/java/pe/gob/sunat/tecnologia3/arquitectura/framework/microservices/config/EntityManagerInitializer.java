package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config;

import lombok.extern.slf4j.Slf4j;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.Vetoed;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;

import static javax.persistence.SynchronizationType.SYNCHRONIZED;

@Slf4j
@Vetoed
@Deprecated
public class EntityManagerInitializer {
  //lectura
  public static final String DCBDFORMULARIO = "dcbdformulario";
  public static final String DCBDPAGO = "dcbdpago";
  public static final String DCBDPDTINTERNET = "dcbdpdtinternet";
  public static final String DCBDPRAD1 = "dcbdprad1";
  public static final String DCBDRECAUDA = "dcbdrecauda";
  public static final String DCBDRSIRAT = "dcbdrsirat";
  public static final String DCBDSIRAT = "dcbdsirat";
  //escrictura
  public static final String DGBDFORMULARIO = "dgbdformulario";
  public static final String DGBDPAGO = "dgbdpago";
  public static final String DGBDPDTINTERNET = "dgbdpdtinternet";
  public static final String DGBDPRAD1 = "dgbdprad1";
  public static final String DGBDRECAUDA = "dgbdrecauda";
  public static final String DGBDRSIRAT = "dgbdrsirat";
  public static final String DGBDSIRAT = "dgbdsirat";
  //XA
  public static final String DXBDFORMULARIO = "dxbdformulario";
  public static final String DXBDPAGO = "dxbdpago";
  public static final String DXBDPDTINTERNET = "dxbdpdtinternet";
  public static final String DXBDPRAD1 = "dxbdprad1";
  public static final String DXBDRECAUDA = "dxbdrecauda";
  public static final String DXBDRSIRAT = "dxbdrsirat";
  public static final String DXBDSIRAT = "dxbdsirat";
  public static final String EMFORMULARIO = "bdformulario";
  public static final String EMPAGO = "bdpago";
  public static final String EMPDTINTERNET = "bdpdtinternet";
  public static final String EMPRAD1 = "bdprad1";
  public static final String EMRECAUDA = "bdrecauda";
  public static final String EMRSIRAT = "bdrsirat";
  public static final String EMSIRAT = "bdsirat";


  private EntityManagerInitializer() {
    log.debug("No me debes crear...");
  }

  public static EntityManager getEntityManager(String name) {
    log.debug("Creando EntityManager: {}", name);
    return Persistence
      .createEntityManagerFactory(name)
      .createEntityManager(SYNCHRONIZED);
  }

  @Produces
  @Named(DCBDFORMULARIO)
  @RequestScoped
  public static EntityManager getDCFormulario() {
    return getEntityManager(DCBDFORMULARIO);
  }

  @Produces
  @Named(DGBDFORMULARIO)
  @RequestScoped
  public static EntityManager getDGFormulario() {
    return getEntityManager(DGBDFORMULARIO);
  }

  @Produces
  @Named(DXBDFORMULARIO)
  @RequestScoped
  public static EntityManager getDXFormulario() {
    return getEntityManager(DXBDFORMULARIO);
  }


  @Produces
  @Named(DCBDPAGO)
  @RequestScoped
  public static EntityManager getDCPago() {
    return getEntityManager(DCBDPAGO);
  }

  @Produces
  @Named(DGBDPAGO)
  @RequestScoped
  public static EntityManager getDGPago() {
    return getEntityManager(DGBDPAGO);
  }

  @Produces
  @Named(DXBDPAGO)
  @RequestScoped
  public static EntityManager getDXPago() {
    return getEntityManager(DXBDPAGO);
  }

  @Produces
  @Named(DCBDPDTINTERNET)
  @RequestScoped
  public static EntityManager getDCPdtInternet() {
    return getEntityManager(DCBDPDTINTERNET);
  }

  @Produces
  @Named(DGBDPDTINTERNET)
  @RequestScoped
  public static EntityManager getDGPdtInternet() {
    return getEntityManager(DGBDPDTINTERNET);
  }

  @Produces
  @Named(DXBDPDTINTERNET)
  @RequestScoped
  public static EntityManager getDXPdtInternet() {
    return getEntityManager(DXBDPDTINTERNET);
  }

  @Produces
  @Named(DCBDPRAD1)
  @RequestScoped
  public static EntityManager getDCPrad1() {
    return getEntityManager(DCBDPRAD1);
  }

  @Produces
  @Named(DGBDPRAD1)
  @RequestScoped
  public static EntityManager getDGPrad1() {
    return getEntityManager(DGBDPRAD1);
  }

  @Produces
  @Named(DXBDPRAD1)
  @RequestScoped
  public static EntityManager getDXPrad1() {
    return getEntityManager(DXBDPRAD1);
  }

  @Produces
  @Named(DCBDRECAUDA)
  @RequestScoped
  public static EntityManager getDCRecauda() {
    return getEntityManager(DCBDRECAUDA);
  }

  @Produces
  @Named(DGBDRECAUDA)
  @RequestScoped
  public static EntityManager getDGRecauda() {
    return getEntityManager(DGBDRECAUDA);
  }

  @Produces
  @Named(DXBDRECAUDA)
  @RequestScoped
  public static EntityManager getDXRecauda() {
    return getEntityManager(DXBDRECAUDA);
  }

  @Produces
  @Named(DCBDRSIRAT)
  @RequestScoped
  public static EntityManager getDCRSirat() {
    return getEntityManager(DCBDRSIRAT);
  }

  @Produces
  @Named(DGBDRSIRAT)
  @RequestScoped
  public static EntityManager getDGRSirat() {
    return getEntityManager(DGBDRSIRAT);
  }

  @Produces
  @Named(DXBDRSIRAT)
  @RequestScoped
  public static EntityManager getDXRSirat() {
    return getEntityManager(DXBDRSIRAT);
  }

  @Produces
  @Named(DCBDSIRAT)
  @RequestScoped
  public static EntityManager getDCSirat() {
    return getEntityManager(DCBDSIRAT);
  }

  @Produces
  @Named(DGBDSIRAT)
  @RequestScoped
  public static EntityManager getDGSirat() {
    return getEntityManager(DGBDSIRAT);
  }

  @Produces
  @Named(DXBDSIRAT)
  @RequestScoped
  public static EntityManager getDXSirat() {
    return getEntityManager(DXBDSIRAT);
  }

  @Produces
  @Named(EMFORMULARIO)
  @RequestScoped
  public static EntityManager getEMFormulario() {
    return getEntityManager(EMFORMULARIO);
  }

  @Produces
  @Named(EMPAGO)
  @RequestScoped
  public static EntityManager getEMPago() {
    return getEntityManager(EMPAGO);
  }

  @Produces
  @Named(EMPDTINTERNET)
  @RequestScoped
  public static EntityManager getEMPdtInternet() {
    return getEntityManager(EMPDTINTERNET);
  }

  @Produces
  @Named(EMPRAD1)
  @RequestScoped
  public static EntityManager getEMPrad1() {
    return getEntityManager(EMPRAD1);
  }

  @Produces
  @Named(EMRECAUDA)
  @RequestScoped
  public static EntityManager getEMRecauda() {
    return getEntityManager(EMRECAUDA);
  }

  @Produces
  @Named(EMRSIRAT)
  @RequestScoped
  public static EntityManager getEMRSirat() {
    return getEntityManager(EMRSIRAT);
  }

  @Produces
  @Named(EMSIRAT)
  @RequestScoped
  public static EntityManager getEMSirat() {
    return getEntityManager(EMSIRAT);
  }
}
