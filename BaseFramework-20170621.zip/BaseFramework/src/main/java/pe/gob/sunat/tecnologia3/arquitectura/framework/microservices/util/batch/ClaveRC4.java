package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.batch;

import javax.enterprise.inject.Vetoed;

@Vetoed
public class ClaveRC4 {

  /**
   * @autor: JASS
   */

  public String generaKey(String identificador) {
    byte[] aFactor = new byte[17];
    String ab;
    String claveOK;
    String clave = identificador;
    aFactor[0] = 6;
    aFactor[1] = 5;
    aFactor[2] = 4;
    aFactor[3] = 3;
    aFactor[4] = 2;
    aFactor[5] = 7;
    aFactor[6] = 6;
    aFactor[7] = 5;
    aFactor[8] = 4;
    aFactor[9] = 3;
    aFactor[10] = 2;
    aFactor[11] = 7;
    aFactor[12] = 6;
    aFactor[13] = 5;
    aFactor[14] = 4;
    aFactor[15] = 3;
    aFactor[16] = 2;
    int k = 17;
    int wsuma = 0;
    for (int i = clave.length() - 1; i >= 0; --i) {
      wsuma += (clave.charAt(i) - '0') * aFactor[k - 1];
      --k;
    }

    int wDav = 11 - (wsuma % 11);
    if (wDav == 11) {
      wDav = 1;
    } else if (wDav == 10)
      wDav = 0;
    clave = String.valueOf(clave) + String.valueOf(wDav);
    ab = clave.substring(0, 2);
    int abint = Integer.parseInt(ab);
    claveOK = String.valueOf(abint % 9) + String.valueOf(clave);
    return claveOK;
  }
}

