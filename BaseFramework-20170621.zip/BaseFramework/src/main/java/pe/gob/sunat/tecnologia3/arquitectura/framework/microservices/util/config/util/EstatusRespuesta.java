package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.util;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

/**
 * Created by Christian Morales on 23/05/2017.
 */
@Getter
@Slf4j
public enum EstatusRespuesta {
    BAD_NEGOCIO("Unprocessable Entity - Se presentaron errores de validación que impidieron completar el Request ENUM",422),
    BAD_PERIODO_TRIBUTARIO("Sr. Contribuyente, por favor revise el per&iacute;odo tributario consignado en el PDT, el cual no puede ser mayor a %s. ENUM",42200),
    PDT_HA_SIDO_PRESENTADO("Sr. Contribuyente el archivo PDT (%s) ya ha sido presentado con anterioridad", 42201),
    BAD_PDT_GENERADO("Sr. Contribuyente falta alg&uacute;n archivo o el tama&ntilde;o no corresponde al generado por el programa de captura del PDT",42202 ),
    RUC_NO_COINCIDE("Sr. Contribuyente el Nro. de RUC del usuario SOL no coincide con el Nro. de RUC de la Declaraci&oacute;n",42203 ),
    DOCUMENTO_INVALIDO("Sr. Contribuyente el Tipo de Documento consignado en la declaraci&oacute;n es inv&aacute;lido", 42204),
    PDT_PARAMETRO_NO_VIGENTE("Sr. Contribuyente la versi&oacute;n de par&aacute;metro del PDT presentado no se encuentra vigente", 42205),
    SOFTWARE_PDT_NO_VIGENTE("Sr. Contribuyente la versi&oacute;n del software con el que gener&oacute; el PDT no se encuentra vigente",42206),
    DECLARACION_EXISTENTE_PERIODO("Sr. Contribuyente ya existe una declaraci&oacute;n presentada para el mismo periodo tributario",42207),
    DECLARACION_RECTIFICATORIA_NO_HABILITADA("Sr. Contribuyente no existe una declaraci&oacute;n anterior para que pueda presentar una declaraci&oacute;n rectificatoria",42208),
    BAD_DECLARACION("Sr. Contribuyente ha ocurrido un error al procesar la declaraci&oacute;n. Por favor intente nuevamente.", 42209),
    DECLARACION_PRE_EXISTENTE("Sr. Contribuyente existe una declaraci&oacute;n para este Periodo que est&aacute; siendo presentada en otra instancia.", 42210),
    DATOS_NO_PROCESADOS("Los datos recibidos no han podido ser procesados adecuadamente.", 42210),
    PROCESO_PAGO("Respuesta de Entidad Financiera - al momento de procesar el Pago.", 423);

    private String msg;
    private Integer codigo;

    EstatusRespuesta(String msg, Integer codigo) {
        this.msg = msg;
        this.codigo = codigo;
    }

    public static String obtenerMensaje(String codMensaje) {
        for (EstatusRespuesta status :EstatusRespuesta.values()) {
            if(status.getCodigo().equals(Integer.valueOf(codMensaje))){
                return status.getMsg();
            }
        }
        return "";
    }
}
