package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.redis.lettuce;

import com.lambdaworks.redis.api.StatefulRedisConnection;
import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixCommandKey;
import com.netflix.hystrix.HystrixCommandProperties;
import lombok.extern.slf4j.Slf4j;

import java.util.function.Function;

import static com.netflix.hystrix.HystrixCommandProperties.ExecutionIsolationStrategy.SEMAPHORE;

/**
 * Created by domix on 5/31/17.
 */
@Slf4j
public class LettuceOperationCommand<T> extends HystrixCommand<T> {
  private final Function<StatefulRedisConnection<String, String>, T> callback;
  private final Integer timeout;
  private final StatefulRedisConnection<String, String> connection;

  public LettuceOperationCommand(StatefulRedisConnection<String, String> connection, Function<StatefulRedisConnection<String, String>, T> callback, Integer timeout, Integer maxConcurrentRequests) {
    super(Setter
      .withGroupKey(HystrixCommandGroupKey.Factory.asKey("RedisCluster"))
      .andCommandKey(HystrixCommandKey.Factory.asKey("RedisOperationCommand"))
      .andCommandPropertiesDefaults(
        HystrixCommandProperties.Setter()
          .withExecutionIsolationStrategy(SEMAPHORE)
          .withExecutionTimeoutInMilliseconds(timeout)
          .withExecutionIsolationSemaphoreMaxConcurrentRequests(maxConcurrentRequests)));
    this.connection = connection;

    this.callback = callback;
    this.timeout = timeout;
  }

  @Override
  protected T run() throws Exception {
    log.debug("A punto de ejecutar la operacion");
    T apply = callback.apply(connection);
    return apply;
  }

  @Override
  protected T getFallback() {
    log.warn("Problema al ejecutar la operación con Redis.");

    if (isResponseTimedOut()) {
      log.warn("Timeout detectado: {}, timeout configurado: {}", getExecutionTimeInMilliseconds(), timeout);
    }

    return null;
  }
}
