package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.redis;

import com.codahale.metrics.health.HealthCheck;
import lombok.extern.slf4j.Slf4j;

import javax.enterprise.inject.Vetoed;

import static com.codahale.metrics.health.HealthCheck.Result.healthy;

/**
 * Permite verificar que la conexión a Redis funcione correctamente.
 * <p>
 * Created by domix on 2/9/17.
 */
@Vetoed
@Slf4j
public class RedisHealthCheck extends HealthCheck {
  @Override
  protected Result check() throws Exception {
    return healthy();
  }
}
