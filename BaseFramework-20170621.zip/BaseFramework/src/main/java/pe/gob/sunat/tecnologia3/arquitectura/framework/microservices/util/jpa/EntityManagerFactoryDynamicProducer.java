package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.jpa;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.context.Dependent;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.Vetoed;
import javax.enterprise.inject.spi.Annotated;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.persistence.EntityManagerFactory;
import java.util.Map;

import static java.util.Collections.unmodifiableMap;
import static java.util.stream.Stream.of;
import static javax.persistence.Persistence.createEntityManagerFactory;
import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.CollectionsUtil.entriesToMap;
import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.CollectionsUtil.entry;

/**
 * Created by domix on 5/5/17.
 */
@Slf4j
@Vetoed
@Deprecated
public class EntityManagerFactoryDynamicProducer {

  //@Produces
  //@ApplicationScoped
  //@Dependent
  //@JpaEntityManagerFactory
  public EntityManagerFactory produce(InjectionPoint ip) {
    if (ip.getAnnotated().isAnnotationPresent(JpaEntityManagerFactory.class)) {
      return toObject(ip);
    }
    throw new IllegalArgumentException("Annotation @JpaEntityManagerFactory is required when injecting EntityManagerFactory");
  }

  public EntityManagerFactory toObject(InjectionPoint ip) {
    Annotated gtAnnotated = ip.getAnnotated();
    JpaEntityManagerFactory named = gtAnnotated.getAnnotation(JpaEntityManagerFactory.class);
    String persistenceUnitName = named.emName();

    return create(persistenceUnitName);
  }

  public static EntityManagerFactory create(String persistenceUnitName) {
    if (StringUtils.isBlank(persistenceUnitName)) {
      throw new IllegalArgumentException("El nombre de la unidad de persistencia es requerido");
    }

    Map<String, String> additionalFields =
      unmodifiableMap(
        of(
          entry("eclipselink.logging.level", "ALL"),
          entry("eclipselink.logging.level.sql", "ALL"),
          entry("eclipselink.logging.parameters", "true"),
          entry("eclipselink.target-server", "pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.AtomikosPlatform"),
          entry("eclipselink.cache.shared.default", "false"),
          entry("jdbc.persistence.logging", "true"))
          .collect(entriesToMap()));

    return createEntityManagerFactory(persistenceUnitName, additionalFields);
  }
}
