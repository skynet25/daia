package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config;

import com.lambdaworks.redis.api.StatefulRedisConnection;
import lombok.Getter;
import lombok.Setter;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.lettuce.LettuceConfig;

import javax.enterprise.inject.Vetoed;
import java.util.List;
import java.util.Optional;

import static java.util.Comparator.comparing;
import static java.util.Optional.ofNullable;

/**
 * Created by domix on 5/26/17.
 */
@Vetoed
public class RedisPoolRegistry {
  private static RedisPoolRegistry instance;
  @Setter
  @Getter
  private List<LettuceConfig> lettuceConfigs;

  static {
    if (instance == null) {
      instance = new RedisPoolRegistry();
    }
  }

  public static RedisPoolRegistry getInstance() {
    return instance;
  }

  public Optional<LettuceConfig> getLettucePool(Integer gtPriority) {
    return lettuceConfigs.stream()
      .sorted(comparing(LettuceConfig::getPriority))
      .filter(redisPool -> redisPool.getPriority() > gtPriority)
      .findFirst();
  }

  public Optional<LettuceConfig> getPrimaryLettucePool() {
    return lettuceConfigs.stream()
      .min(comparing(LettuceConfig::getPriority));
  }

  public Boolean reconnectIfNeccesary(LettuceConfig lettuceConfig) {
    StatefulRedisConnection<String, String> connection = lettuceConfig.getConnect();
    /*lettuceConfig.getClient().setOptions(ClientOptions.builder().autoReconnect(true)
      .cancelCommandsOnReconnectFailure(true).pingBeforeActivateConnection(true).disconnectedBehavior());*/
    if (!isConnected(connection)) {
      lettuceConfig.setConnect(lettuceConfig.getClient().connect());
    }

    return isConnected(lettuceConfig.getConnect());
  }

  public boolean isConnected(StatefulRedisConnection<String, String> connection) {
    return connection != null && connection.isOpen();
  }

  public Optional<LettuceConfig> getPrimaryConnectedClusterConfig() {
    return ofNullable(
      getPrimaryLettucePool()
        .filter(lettuceConfig -> isConnected(lettuceConfig.getConnect()))
        .orElse(null));
  }

  public Optional<StatefulRedisConnection<String, String>> getPrimaryConnection() {

    /*Optional<LettuceConfig> primaryLettucePool = getPrimaryLettucePool();

    Integer priority = primaryLettucePool
      .map(LettuceConfig::getPriority)
      .orElse(MAX_PRIORITY);*/
    return ofNullable(
      getPrimaryConnectedClusterConfig()
        .map(LettuceConfig::getConnect)
        .orElse(null));
  }


}
