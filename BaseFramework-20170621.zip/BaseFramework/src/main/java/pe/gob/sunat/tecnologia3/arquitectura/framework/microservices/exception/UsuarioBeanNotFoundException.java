package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception;

import lombok.Getter;

/**
 * Created by domix on 2/23/17.
 */
public class UsuarioBeanNotFoundException extends GenericException {
  @Getter
  private final String attributeName;

  public UsuarioBeanNotFoundException(String message, String attributeName) {
    super(message);
    this.attributeName = attributeName;
  }
}
