package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.cache;

import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.RedisPoolRegistry;

import javax.cache.Cache;
import javax.cache.CacheException;
import javax.cache.CacheManager;
import javax.cache.configuration.Configuration;
import javax.cache.spi.CachingProvider;
import java.lang.ref.WeakReference;
import java.net.URI;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import static java.lang.String.format;
import static java.util.Objects.requireNonNull;
import static org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString;

/**
 * Created by domix on 2/24/17.
 */
@Slf4j
public final class RedisCacheManager implements CacheManager {
  private final CachingProvider cachingProvider;
  private final URI uri;
  private RedisPoolRegistry redisPoolRegistry;
  private final ClassLoader classLoader;
  private final Properties properties;
  protected final WeakReference<ClassLoader> classLoaderReference;
  protected final boolean isDefaultURI;
  protected final boolean isDefaultClassLoader;
  protected final String cacheNamePrefix;

  protected final ConcurrentMap<String, RedisCache<?, ?>> caches = new ConcurrentHashMap<>();

  public RedisCacheManager(CachingProvider cachingProvider, URI uri,
                           ClassLoader classLoader, Properties properties) {

    log.debug("Creando RedisCacheManager");
    this.cachingProvider = cachingProvider;
    this.classLoader = classLoader;
    isDefaultURI = uri == null || cachingProvider.getDefaultURI().equals(uri);

    this.uri = isDefaultURI ? cachingProvider.getDefaultURI() : uri;

    isDefaultClassLoader = classLoader == null || cachingProvider.getDefaultClassLoader().equals(classLoader);
    final ClassLoader localClassLoader = isDefaultClassLoader ? cachingProvider.getDefaultClassLoader() : classLoader;
    this.classLoaderReference = new WeakReference<>(localClassLoader);

    this.properties = properties == null ? new Properties() : new Properties(properties);

    this.cacheNamePrefix = fabricCacheNamePrefix();
  }

  @Override
  public CachingProvider getCachingProvider() {
    return this.cachingProvider;
  }

  @Override
  public URI getURI() {
    return this.uri;
  }

  @Override
  public ClassLoader getClassLoader() {
    return this.classLoader;
  }

  @Override
  public Properties getProperties() {
    return this.properties;
  }

  @Override
  public <K, V, C extends Configuration<K, V>> Cache<K, V> createCache(String cacheName, C configuration) {
    requireNonNull(cacheName, "cacheName must not be null");

    if (redisPoolRegistry == null) {
      this.redisPoolRegistry = RedisPoolRegistry.getInstance();
    }

    final String cacheNameWithPrefix = getCacheNameWithPrefix(cacheName);
    if (caches.containsKey(cacheNameWithPrefix)) {
      throw new CacheException(format("A cache named %s already exists. Redis full", cacheName));
    }

    log.debug("Creando el cache '{}' con configuración: {}", cacheName, reflectionToString(configuration));

    return new RedisCache(cacheNameWithPrefix, this, (RedisCacheConfiguration) configuration, redisPoolRegistry);
  }

  @Override
  public <K, V> Cache<K, V> getCache(String cacheName, Class<K> keyType, Class<V> valueType) {
    return getCache(cacheName);
  }

  @Override
  public <K, V> Cache<K, V> getCache(String cacheName) {
    final String cacheNameWithPrefix = getCacheNameWithPrefix(cacheName);

    RedisCacheConfiguration defaultConfiguration = new RedisCacheConfiguration();

    return Optional.ofNullable(caches.get(cacheNameWithPrefix))
      .map(entries -> (Cache<K, V>) entries)
      .orElseGet(() -> createCache(cacheName, defaultConfiguration));
  }

  @Override
  public Iterable<String> getCacheNames() {
    Set<String> names = new LinkedHashSet<>();
    for (Map.Entry<String, RedisCache<?, ?>> entry : caches.entrySet()) {
      String nameWithPrefix = entry.getKey();
      int index = nameWithPrefix.indexOf(cacheNamePrefix) + cacheNamePrefix.length();
      final String name = nameWithPrefix.substring(index);
      names.add(name);
    }
    return Collections.unmodifiableCollection(names);
  }

  @Override
  public void destroyCache(String cacheName) {
    log.error("destroyCache is disabled..");
  }

  @Override
  public void enableManagement(String cacheName, boolean enabled) {
    log.error("enableManagement is disabled..");
  }

  @Override
  public void enableStatistics(String cacheName, boolean enabled) {
    log.error("enableStatistics is disabled..");
  }

  @Override
  public void close() {
    log.debug("closing...");
  }

  @Override
  public boolean isClosed() {
    return redisPoolRegistry.getPrimaryConnection()
      .map(connection -> !connection.isOpen()).orElse(true);
  }

  @Override
  public <T> T unwrap(Class<T> clazz) {
    return clazz.cast(redisPoolRegistry.getPrimaryConnection()
      .orElseThrow(() -> new RuntimeException("Prioblemas graves")));
  }

  /**
   * This method calculates a fixed string based on the URI and classloader using the formula:
   * <p>/hz[/uri][/classloader]/</p>
   * <p>URI and classloader are dropped if they have default values.</p>
   *
   * @return the calculated cache prefix.
   */
  protected String fabricCacheNamePrefix() {
    final StringBuilder sb = new StringBuilder("/cache");
    if (!isDefaultURI) {
      sb.append("/").append(uri.toASCIIString());
    }
    final ClassLoader thisClassLoader = getClassLoader();
    if (!isDefaultClassLoader && thisClassLoader != null) {
      sb.append("/").append(thisClassLoader.toString());
    }
    sb.append("/");
    return sb.toString();
  }

  protected String getCacheNameWithPrefix(String name) {
    return cacheNamePrefix + name;
  }

}
