package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config;

import lombok.Getter;
import lombok.Setter;

import javax.enterprise.inject.Vetoed;

@Getter
@Setter
@Vetoed
@Deprecated
public class PersistenceConfig extends MicroserviceConfig {

}
