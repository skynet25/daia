package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.redis;

import lombok.Getter;
import lombok.Setter;
import redis.clients.jedis.Jedis;

import javax.enterprise.inject.Vetoed;

@Getter
@Setter
@Vetoed
public class JedisContainer {
  private Jedis jedis;
}
