package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception;

import com.google.common.collect.FluentIterable;
import com.google.common.collect.ImmutableList;
import io.dropwizard.jersey.validation.ValidationErrorMessage;

import javax.enterprise.inject.Vetoed;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import static java.lang.String.format;
import static javax.ws.rs.core.Response.Status.NOT_ACCEPTABLE;

@Vetoed
@Provider
public class ValidationViolationExceptionMapper implements ExceptionMapper<ValidationException> {
  @Override
  public Response toResponse(final ValidationException exception) {

    final ImmutableList<String> errors = FluentIterable
      .from(exception.getConstraintViolations())
      .transform(violation ->
        format("%s: %s", violation.getPropertyPath().toString(), violation.getMessage()))
      .toList();

    return Response
      .status(NOT_ACCEPTABLE)
      .entity(new ValidationErrorMessage(errors))
      .build();
  }
}
