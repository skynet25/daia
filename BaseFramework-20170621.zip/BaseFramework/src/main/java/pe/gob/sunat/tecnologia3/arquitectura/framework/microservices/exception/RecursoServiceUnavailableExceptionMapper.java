package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception;

import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.cdi.CdiService;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.MensajeDetalladoBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.service.MensajeService;

import javax.enterprise.inject.Vetoed;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.Arrays;
import java.util.Optional;

import static javax.ws.rs.core.Response.Status.SERVICE_UNAVAILABLE;
import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.util.MensajeUtil.obtenerMensaje;

@Vetoed
@Provider
public class RecursoServiceUnavailableExceptionMapper implements ExceptionMapper<RecursoNoDisponibleException> {

  @Override
  public Response toResponse(RecursoNoDisponibleException exception) {
    Optional<MensajeService> facade = CdiService.getFacade(MensajeService.class);
    String codStatus = String.valueOf(SERVICE_UNAVAILABLE.getStatusCode());
    MensajeDetalladoBean mensajeDetalladoBean = facade
      .map(servicio -> servicio
        .obtenerMensajeDetalle(codStatus, exception))
      .orElse(
        new MensajeDetalladoBean(
          codStatus, obtenerMensaje(codStatus), Arrays.toString(exception.getStackTrace())));

    return Response.status(SERVICE_UNAVAILABLE)
      .entity(mensajeDetalladoBean)
      .build();

  }

}
