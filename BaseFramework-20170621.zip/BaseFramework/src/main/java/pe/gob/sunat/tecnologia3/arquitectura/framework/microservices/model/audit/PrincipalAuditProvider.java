package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.model.audit;

/**
 * Created by domix on 2/26/17.
 */
public interface PrincipalAuditProvider {
  String getPrincipal();

  void setPrincipal(String principal);
}
