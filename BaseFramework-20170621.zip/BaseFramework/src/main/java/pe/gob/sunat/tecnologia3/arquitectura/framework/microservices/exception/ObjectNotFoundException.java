package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception;

import lombok.Getter;

import java.io.Serializable;

public class ObjectNotFoundException extends RuntimeException {
  @Getter
  private final Serializable data;

  public ObjectNotFoundException(String message) {
    this(message, null);
  }

  public ObjectNotFoundException(Serializable data) {
    this("No se encontro el objeto***", data);
  }

  public ObjectNotFoundException(String message, Serializable data) {
    this(message, null, data);
  }

  public ObjectNotFoundException(String message, Throwable cause, Serializable data) {
    super(message, cause);
    this.data = data;
  }
}
