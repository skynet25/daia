package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception;

import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.cdi.CdiService;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.MensajeBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.ParametroBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.service.MensajeService;

import javax.enterprise.inject.Vetoed;
import javax.ws.rs.NotAllowedException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.Optional;

import static javax.ws.rs.core.Response.Status.METHOD_NOT_ALLOWED;
import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.util.MensajeUtil.obtenerMensaje;

@Vetoed
@Provider
public class RecursoNotAllowedExceptionMapper implements ExceptionMapper<NotAllowedException> {

  @Override
  public Response toResponse(NotAllowedException exception) {
    Optional<MensajeService> facade = CdiService.getFacade(MensajeService.class);
    String codSatatus = String.valueOf(METHOD_NOT_ALLOWED.getStatusCode());
    ParametroBean parametroBean = facade
      .map(servicio -> servicio
        .obtenerMensaje(codSatatus)).orElse(new ParametroBean(codSatatus, obtenerMensaje(codSatatus)));

    return Response.status(METHOD_NOT_ALLOWED)
            .entity(parametroBean)
            .build();
  }
}
