package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.model.audit;

import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception.GenericException;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.model.annotation.CreatedBy;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.model.annotation.CreatedDate;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.model.annotation.LastModifiedBy;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.model.annotation.LastModifiedDate;

import javax.enterprise.inject.Vetoed;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.Date;
import java.util.Optional;

import static org.apache.commons.lang3.reflect.FieldUtils.*;
import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.cdi.CdiService.getFacade;

/**
 * Created by domix on 2/26/17.
 */
@Vetoed
@Slf4j
public class AuditEntityListener {

  @PrePersist
  public void prePersist(Object entity) {
    log.debug("About to Persist an Entity: {}", entity.getClass().getName());

    process(entity, true);
  }

  @PreUpdate
  public void preUpdate(Object entity) {
    log.debug("About to Update an Entity: {}", entity.getClass().getName());

    process(entity, false);
  }

  private void process(Object entity, Boolean creating) {
    String user = getFacade(PrincipalAuditProvider.class)
      .map(PrincipalAuditProvider::getPrincipal)
      .orElse(null);

    if (creating) {
      Optional<Field> createdDateFieldOptional = findField(entity, CreatedDate.class);
      Optional<Field> createdByFieldOptional = findField(entity, CreatedBy.class);

      if (log.isDebugEnabled()) {
        log.debug("CreatedDate {}", getValue(createdDateFieldOptional, entity, Date.class));
        log.debug("CreatedBy {}", getValue(createdByFieldOptional, entity, String.class));
      }

      setValue(createdDateFieldOptional, entity, new Date());
      setValue(createdByFieldOptional, entity, user);
    } else {
      Optional<Field> lastModiFieldOptional = findField(entity, LastModifiedDate.class);
      Optional<Field> lastModifiedFieldOptional = findField(entity, LastModifiedBy.class);

      if (log.isDebugEnabled()) {
        log.debug("LastModifiedDate {}", getValue(lastModiFieldOptional, entity, Date.class));
        log.debug("LastModifiedBy {}", getValue(lastModifiedFieldOptional, entity, String.class));
      }

      setValue(lastModiFieldOptional, entity, new Date());
      setValue(lastModifiedFieldOptional, entity, user);
    }
  }

  private void setValue(Optional<Field> field, Object instance, Object value) {
    field.ifPresent(field1 -> {
      try {
        writeField(field1, instance, value, true);
      } catch (IllegalAccessException e) {
        throw new GenericException(e);
      }
    });
  }

  private <T> T getValue(Optional<Field> field, Object instance, Class<T> e) {

    return field.map(field1 -> {
      try {
        return e.cast(readField(field1, instance, true));
      } catch (IllegalAccessException e1) {
        throw new GenericException(e1);
      }
    }).orElse(null);
  }

  private Optional<Field> findField(Object entity, final Class<? extends Annotation> annotationCls) {
    return getFieldsListWithAnnotation(entity.getClass(), annotationCls)
      .stream().findFirst();
  }
}
