package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.NotBlank;

/**
 * Created by domix on 4/24/17.
 */
@Getter
@Setter
public class RemoteServiceLocation {
  @NotBlank
  private String serviceBase = "http://localhost:7130";
  private String baseUrlForConfiguracionService = "/v1/recaudacion/tributaria/configuracion/t/parametro/";
}
