package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import redis.clients.jedis.Jedis;
import redis.clients.util.Pool;

/**
 * Created by domix on 5/26/17.
 */
@Setter
@Getter
@Builder
public class RedisPool {
  private Integer priority;
  private Pool<Jedis> pool;
}
