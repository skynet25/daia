package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config;

import lombok.Getter;
import lombok.Setter;

import javax.enterprise.inject.Vetoed;
import javax.validation.constraints.NotNull;
import java.util.Map;

@Getter
@Setter
@Vetoed
public class DataSourceConfig {
  static final int DEFAULT_ISOLATION_LEVEL_UNSET = -1;
  private static final int DEFAULT_POOL_SIZE = 2;
  private static final int DEFAULT_MAX_POOL_SIZE = 5;

  private int minPoolSize = DEFAULT_POOL_SIZE;
  private int maxPoolSize = DEFAULT_MAX_POOL_SIZE;
  private int borrowConnectionTimeout = 30;
  private int reapTimeout = 0;
  private int maxIdleTime = 60;
  private String testQuery = "SELECT 1 FROM sysmaster:sysdual";
  private int maintenanceInterval = 60;
  private int loginTimeout;
  private String uniqueResourceName;
  private int defaultIsolationLevel = DEFAULT_ISOLATION_LEVEL_UNSET;
  private int maxLifetime = 60;
  private Boolean healthCheck = true;

  private Map xaProperties = null;
  private String xaDataSourceClassName = null;
  @NotNull
  private String jndiName;

  private String url;
  private String user;
  private String password;
  private String driverClassName;
  private boolean readOnly = false;

  private Integer timeoutHealthCheckInMilliseconds = 1000;

  private Map entityManagerProperties = null;
}
