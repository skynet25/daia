package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MensajeDetalladoBean extends MensajeBean {

	private String exc;

	public MensajeDetalladoBean(String cod, String msg) {
		super(cod, msg);
	}
	
	public MensajeDetalladoBean(String cod, String msg, String exc) {
		super(cod, msg);
		this.exc = exc;
	}
	
	public MensajeDetalladoBean(ParametroBean parametroBean, String exc) {
		super(parametroBean.getCod(), parametroBean.getMsg());
		this.exc = exc;
	}
}
