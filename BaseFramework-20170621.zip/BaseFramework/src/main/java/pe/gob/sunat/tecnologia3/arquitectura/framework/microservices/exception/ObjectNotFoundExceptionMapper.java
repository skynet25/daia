package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception;

import javax.enterprise.inject.Vetoed;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import static javax.ws.rs.core.Response.Status.NOT_FOUND;
import static javax.ws.rs.core.Response.status;

@Vetoed
@Provider
public class ObjectNotFoundExceptionMapper implements ExceptionMapper<ObjectNotFoundException> {
  @Override
  public Response toResponse(ObjectNotFoundException exception) {
    return status(NOT_FOUND)
      .entity(exception.getData())
      .build();
  }
}
