package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.security;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Clase modelo que representa toda la configuracion del DataPower.
 *
 * @author Sapia
 * @version 1.0
 * @since 22-01-2016
 */
@Getter
@Setter
@ToString
public class ServicioAutorizacion {

	private String protocolo;
	private String host;
	private String puerto;
	private String path;

	@Getter
	@Setter
	@ToString
	public class EntradaServicioAutorizacion {

		private String sunatUser;
		private String password;
		private String urlOrig;
		private String scope;
		
		/**
		 * Método utilizado para convertir desde Objeto a JSON.
		 * @param objectMapper
		 * @return
		 */
		public String toJson(ObjectMapper objectMapper) {
			String json = null;
			try {
				json = objectMapper.writeValueAsString(this);
			} catch (Exception e) {
			}
			return json;
		}

	}

}
