package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception.GenericException;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.jackson.JacksonFactory;

import java.io.IOException;
import java.io.Serializable;
import java.util.Map;

import static java.util.Collections.unmodifiableMap;
import static java.util.Optional.ofNullable;
import static java.util.stream.Stream.of;
import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.CollectionsUtil.entriesToMap;
import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.CollectionsUtil.entry;

/**
 * @autor: jyauyo [09-2016]
 * @descripción: {Clase que convierte una cadena json en el tipo de Clase enviado, y Un objecto a cadena json}
 */
@Slf4j
public class JsonUtilParser implements Serializable {

  private final ObjectMapper objectMapper;

  public JsonUtilParser() {
    this.objectMapper = JacksonFactory.getObjectMapper();
  }

  /**
   * Convierte un documento JSON a un objeto Java.
   *
   * @param json  El documento fuente JSON.
   * @param clazz La clase a la cual se desea obtener una instancia
   * @param <T>   El tipo de la clase que se desea
   * @return La instancia del objeto recien creada
   * @throws GenericException Si no se pudo realizar la conversion de JSON a objeto
   */
  public <T> T toObject(String json, Class<T> clazz) {
    try {
      return objectMapper.readValue(json, clazz);
    } catch (IOException e) {
      Map<String, String> data = unmodifiableMap(of(
        entry("json", json),
        entry("class", clazz.getClass().getName()))
        .collect(entriesToMap()));

      throw new GenericException("No se pudo convertir de JSON a objeto.", e, data);
    }
  }

  /**
   * @autor: jyauyo [09-2016]
   */
  public <T> T jsonToEntity(String json, Class<T> clazz) {
    String jsonFixed = replace(json, "IfxBSONObject ", "");
    return toObject(jsonFixed, clazz);
  }

  /**
   * @autor: jyauyo [09-2016]
   */
  public String entityToJson(Object obj) {

    String strJSON;

    try {
      strJSON = objectMapper.writeValueAsString(obj);
    } catch (JsonProcessingException e) {
      String name = ofNullable(obj)
        .map(o -> o.getClass().getName())
        .orElse("Null OBJ");
      Map<String, String> data = unmodifiableMap(of(
        entry("obj", name))
        .collect(entriesToMap()));

      throw new GenericException("No se pudo convertir de Objeto a JSON.", e, data);
    }

    return strJSON;
  }


  /**
   * @autor: jyauyo [09-2016]
   */
  private String replace(String str, String pattern, String replace) {
    return Cadena.replace(str, pattern, replace);
  }

}
