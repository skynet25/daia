package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.cache;

import javax.enterprise.inject.Any;
import javax.enterprise.inject.Vetoed;
import javax.enterprise.util.AnnotationLiteral;

/**
 * Created by domix on 2/24/17.
 */
@Vetoed
public class AnyLiteral extends AnnotationLiteral<Any> implements Any {
  public static final AnyLiteral INSTANCE = new AnyLiteral();

  @Override
  public String toString() {
    return "@javax.enterprise.inject.Any()";
  }
}
