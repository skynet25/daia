package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util;

import lombok.extern.slf4j.Slf4j;
import org.jboss.util.naming.NonSerializableFactory;

import javax.enterprise.inject.Vetoed;
import javax.naming.*;

/**
 * Created by domix on 1/18/17.
 */
@Slf4j
@Vetoed
public class JndiUtils {

  private JndiUtils() {
    log.debug("No puedes crear esta clase");
  }

  public static void bind(String jndiName, Object who, Class classType, Context ctx) {
    // Ah ! This service isn't serializable, so we use a helper class
    try {
      NonSerializableFactory.bind(jndiName, who);
      Name n = ctx.getNameParser("").parse(jndiName);
      while (n.size() > 1) {
        String ctxName = n.get(0);
        try {
          ctx = (Context) ctx.lookup(ctxName);
        } catch (NameNotFoundException e) {
          log.trace("Falling back the Context {}", e);
          ctx = ctx.createSubcontext(ctxName);
        }
        n = n.getSuffix(1);
      }

      // The helper class NonSerializableFactory uses address type nns, we go on to
      // use the helper class to bind the service object in JNDI
      StringRefAddr addr = new StringRefAddr("nns", jndiName);
      Reference ref = new Reference(classType.getName(), addr, NonSerializableFactory.class.getName(), null);
      ctx.rebind(n.get(0), ref);
    } catch (NamingException e) {
      throw new IllegalStateException("No fue posible guardar en el árbol JNDI l recurso.", e);
    }
  }
}
