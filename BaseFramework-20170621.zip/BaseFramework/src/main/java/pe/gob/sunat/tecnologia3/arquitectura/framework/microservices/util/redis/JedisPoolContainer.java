package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.redis;

import lombok.Getter;
import lombok.Setter;
import redis.clients.jedis.JedisPool;

import javax.enterprise.inject.Vetoed;

/**
 * Created by domix on 11/8/16.
 */
@Getter
@Setter
@Vetoed
public class JedisPoolContainer {
  private JedisPool jedisPool;
}
