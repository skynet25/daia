package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config;

import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception.GenericException;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.PersistenceConfig.JNDI_CONFIG;

/**
 * Created by domix on 11/14/16.
 */
@Slf4j
public class ConfigService {
  @Produces
  @ApplicationScoped
  public PersistenceConfig getConfig() {
    return fromContext(PersistenceConfig.class, JNDI_CONFIG);
  }

  public <T> T getConfig(Class<T> configClass) {
    return fromContext(configClass, JNDI_CONFIG);
  }

  public <T> T fromContext(Class<T> configClass, String name) {
    InitialContext context;
    try {
      context = new InitialContext();
      return configClass.cast(context.lookup(name));
    } catch (NamingException e) {
      throw new GenericException(e.getMessage(), e);
    }
  }
}
