package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.cache;

import java.util.concurrent.TimeUnit;

import javax.cache.Cache;
import javax.cache.CacheManager;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.cache.RedisCacheConfiguration;

@ApplicationScoped
public class ConfiguracionCacheProducer {

  @Inject
  private CacheManager cacheManager;

  @Produces
  @Named("parametroCache")
  @ApplicationScoped
  public Cache<String, String> parametroCache() {
    return cacheManager.getCache("parametro");
  }
  
  
  @Produces
	@Named("gestorCache")
	@ApplicationScoped
	public Cache<String, String> gestorCache() {
		RedisCacheConfiguration redisCacheConfiguration = new RedisCacheConfiguration();
		Long numSecs = TimeUnit.HOURS.toSeconds(4);
		redisCacheConfiguration.setTtlInSeconds(Integer.valueOf(numSecs.toString()) );
		return cacheManager.createCache("gestor", redisCacheConfiguration);
	}
}
