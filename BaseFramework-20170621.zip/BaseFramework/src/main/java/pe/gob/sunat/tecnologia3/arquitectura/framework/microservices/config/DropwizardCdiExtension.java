package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config;

import com.google.common.collect.Sets;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import javax.enterprise.event.Observes;
import javax.enterprise.inject.spi.AfterBeanDiscovery;
import javax.enterprise.inject.spi.BeforeBeanDiscovery;
import javax.enterprise.inject.spi.Extension;
import javax.enterprise.inject.spi.ProcessAnnotatedType;
import java.util.Set;

@Slf4j
class DropwizardCdiExtension implements Extension {

  @Getter
  private final Set<String> names = Sets.newHashSet();

  void beforeBeanDiscovery(@Observes BeforeBeanDiscovery bbd) {
    log.info("============================> beginning the scanning process");
  }

  <T> void processAnnotatedType(@Observes ProcessAnnotatedType<T> pat) {
    final String name = pat.getAnnotatedType().getJavaClass().getName();
    log.info("============================> scanning type: {}", name);
    names.add(name);
  }

  void afterBeanDiscovery(@Observes AfterBeanDiscovery abd) {
    log.info("============================> finished the scanning process");
  }

}
