package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.model.bean;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MensajeExecBean extends MensajeBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private String exc;
}
