package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.batch;

import lombok.extern.slf4j.Slf4j;

import javax.crypto.Cipher;
import javax.enterprise.inject.Vetoed;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;


@Slf4j
@Vetoed
public class ArchivoZIP {

  private static final int BUFFER = 2048;

  private ArchivoZIP() {
    log.debug("No me puedes crear");
  }

  public static Map<String, Object> unZipEntryVarios(String sNombreBase, String rutafile, Map<String, String> datos) throws IOException {

    final String rutaFiles = new File(rutafile).getCanonicalPath().concat("\\");

    Map<String, Object> mapaLinea = new HashMap<>();

    String inFileName = rutaFiles.concat(sNombreBase.concat(".ZIP"));

    //1. Se obtiene contraseña a partir de nombre de archivo.
    String key = EncriptacionZIP.getSemilla(sNombreBase.substring(11, 43));// "17110125239157171141971761661982"
    //2. Se descomprime y se desencripta el archivo ZIP.
    datos.entrySet().stream().parallel().forEach(e -> unZipEntry(inFileName, rutaFiles.concat(sNombreBase.concat("_" + e.getValue() + "." + e.getValue())), key));
    //2. Se descomprime y se desencripta el contenido del archivo ZIP.
    datos.entrySet().stream().parallel().forEach(e -> unZipEntry(rutaFiles.concat(sNombreBase.concat("_" + e.getValue() + "." + e.getValue())).concat(".ZIP"), rutaFiles.concat(sNombreBase.concat("." + e.getValue())), null));
    //3. Leer Fichero Linea por Linea
    datos.entrySet().stream().parallel().forEach(e -> mapaLinea.put("" + e.getValue(), ArchivoZIP.leerFichero(rutaFiles.concat(sNombreBase.concat("." + e.getValue())), "" + e.getValue())));

    mapaLinea.forEach((k, v) -> log.debug("OUTPUT: Item : {}, Value : {}", k, v));

    return mapaLinea;
  }

  static int unZipEntry(String inFileName, String outFileName, String key) {
    int result = 0;
    ZipEntry entry;

    try (FileInputStream fis = new FileInputStream(inFileName);
         ZipInputStream zis = new ZipInputStream(new BufferedInputStream(fis))) {

      while ((entry = zis.getNextEntry()) != null) {
        String sNomFile = entry.getName();
        log.debug("Nombre: {}", sNomFile.substring(13));
        log.debug("Salida: {}", outFileName);
        // Se desencripta sólo la entrada indicada
        if (outFileName.contains(sNomFile.substring(13))) {
          log.info("Extracting: {}", entry);
          int count;
          byte data[] = new byte[BUFFER];

          try (FileOutputStream fos = new FileOutputStream(outFileName);
               BufferedOutputStream dest = new BufferedOutputStream(fos, BUFFER)) {
            while ((count = zis.read(data, 0, BUFFER)) != -1) {
              dest.write(data, 0, count);
            }
            dest.flush();
          }
          result = 1;

          if (key != null) {
            //Desencriptar Encriptar
            EncriptacionZIP.procesaArchivo(Cipher.DECRYPT_MODE, outFileName, outFileName.concat(".ZIP"), key);
            log.info("Proceso de desencriptación exitoso.");
            log.info("Archivo generado: {}", outFileName);
            log.info("Archivo generado .zip: {}", outFileName.concat(".ZIP"));
          }
        }

      }
    } catch (Exception e) {
      log.error(e.getMessage(), e);
    }

    return result;
  }

  static Map<String, Object> leerFichero(String outputFile, String extension) {
    log.debug("outputFile: {}", outputFile);
    log.debug("extension: {}", extension);

    Map<String, Object> mapaLinea = null;
    Integer conta = 0;
    try (FileReader fr = new FileReader(outputFile);
         BufferedReader br = new BufferedReader(fr)) {
      mapaLinea = new HashMap<>();

      // Lectura del fichero
      String linea;
      while ((linea = br.readLine()) != null) {
        linea = linea.trim();
        if (linea != null) {
          conta++;
          mapaLinea.put("" + conta, linea);
        }
      }

    } catch (Exception e) {
      log.error(e.getMessage(), e);
    }

    return mapaLinea;
  }

}
