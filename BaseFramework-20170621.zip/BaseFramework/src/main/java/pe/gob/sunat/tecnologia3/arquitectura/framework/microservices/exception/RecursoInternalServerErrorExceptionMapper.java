package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception;

import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.cdi.CdiService;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.MensajeDetalladoBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.service.MensajeService;

import javax.enterprise.inject.Vetoed;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.Arrays;
import java.util.Optional;

import static javax.ws.rs.core.Response.Status.INTERNAL_SERVER_ERROR;
import static javax.ws.rs.core.Response.status;
import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.util.MensajeUtil.obtenerMensaje;

@Vetoed
@Provider
@Slf4j
public class RecursoInternalServerErrorExceptionMapper implements ExceptionMapper<RuntimeException> {

  @Override
  public Response toResponse(RuntimeException exception) {
    Optional<MensajeService> facade = CdiService.getFacade(MensajeService.class);
    String codStatus = String.valueOf(INTERNAL_SERVER_ERROR.getStatusCode());
    MensajeDetalladoBean mensajeDetalladoBean = facade
      .map(servicio -> servicio
        .obtenerMensajeDetalle(codStatus, exception))
      .orElse(
        new MensajeDetalladoBean(
          codStatus, obtenerMensaje(codStatus), Arrays.toString(exception.getStackTrace())));

    return status(INTERNAL_SERVER_ERROR)
      .entity(mensajeDetalladoBean)
      .build();
  }

}
