package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.redis;

import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.RedisPoolRegistry;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Disposes;
import javax.enterprise.inject.Produces;

@Slf4j
@ApplicationScoped
public class JedisPoolFactory {
  public static final String JNDI_JEDIS_POOL = "java:/JedisPool";

  @ApplicationScoped
  @Produces
  public RedisPoolRegistry getRedisPoolRegistry() {
    return RedisPoolRegistry.getInstance();
  }


  public void destroyRedis(@Disposes RedisPoolRegistry jedisPoolContainers) {
    log.info("Destruyendo todos los Jedis Pool");
    if (jedisPoolContainers != null) {
      //TODO: liberar tal vez
    }
  }

}
