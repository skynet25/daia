package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util;

import lombok.extern.slf4j.Slf4j;

import javax.enterprise.inject.Vetoed;
import java.util.AbstractMap.SimpleEntry;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collector;

import static java.util.stream.Collectors.toConcurrentMap;
import static java.util.stream.Collectors.toMap;

/**
 * Created by domix on 2/22/17.
 */
@Slf4j
@Vetoed
public class CollectionsUtil {

  private CollectionsUtil() {
    log.debug("No puedes crearme.");
  }

  public static <K, V> Entry<K, V> entry(K key, V value) {
    return new SimpleEntry<>(key, value);
  }

  public static <K, U> Collector<Entry<K, U>, ?, Map<K, U>> entriesToMap() {
    return toMap(Entry::getKey, Entry::getValue);
  }

  public static <K, U> Collector<Entry<K, U>, ?, ConcurrentMap<K, U>> entriesToConcurrentMap() {
    return toConcurrentMap(Entry::getKey, Entry::getValue);
  }
}
