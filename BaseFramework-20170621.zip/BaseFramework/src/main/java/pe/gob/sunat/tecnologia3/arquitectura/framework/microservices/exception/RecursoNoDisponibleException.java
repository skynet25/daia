package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception;

/**
 * Created by Victor Ramos on 23/05/2017.
 */
public class RecursoNoDisponibleException extends RuntimeException {

    private final transient Object data;
    private final String codError;

    public RecursoNoDisponibleException(String message) {
        this(message, (Object)null);
    }

    public RecursoNoDisponibleException(Object data) {
        this("Error Generico", data);
    }

    public RecursoNoDisponibleException(String message, Throwable cause) {
        this(null, message, cause, null);
    }

    public RecursoNoDisponibleException(String codError, String message) {
        this(codError, message, null, null);
    }

    public RecursoNoDisponibleException(String message, Object data) {
        this(null, message, data);
    }

    public RecursoNoDisponibleException(String codError, String message, Object data) {
        this(codError, message, null, data);
    }

    public RecursoNoDisponibleException(String message, Throwable cause, Object data) {
        this(null, message, cause, data);
    }

    public RecursoNoDisponibleException(String codError, String message, Throwable cause, Object data) {
        super(message, cause);
        this.data = data;
        this.codError = codError;
    }
}
