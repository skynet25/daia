package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.jackson;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * Created by domix on 2/22/17.
 */
@Slf4j
public class JacksonFactory {
  @Setter
  private static ObjectMapper objectMapper = null;

  private JacksonFactory() {
    log.debug("No me puedes crear");
  }

  public static ObjectMapper getObjectMapper() {
    if (objectMapper == null) {
      objectMapper = new ObjectMapper();
    }

    return objectMapper;
  }

}
