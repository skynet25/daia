package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.batch;


import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception.BaseException;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.enterprise.inject.Vetoed;
import java.io.*;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;

@Slf4j
@Vetoed
public class EncriptacionZIP {

  private static final int IV_LENGTH = 16;

  private EncriptacionZIP() {
    log.debug("No crear esta clase.");
  }

  /**
   * @autor: JASS
   */
  public static byte[] encrypt(String plainText, String password) throws BaseException {
    ByteArrayInputStream bis; // Input
    try {
      bis = new ByteArrayInputStream(plainText.getBytes("UTF8"));
    } catch (UnsupportedEncodingException e) {
      throw new BaseException(e.getMessage(), e);
    }
    ByteArrayOutputStream bos = new ByteArrayOutputStream(); // Output
    // Se invoca a método de Encriptación AES
    encrypt(bis, bos, password);
    // Se retorna Byte Array encriptado
    return bos.toByteArray();
  }

  /**
   * @autor: JASS
   * @descripción: { Se invoca a método de desencriptación de Algoritmo AES
   * Retorna arreglo de bytes
   * }
   * plainText: Cadena de texto (binario) a ser desencriptado
   * password: Contraseña
   */
  public static byte[] decrypt(String cipherText, String password) throws BaseException {
    byte[] cipherTextBytes = cipherText.getBytes(); // Se transforma Input a arreglo de bytes
    ByteArrayInputStream bis = new ByteArrayInputStream(cipherTextBytes); // Input
    ByteArrayOutputStream bos = new ByteArrayOutputStream(); // Output
    // Se invoca a método de Desencriptación AES
    decrypt(bis, bos, password);
    // Se retorna Byte Array desencriptado
    return bos.toByteArray();
  }

  /**
   * @autor: JASS
   * @descripción: { Método de encriptación de Algoritmo AES
   * Retorna arreglo de bytes
   * }
   * in: Input Stream
   * out: Output Stream
   * password: Contraseña
   */
  public static void encrypt(InputStream in, OutputStream out, String password) throws BaseException {
    // Se calcula el parámetro IV (Inicialization Vector)
    SecureRandom r = new SecureRandom();
    byte[] iv = new byte[IV_LENGTH];
    r.nextBytes(iv); // Se calcula una cadena aleatoria
    // Se escribe la cadena IV en el Stream de salida al inicio
    try {
      out.write(iv);
      out.flush();
    } catch (IOException e) {
      throw new BaseException(e.getMessage(), e);
    }

    // Se inicializa la clase Cipher con el Algoritmo AES, utilizando CTS (Cipher Text Stealing) y NoPadding
    Cipher cipher = null;
    try {
      cipher = Cipher.getInstance("AES/CTS/NoPadding");
    } catch (GeneralSecurityException e) {
      throw new BaseException(e.getMessage(), e);
    }
    // Se transforma la cadena de contraseña a un Byte Array
    byte[] passw = hexStringToByteArray(password);
    // Se inicializa el SecretKey a ser utilizado con el Cipher, algoritmo AES
    SecretKey keySpec = new SecretKeySpec(passw, "AES");
    // Se inicializa el IvParameterSpec a ser utilizado con el Cipher, algoritmo AES
    IvParameterSpec ivSpec = new IvParameterSpec(iv);
    // Se inicializa el Cipher para Encriptar
    try {
      cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
    } catch (GeneralSecurityException e) {
      throw new BaseException(e.getMessage(), e);
    }
    // Se procede a ejecutar el algoritmo de encriptación a nivel del InputStream completo
    out = new CipherOutputStream(out, cipher);
    byte[] buf = new byte[1024];
    int numRead;
    try {
      while ((numRead = in.read(buf)) >= 0) {
        out.write(buf, 0, numRead);
      }
    } catch (IOException ex) {
      throw new BaseException(ex.getMessage(), ex);
    } finally {
      try {
        out.close();
      } catch (IOException e) {
        log.error("", e);
      }
    }
  }

  /**
   * @autor: JASS
   * @descripción: { Método de desencriptación de Algoritmo AES
   * Retorna arreglo de bytes
   * }
   * in: Input Stream
   * out: Output Stream
   * password: Contraseña
   */
  public static void decrypt(InputStream in, OutputStream out, String password) throws BaseException {

    // Se obtiene el parámetro IV (Inicialization Vector)
    byte[] iv = new byte[IV_LENGTH];
    // Se lee los primeros caracteres del InputStream
    try {
      in.read(iv);
    } catch (IOException e) {
      throw new BaseException(e.getMessage(), e);
    }

    // Se transforma la cadena de contraseña a un Byte Array
    byte[] passw = hexStringToByteArray(password);

    // Se inicializa el SecretKey a ser utilizado con el Cipher, algoritmo AES
    SecretKey keyValue = new SecretKeySpec(passw, "AES");
    // Se inicializa la clase Cipher con el Algoritmo AES, utilizando CTS (Cipher Text Stealing) y NoPadding
    Cipher cipher = null;
    try {
      cipher = Cipher.getInstance("AES/CTS/NoPadding");
    } catch (GeneralSecurityException e) {
      throw new BaseException(e.getMessage(), e);
    }
    // Se inicializa el IvParameterSpec a ser utilizado con el Cipher, algoritmo AES
    IvParameterSpec ivSpec = new IvParameterSpec(iv);
    // Se inicializa el Cipher para Encriptar
    try {
      cipher.init(Cipher.DECRYPT_MODE, keyValue, ivSpec);
    } catch (GeneralSecurityException e) {
      throw new BaseException(e.getMessage(), e);
    }
    // Se procede a ejecutar el algoritmo de desencriptación a nivel del InputStream completo
    InputStream in1 = new CipherInputStream(in, cipher);
    byte[] buf = new byte[1024];
    int numRead;
    try {
      while ((numRead = in1.read(buf)) >= 0) {
        out.write(buf, 0, numRead);
      }
    } catch (IOException e) {
      throw new BaseException(e.getMessage(), e);
    } finally {
      try {
        out.close();
      } catch (IOException e) {
        log.error(e.getMessage(), e);
      }
    }
  }

  /**
   * @autor: JASS
   * @descripción: { Método general que permite procesar Archivo y ejecutar acción de encriptar / desencriptar }
   * mode: Modo de operación (Encriptación / Desencriptación)
   * inputFile: Nombre de Archivo Input
   * outputFile: Nombre de Archivo Output
   * password: Contraseña
   */
  @SuppressWarnings("resource")
  public static void procesaArchivo(int mode, String inputFile, String outputFile, String password) throws BaseException {

    try (BufferedInputStream is = new BufferedInputStream(new FileInputStream(inputFile));
         BufferedOutputStream os = new BufferedOutputStream(new FileOutputStream(outputFile));) {
      if (mode == Cipher.ENCRYPT_MODE) {
        encrypt(is, os, password);
      } else if (mode == Cipher.DECRYPT_MODE) {
        decrypt(is, os, password);
      } else {
        throw new BaseException("Modo desconocido");
      }
    } catch (IOException e) {
      throw new BaseException(e.getMessage(), e);
    }
  }

  public static String getSemilla(String nroCon) {
    ClaveRC4 rcPDT = new ClaveRC4();
    String mod11 = rcPDT.generaKey(nroCon.substring(1, 16)).substring(1);
    log.debug("mod11: {}", mod11);
    return nroCon.substring(0, 1) + mod11 +
      nroCon.substring(16, nroCon.length() - 1);
  }


  public static byte[] hexStringToByteArray(String s) {
    int len = s.length();
    byte[] data = new byte[len / 2];
    for (int i = 0; i < len; i += 2) {
      data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
        + Character.digit(s.charAt(i + 1), 16));
    }
    return data;
  }

}
