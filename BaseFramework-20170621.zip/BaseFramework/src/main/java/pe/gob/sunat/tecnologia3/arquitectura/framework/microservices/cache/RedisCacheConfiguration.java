package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.cache;

import lombok.Getter;
import lombok.Setter;

import javax.cache.configuration.Configuration;

import static java.lang.Math.toIntExact;
import static java.util.concurrent.TimeUnit.DAYS;
import static java.util.concurrent.TimeUnit.MINUTES;

/**
 * Created by domix on 4/27/17.
 */
@Getter
@Setter
public class RedisCacheConfiguration<K, V> implements Configuration<K, V> {
  public static final int DEFAULT_DURATION_IN_MINUTES = 60;
  public static final int MIN_LIMIT = toIntExact(MINUTES.toSeconds(3));
  public static final int MAX_LIMIT = toIntExact(DAYS.toSeconds(3));
  private Integer ttlInSeconds = toIntExact(MINUTES.toSeconds(DEFAULT_DURATION_IN_MINUTES));

  @Override
  public Class<K> getKeyType() {
    return (Class<K>) String.class;
  }

  @Override
  public Class<V> getValueType() {
    return (Class<V>) Object.class;
  }

  @Override
  public boolean isStoreByValue() {
    return true;
  }
}
