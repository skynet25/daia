package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.jpa;

import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.ConfigService;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.cdi.CdiService;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.context.Initialized;
import javax.enterprise.event.Observes;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import static javax.persistence.SynchronizationType.SYNCHRONIZED;

/**
 * Created by domix on 5/4/17.
 */
@Slf4j
@ApplicationScoped
public class JpaEMInitializer {
  @Inject
  private ConfigService configService;

  public void init(@Observes @Initialized(ApplicationScoped.class) Object init) {
    CdiService
      .getFacades(EntityManagerFactory.class)
      .forEach(this::createEntityManager);
  }

  public EntityManager createEntityManager(EntityManagerFactory entityManagerFactory) {
    log.debug("Properties EMF: {}", entityManagerFactory.getProperties());

    EntityManager entityManager = entityManagerFactory
      .createEntityManager(SYNCHRONIZED);

    log.debug("Properties EM: {}", entityManager.getProperties());
    return entityManager;
  }
}
