package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util;

import lombok.extern.slf4j.Slf4j;

import javax.enterprise.inject.Vetoed;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;
import java.net.URI;

/**
 * Created by domix on 12/1/16.
 */
@Slf4j
@Vetoed
public class UriHelper {

  private UriHelper() {
    log.debug("No puedes crear esta clase");
  }

  public static URI getUriForId(@Context UriInfo uriInfo, Integer id) {
    UriBuilder builder = uriInfo.getAbsolutePathBuilder();
    builder.path(Integer.toString(id));
    return builder.build();
  }

  public static URI getUriForId(@Context UriInfo uriInfo, String id) {
    UriBuilder builder = uriInfo.getAbsolutePathBuilder();
    builder.path(id);
    return builder.build();
  }
}
