package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.cache;

import lombok.extern.slf4j.Slf4j;

import javax.cache.CacheException;
import javax.cache.CacheManager;
import javax.cache.configuration.OptionalFeature;
import javax.cache.spi.CachingProvider;
import javax.enterprise.inject.Vetoed;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.WeakHashMap;

/**
 * Created by domix on 2/24/17.
 */
@Slf4j
@Vetoed
public class RedisCachingProvider implements CachingProvider {
  public static final String CLOSING = "Closing...";
  protected final URI defaultURI;
  protected final ClassLoader defaultClassLoader;
  private final Map<ClassLoader, Map<URI, RedisCacheManager>> cacheManagers;

  public RedisCachingProvider() {
    //we use a WeakHashMap to prevent strong references to a classLoader to avoid memory leak.
    this.cacheManagers = new WeakHashMap<>();
    this.defaultClassLoader = this.getClass().getClassLoader();

    try {
      defaultURI = new URI("redis");
    } catch (URISyntaxException e) {
      throw new CacheException("Cannot create Default URI", e);
    }
  }

  @Override
  public CacheManager getCacheManager(URI uri, ClassLoader classLoader, Properties properties) {
    final URI managerURI = getManagerUri(uri);
    final ClassLoader managerClassLoader = getManagerClassLoader(classLoader);
    final Properties managerProperties = properties == null ? new Properties() : properties;
    synchronized (cacheManagers) {
      Map<URI, RedisCacheManager> cacheManagersByURI = cacheManagers.get(managerClassLoader);
      if (cacheManagersByURI == null) {
        cacheManagersByURI = new HashMap<>();
        cacheManagers.put(managerClassLoader, cacheManagersByURI);
      }
      RedisCacheManager cacheManager = cacheManagersByURI.get(managerURI);
      if (cacheManager == null || cacheManager.isClosed()) {
        try {
          cacheManager = createRedisCacheManager(uri, classLoader, managerProperties);
          cacheManagersByURI.put(managerURI, cacheManager);
        } catch (Exception e) {
          throw new CacheException("Error opening URI [" + managerURI.toString() + "]", e);
        }
      }
      return cacheManager;
    }
  }

  private RedisCacheManager createRedisCacheManager(URI uri, ClassLoader classLoader, Properties managerProperties) {
    return new RedisCacheManager(this, uri, classLoader, managerProperties);
  }

  @Override
  public ClassLoader getDefaultClassLoader() {
    return this.defaultClassLoader;
  }

  @Override
  public URI getDefaultURI() {
    return this.defaultURI;
  }

  @Override
  public Properties getDefaultProperties() {
    return null;
  }

  @Override
  public CacheManager getCacheManager(URI uri, ClassLoader classLoader) {
    return createRedisCacheManager(uri, classLoader, null);
  }

  @Override
  public CacheManager getCacheManager() {
    return null;
  }

  @Override
  public void close() {
    log.debug(CLOSING);
  }

  @Override
  public void close(ClassLoader classLoader) {
    log.debug(CLOSING);
  }

  @Override
  public void close(URI uri, ClassLoader classLoader) {
    log.debug(CLOSING);
  }

  @Override
  public boolean isSupported(OptionalFeature optionalFeature) {
    return false;
  }

  protected URI getManagerUri(URI uri) {
    return uri == null ? defaultURI : uri;
  }

  protected ClassLoader getManagerClassLoader(ClassLoader classLoader) {
    return classLoader == null ? defaultClassLoader : classLoader;
  }
}
