package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception;

import lombok.Getter;

@Getter
public class GenericException extends RuntimeException {

  private final transient Object data;
  private final String codError;

  public GenericException(String message) {
    this(message, (Object)null);
  }

  public GenericException(Object data) {
    this("Error Generico", data);
  }

  public GenericException(String message, Throwable cause) {
    this(null, message, cause, null);
  }

  public GenericException(String codError, String message) {
    this(codError, message, null, null);
  }

  public GenericException(String message, Object data) {
    this(null, message, data);
  }

  public GenericException(String codError, String message, Object data) {
    this(codError, message, null, data);
  }

  public GenericException(String message, Throwable cause, Object data) {
    this(null, message, cause, data);
  }

  public GenericException(String codError, String message, Throwable cause, Object data) {
    super(message, cause);
    this.data = data;
    this.codError = codError;
  }

}
