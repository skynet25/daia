package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.cache;

import com.lambdaworks.redis.api.StatefulRedisConnection;
import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.ConfigService;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.PersistenceConfig;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.RedisCluster;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.RedisPoolRegistry;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.lettuce.LettuceConfig;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception.GenericException;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.cdi.CdiService;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.redis.lettuce.LettuceOperationCommand;

import javax.cache.Cache;
import javax.cache.CacheManager;
import javax.cache.configuration.CacheEntryListenerConfiguration;
import javax.cache.configuration.Configuration;
import javax.cache.integration.CompletionListener;
import javax.cache.processor.EntryProcessor;
import javax.cache.processor.EntryProcessorResult;
import java.util.*;
import java.util.function.Function;

import static java.lang.String.format;
import static java.util.Objects.requireNonNull;

/**
 * Created by domix on 2/24/17.
 */
@Slf4j
@SuppressWarnings("unchecked")
public class RedisCache<K, V> implements Cache<K, V> {

  private final String name;
  private final CacheManager cacheManager;
  private final RedisCacheConfiguration configuration;
  private final RedisPoolRegistry redisPoolRegistry;
  private final PersistenceConfig persistenceConfig;
  private final Integer redisReadTimeoutInMilliseconds;
  private final Integer maxConcurrentRequests;

  public RedisCache(String name, CacheManager cacheManager, RedisCacheConfiguration<K, V> configuration, RedisPoolRegistry redisPoolRegistry) {
    requireNonNull(name, "El nombre del cache es requerido");
    requireNonNull(cacheManager, "El cacheManager es requerido");
    requireNonNull(configuration, "La configuración es requerida");
    requireNonNull(redisPoolRegistry, "El RedisPoolRegistry es requerido");
    requireNonNull(configuration.getTtlInSeconds(), "El tiempo de expiración de las llaves es requerido.");

    this.redisPoolRegistry = redisPoolRegistry;
    this.name = name;
    this.cacheManager = cacheManager;
    this.configuration = configuration;
    this.persistenceConfig = CdiService.getFacade(ConfigService.class)
      .orElseThrow(() -> new RuntimeException("Imposible, but who knows...")).getConfig();

    RedisCluster redisCluster = persistenceConfig.getRedis();

    requireNonNull(redisCluster, "La configuración del RedisCluster es requerida");

    redisReadTimeoutInMilliseconds = redisCluster.getReadTimeoutInMilliseconds();
    maxConcurrentRequests = redisCluster.getMaxConcurrentRequests();
  }

  private String realKey(K key) {
    return format("%s/%s", name, key.toString());
  }

  private <T> T doLettuceWriteOperation(Function<StatefulRedisConnection<String, String>, Void> callback) {
    log.info("Lettuce, se escribe");

    redisPoolRegistry.getLettuceConfigs().forEach(lettuceConfig -> {
      boolean proceed;
      try {
        StatefulRedisConnection<String, String> connect = lettuceConfig.getConnect();
        if (connect != null && !connect.isOpen()) {
          lettuceConfig.setConnect(lettuceConfig.getClient().connect());
        }
      } catch (Throwable T) {
      }

      StatefulRedisConnection<String, String> connect = lettuceConfig.getConnect();
      proceed = connect != null && connect.isOpen();

      if (proceed) {
        new LettuceOperationCommand<>(lettuceConfig.getConnect(), callback,
          redisReadTimeoutInMilliseconds, maxConcurrentRequests)
          .execute();
      } else {
        log.warn("No se ejecuta la operacion en {}", lettuceConfig.getClient().toString());
      }


    });
    return null;
  }


  private <T> T doLettuceReadOperation(Function<StatefulRedisConnection<String, String>, T> callback) {
    log.info("Leyendo con Lettuce");
    //iterar hasta encontrar el resultado o hasta que se haya acabado los nodos
    boolean foundOrNoMoreAvailableNodes = false;
    T result = null;

    LettuceConfig config = redisPoolRegistry.getPrimaryLettucePool()
      .orElseThrow(() -> new RuntimeException("No se encontro el primario"));

    while (!foundOrNoMoreAvailableNodes) {
      log.debug("Lettuce: Se usara nodo {}", config.getPriority());

      boolean proceed;
      try {
        StatefulRedisConnection<String, String> connect = config.getConnect();
        if (connect != null && !connect.isOpen()) {
          config.setConnect(config.getClient().connect());
        }
      } catch (Throwable T) {
      }

      StatefulRedisConnection<String, String> connect = config.getConnect();
      proceed = connect != null && connect.isOpen();

      if (proceed) {
        result = new LettuceOperationCommand<>(config.getConnect(), callback, redisReadTimeoutInMilliseconds, maxConcurrentRequests).execute();
      }

      if (result == null) {

        log.debug("Lettuce No se encontro en el nodo {}, se procede a seguir buscando.", config.getPriority());
        Optional<LettuceConfig> nextLettuceConfig = redisPoolRegistry.getLettucePool(config.getPriority());

        if (nextLettuceConfig.isPresent()) {
          log.debug("Lettuce: Hay otro nodo disponible.");
          config = nextLettuceConfig.get();
        } else {
          log.debug("Lettuce: Ya no hay mas nodos, se regresa.");
          foundOrNoMoreAvailableNodes = true;
        }
      } else {
        foundOrNoMoreAvailableNodes = true;
      }

    }
    return result;
  }


  @Override
  public V get(K key) {
    List<LettuceConfig> lettuceConfigs = redisPoolRegistry.getLettuceConfigs();
    if (lettuceConfigs == null) {
      throw new GenericException("Se debe configurar apropiadamente Lettuce");
    } else {
      return (V) doLettuceReadOperation(connection -> {
        String realKey = realKey(key);
        log.debug("Lettuce: Obteniendo del cache '{}' la llave '{}'. Llave real '{}'", name, key, realKey);
        return connection.sync().get(realKey);
      });

    }
  }

  @Override
  public Map<K, V> getAll(Set<? extends K> keys) {
    unsupportedFeature();
    return null;
  }

  private void unsupportedFeature() {
    throw new UnsupportedOperationException("No esta soportado este tipo de operación");
  }

  @Override
  public boolean containsKey(K key) {
    List<LettuceConfig> lettuceConfigs = redisPoolRegistry.getLettuceConfigs();

    if (lettuceConfigs == null) {
      throw new GenericException("Se debe configurar apropiadamente Lettuce");
    } else {
      log.info("Se usa Lettuce para buscar");
      Boolean aBoolean = doLettuceReadOperation(connection -> {
        //log.debug("Intentado hacer GET con {}", jedis);
        //Objects.requireNonNull(jedis, "El jedis es nulo.");
        log.info("Lettuce: contaninsKey?");
        String realKey = realKey(key);
        Boolean exists = connection.sync().exists(realKey);
        log.debug("Lettuce: Buscando en el cache '{}' la llave '{}'. Llave real '{}'. ¿Encontrada?: {}", name, key, realKey, exists);
        return exists;
      });
      return aBoolean != null && aBoolean;
    }

  }

  @Override
  public void loadAll(Set<? extends K> keys, boolean replaceExistingValues, CompletionListener completionListener) {
    unsupportedFeature();
  }

  @Override
  public void put(K key, V value) {
    List<LettuceConfig> lettuceConfigs = redisPoolRegistry.getLettuceConfigs();
    if (lettuceConfigs == null) {
      throw new GenericException("Se debe configurar apropiadamente Lettuce");
    } else {
      doLettuceWriteOperation(connection -> {
        String realKey = realKey(key);

        int seconds = configuration.getTtlInSeconds();
        log.debug("Lettuce: Guardando en el cache '{}' la llave '{}'. Llave real '{}'. Con '{}' segundos de timeout", name, key, realKey, seconds);

        connection.sync().set(realKey, value.toString());
        connection.sync().expire(realKey, seconds);
        // TODO: tal vez intentar leer del nodo de lectura y bloquear hasta que el valor sea obtenido. Esto para asegurar que se replico correctamente.
        return null;
      });
    }
  }

  @Override
  public V getAndPut(K key, V value) {
    unsupportedFeature();
    return null;
  }

  @Override
  public void putAll(Map<? extends K, ? extends V> map) {
    unsupportedFeature();
  }

  @Override
  public boolean putIfAbsent(K key, V value) {
    if (!containsKey(key)) {
      put(key, value);
      return true;
    } else {
      return false;
    }
  }

  @Override
  public boolean remove(K key) {
    List<LettuceConfig> lettuceConfigs = redisPoolRegistry.getLettuceConfigs();

    if (lettuceConfigs == null) {
      throw new GenericException("Se debe configurar apropiadamente Lettuce");
    } else {
      doLettuceWriteOperation(connection -> {
        String realKey = realKey(key);
        boolean result = connection.sync().del(realKey(key)) > 0;
        log.debug("Borrando del cache '{}' la llave '{}'. Llave real '{}'. ¿Borrado?: {}", name, key, realKey, result);
        return null;
      });
      return true;
    }
  }

  @Override
  public boolean remove(K key, V oldValue) {
    return get(key).equals(oldValue) && remove(key);
  }

  @Override
  public V getAndRemove(K key) {
    if (containsKey(key)) {
      V oldValue = get(key);
      remove(key);
      return oldValue;
    } else {
      return null;
    }
  }

  @Override
  public boolean replace(K key, V oldValue, V newValue) {
    if (containsKey(key) && get(key).equals(oldValue)) {
      put(key, newValue);
      return true;
    } else {
      return false;
    }
  }

  @Override
  public boolean replace(K key, V value) {
    if (containsKey(key)) {
      put(key, value);
      return true;
    } else {
      return false;
    }
  }

  @Override
  public V getAndReplace(K key, V value) {
    if (containsKey(key)) {
      V oldValue = get(key);
      put(key, value);
      return oldValue;
    } else {
      return null;
    }
  }

  @Override
  public void removeAll(Set<? extends K> keys) {
    keys.forEach(this::remove);
  }

  @Override
  public void removeAll() {
    unsupportedFeature();
  }

  @Override
  public void clear() {
    unsupportedFeature();
  }

  @Override
  public <C extends Configuration<K, V>> C getConfiguration(Class<C> clazz) {
    unsupportedFeature();
    return null;
  }

  @Override
  public <T> T invoke(K key, EntryProcessor<K, V, T> entryProcessor, Object... arguments) {
    unsupportedFeature();
    return null;
  }

  @Override
  public <T> Map<K, EntryProcessorResult<T>> invokeAll(Set<? extends K> keys, EntryProcessor<K, V, T> entryProcessor, Object... arguments) {
    unsupportedFeature();
    return null;
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public CacheManager getCacheManager() {
    return cacheManager;
  }

  @Override
  public void close() {
    unsupportedFeature();
  }

  @Override
  public boolean isClosed() {
    return redisPoolRegistry.getPrimaryConnection()
      .map(connection -> !connection.isOpen())
      .orElse(true);
  }

  @Override
  public <T> T unwrap(Class<T> clazz) {
    return clazz.cast(redisPoolRegistry.getLettuceConfigs());
  }

  @Override
  public void registerCacheEntryListener(CacheEntryListenerConfiguration<K, V> cacheEntryListenerConfiguration) {
    unsupportedFeature();
  }

  @Override
  public void deregisterCacheEntryListener(CacheEntryListenerConfiguration<K, V> cacheEntryListenerConfiguration) {
    unsupportedFeature();
  }

  @Override
  public Iterator<Entry<K, V>> iterator() {
    unsupportedFeature();
    return null;
  }

}
