package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception;

import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.cdi.CdiService;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.ParametroBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.service.MensajeService;

import javax.enterprise.inject.Vetoed;
import javax.ws.rs.NotAcceptableException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.Optional;

import static javax.ws.rs.core.Response.Status.FORBIDDEN;
import static javax.ws.rs.core.Response.Status.NOT_ACCEPTABLE;
import static javax.ws.rs.core.Response.status;
import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.util.MensajeUtil.obtenerMensaje;

@Vetoed
@Provider
public class RecursoNotAcceptableExceptionMapper implements ExceptionMapper<NotAcceptableException> {

  @Override
  public Response toResponse(NotAcceptableException exception) {

    Optional<MensajeService> facade = CdiService.getFacade(MensajeService.class);
    String codStatus = String.valueOf(NOT_ACCEPTABLE.getStatusCode());
    ParametroBean parametroBean = facade
      .map(servicio -> servicio
        .obtenerMensaje(codStatus))
      .orElse(new ParametroBean(codStatus, obtenerMensaje(codStatus)));

    return status(NOT_ACCEPTABLE)
      .entity(parametroBean)
      .build();
  }
}
