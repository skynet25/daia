package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config;

import lombok.Getter;
import lombok.Setter;

import javax.enterprise.inject.Vetoed;
import java.util.List;

/**
 * Created by domix on 5/29/17.
 */
@Getter
@Setter
@Vetoed
public class RedisCluster {
  private List<RedisConfig> clusters;

  /**
   * El tiempo máximo de espera para obtener respuesta antes de intentar el siguiente cluster.
   */
  private Integer readTimeoutInMilliseconds = 200;

  /**
   * Cantidad máxima de peticiones concurrentes a Redis
   */
  private Integer maxConcurrentRequests = 300;
}
