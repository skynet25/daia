package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config;

import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.redis.JedisPoolFactory.JNDI_JEDIS_POOL;

/**
 * Created by domix on 4/26/17.
 */
public enum RedisNodeType {
  WRITE, READ;

  public static String jndi(RedisNodeType nodeType) {
    return String.format("%s_%s", JNDI_JEDIS_POOL, nodeType.name());
  }

  public String jndi() {
    return jndi(this);
  }
}
