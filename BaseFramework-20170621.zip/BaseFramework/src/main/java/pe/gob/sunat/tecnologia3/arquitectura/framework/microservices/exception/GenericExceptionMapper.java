package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception;

import javax.enterprise.inject.Vetoed;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import static javax.ws.rs.core.Response.Status.NOT_ACCEPTABLE;

@Vetoed
@Provider
public class GenericExceptionMapper implements ExceptionMapper<GenericException> {
  @Override
  public Response toResponse(GenericException exception) {
    return Response.status(NOT_ACCEPTABLE)
      .entity(exception.getData())
      .build();
  }
}
