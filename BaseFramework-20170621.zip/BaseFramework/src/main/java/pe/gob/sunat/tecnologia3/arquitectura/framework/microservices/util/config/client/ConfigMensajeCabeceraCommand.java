package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.client;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import lombok.extern.slf4j.Slf4j;
import okhttp3.ResponseBody;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.JsonUtilParser;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.MensajeBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.ParametroBean;
import retrofit2.Call;

import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.util.MensajeUtil.obtenerMensaje;

/**
 * Created by domix on 5/15/17.
 */
@Slf4j
public class ConfigMensajeCabeceraCommand extends HystrixCommand<ParametroBean> {

  private final ServicioConfiguracionRemoto servicioConfiguracionRemoto;
  private final JsonUtilParser jsonUtilParser;
  private final String codTabla;

  public ConfigMensajeCabeceraCommand(ServicioConfiguracionRemoto servicioConfiguracionRemoto, JsonUtilParser jsonUtilParser, String codTabla) {
    super(HystrixCommandGroupKey.Factory.asKey("ConfigService"));
    this.servicioConfiguracionRemoto = servicioConfiguracionRemoto;
    this.jsonUtilParser = jsonUtilParser;
    this.codTabla = codTabla;
  }

  @Override
  protected ParametroBean run() throws Exception {
    log.info("Haciendo peticion");
    Call<ParametroBean> callResumen = servicioConfiguracionRemoto.obtenerMensajeCabecera(codTabla);
    return ConfigServiceRestClient.getParametroBean(callResumen);
  }

  @Override
  protected ParametroBean getFallback() {
    if(getFailedExecutionException() != null) {
      log.debug(getFailedExecutionException().getMessage(), getFailedExecutionException());
    }
    if (getExecutionException() != null) {
      log.debug(getExecutionException().getMessage(), getExecutionException());
    }
    log.info(">>>>> CIRCUITO ABIERTO");
    return new ParametroBean(codTabla, obtenerMensaje(codTabla));
  }
}
