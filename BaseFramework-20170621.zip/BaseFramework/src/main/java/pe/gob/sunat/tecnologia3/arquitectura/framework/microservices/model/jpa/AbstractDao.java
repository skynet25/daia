package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.model.jpa;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception.GenericException;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception.ObjectNotFoundException;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception.ValidationException;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static java.util.Collections.unmodifiableMap;
import static java.util.Objects.requireNonNull;
import static java.util.stream.Stream.of;
import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.CollectionsUtil.entriesToMap;
import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.CollectionsUtil.entry;

@Slf4j
public abstract class AbstractDao<T, Id> implements BaseDao<T, Id> {

  private static final String QUERY_SELECT_ALL = "SELECT o FROM %s o ORDER BY 1";

  @Getter
  private EntityManager entityManager;

  @Getter
  protected Class<T> entityClass;

  public abstract EntityManager buildEntityManager();

  public abstract Class<T> provideEntityClass();

  @PostConstruct
  public void init() {
    log.info("Init Dao: {}", this.getClass().getName());

    this.entityManager = buildEntityManager();
    this.entityClass = provideEntityClass();
  }

  public static <T extends AbstractDao> T createDao(Class<T> daoClass, EntityManager entityManager) {
    requireNonNull(daoClass, "Es requerido el tipo del DAO.");
    requireNonNull(entityManager, "Es requerido el EntityManager.");

    AbstractDao abstractDao;
    try {
      abstractDao = daoClass.newInstance();
    } catch (InstantiationException | IllegalAccessException e) {
      Map<String, Object> additionalFields = unmodifiableMap(of(entry("daoClass", daoClass.getClass().getName())).collect(entriesToMap()));

      throw new GenericException(e.getMessage(), e, additionalFields);
    }

    abstractDao.init();
    abstractDao.entityManager = entityManager;
    return daoClass.cast(abstractDao);
  }

  @Override
  public T save(final T object) {
    return save(object, true);
  }

  @Override
  public T save(final T object, Boolean flush) {
    try {
      entityManager.persist(object);
      if (flush) {
        entityManager.flush();
      }

    } catch (javax.validation.ConstraintViolationException violation) {
      throw new ValidationException(violation);
    }

    return object;
  }

  @Override
  public T findById(final Id id) {
    T t = entityManager.find(entityClass, id);
    if (t == null) {
      throw new ObjectNotFoundException("No se encontro la entidad**");
    }
    return t;
  }

  @Override
  public List<T> findByNamedQuery(String queryName, String paramName, Object paramValue) {
    return findByQuery(createNamedQuery(queryName).setParameter(paramName, paramValue));
  }

  @Override
  public List<T> findAll() {
    final String query = String.format(QUERY_SELECT_ALL, entityClass.getSimpleName());
    return findByQuery(entityManager.createQuery(query));
  }

  @Override
  public List<T> findByQuery(Query query) {
    return (List<T>) query.getResultList();
  }

  @Override
  public Optional<T> findSingle(Query query) {
    T singleResult;

    try {
      singleResult = (T) query.getSingleResult();
    } catch (NoResultException nr) {
      singleResult = null;
      log.warn("No se encontro", nr);
    }

    return Optional.ofNullable(singleResult);
  }

  @Override
  public List<T> find(Integer pageNumber, Integer pageSize) {
    log.debug("PageNumber {}", pageNumber);
    log.debug("pageSize   {}", pageSize);
    final String queryStr = String.format(QUERY_SELECT_ALL, entityClass.getSimpleName());

    int size = pageSize > 100 ? 100 : pageSize;
    int page = pageNumber <= 0 ? 1 : pageNumber;

    return findByQuery(entityManager.createQuery(queryStr).setFirstResult((page - 1) * size).setMaxResults(size));
  }

  @Override
  public Query createNativeQuery(String queryStr) {
    return entityManager.createNativeQuery(queryStr);
  }

  @Override
  public void delete(final T object) {
    entityManager.remove(object);
  }

  @Override
  public <Id> void deleteById(final Id id) {
    entityManager.remove(entityManager.find(entityClass, id));
  }

  @Override
  public <T> T update(T entity) {
    return entityManager.merge(entity);
  }

  @Override
  public Query createQuery(String qlString) {
    return entityManager.createQuery(qlString);
  }

  @Override
  public Query createNamedQuery(String name) {
    return entityManager.createNamedQuery(name);
  }

  @Override
  public Query createNativeQuery(String sqlString, Class resultClass) {
    return entityManager.createNativeQuery(sqlString, resultClass);
  }

  @Override
  public void clear() {
    entityManager.clear();
  }

  @Override
  public <T> T find(Class<T> entityClass, Object primaryKey) {
    return entityManager.find(entityClass, primaryKey);
  }

}
