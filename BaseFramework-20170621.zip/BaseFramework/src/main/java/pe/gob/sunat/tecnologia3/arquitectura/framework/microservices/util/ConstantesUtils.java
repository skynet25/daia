package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util;

import lombok.extern.slf4j.Slf4j;

import javax.enterprise.inject.Vetoed;

@Slf4j
@Vetoed
public class ConstantesUtils {

	public static final Character ESTADO_ACTIVO = '0';
	public static final Character ESTADO_INACTIVO = '1';
	
	public static final Character OPERACION_AUTOMATICO = '2';
	public static final Character OPERACION_MANUAL = '1';
	
	/** RVENTOCILLAM 
	 * 
	 * LOS CODIGOS QUE SE MUESTRAN A CONTINUACION PERTENECEN A PARAMETRIA PASARELA,
	 * QUE SEGUN CONSULTAS HECHAS A COSAPI SE INDICARON, COMO EJEMPLO
	 * 
	 * **/
	public static final String COD_APLI_PASARELA= "1120"; // codigo de los aplicativos que usan parametria pasarela
	public static final String COD_FORM_PASARELA= "1117"; // codigo de formularios
	public static final String COD_TRIB_PASARELA= "1118"; // codigo de tributos
	public static final String COD_FORM_TRIB_PASARELA= "1119"; // codigo de tributos por formulario

	/**  
	 * RVENTOCILLAM
	 * Consulta de Parametros externos
	 * 
	 * **/
	public static final String COD_PARAMETROS_EXTERNOS= "3333";

	private ConstantesUtils() {
		log.debug("No puedes crear esta clase.");
	}
}
