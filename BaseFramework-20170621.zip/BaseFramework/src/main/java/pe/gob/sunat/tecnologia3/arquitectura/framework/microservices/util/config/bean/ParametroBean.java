package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean;

import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties({ "indMsjPred", "desTabla" })
public class ParametroBean extends MensajeBean {

	private String desTabla;

	// 0 msjEncontrado, 1 Default
	@Transient
	private int indMsjPred;

	public ParametroBean(String cod, String msg, String desTabla, int indMsjPred) {
		super(cod, desTabla);
		this.desTabla = desTabla;
		this.indMsjPred = indMsjPred;
	}

	public ParametroBean(String cod, String valParam, String desTabla) {
		super(cod, desTabla);
		this.desTabla = desTabla;
	}

	public ParametroBean(String cod, String msg, int indMsjPred) {
		super(cod, msg);
		this.indMsjPred = indMsjPred;
	}

	public ParametroBean(String cod, String msg) {
		super(cod, msg);
	}

	public ParametroBean() {
		super();
	}
}
