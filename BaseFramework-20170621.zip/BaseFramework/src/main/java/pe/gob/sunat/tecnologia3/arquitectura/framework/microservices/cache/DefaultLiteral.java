package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.cache;

import javax.enterprise.inject.Default;
import javax.enterprise.inject.Vetoed;
import javax.enterprise.util.AnnotationLiteral;

/**
 * Created by domix on 2/24/17.
 */
@Vetoed
public class DefaultLiteral extends AnnotationLiteral<Default> implements Default {
  public static final DefaultLiteral INSTANCE = new DefaultLiteral();

  @Override
  public String toString() {
    return "@javax.enterprise.inject.Default()";
  }
}
