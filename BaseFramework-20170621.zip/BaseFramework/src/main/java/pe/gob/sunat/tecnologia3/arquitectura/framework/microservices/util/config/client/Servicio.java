package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.client;

import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.MensajeBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.MensajePersonalizadoBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.ParametroBean;

import javax.inject.Inject;

public class Servicio {
  @Inject
  private ConfigServiceRestClient configServiceRestClient;

  public ParametroBean obtenerMensajeCabecera(String codTabla) {
    return configServiceRestClient.consumirObtenerMensajeCabecera(codTabla);
  }

  public MensajePersonalizadoBean obtenerListaMensajes(String codTabla, String codParam) {
    return configServiceRestClient.consumirObtenerListaMensaje(codTabla, codParam);
  }

  public ParametroBean obtenerMensajeDetalle(String codTabla, String codParam) {
    return configServiceRestClient.consumirObtenerMensajeDetalle(codTabla, codParam);
  }
}
