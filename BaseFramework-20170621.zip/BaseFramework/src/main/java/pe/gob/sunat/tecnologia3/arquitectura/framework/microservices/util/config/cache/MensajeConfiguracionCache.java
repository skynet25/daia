package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.cache;

import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.ParametroBean;

import javax.cache.Cache;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@ApplicationScoped
public class MensajeConfiguracionCache {

  @Inject
  @Named("parametroCache")
  Cache<String, String> parametroCache;

  public Optional<ParametroBean> getParametroCache(String key) {
    try {
      if (parametroCache.containsKey(key)) {
        String valParam = parametroCache.get(key);
        return Optional.ofNullable(new ParametroBean(key, valParam));
      }
    } catch (Throwable t) {
      log.debug(t.getMessage(), t);
    }
    return Optional.empty();
  }

  public List<ParametroBean> getListParametroCache(List<String> listaKey) {
    return listaKey.stream()
      .map(key ->
        getParametroCache(key)
          .orElse(new ParametroBean()))
      .filter(Objects::nonNull)
      .collect(Collectors.toList());
  }

  public void saveParametroCache(String key, String valParam) {
    parametroCache.put(key, valParam);
  }

  public void saveListParametroCache(List<ParametroBean> listaParametros) {
    for (ParametroBean parametro : listaParametros) {
      parametroCache.put(parametro.getCod(), parametro.getMsg());
    }
  }

  public void deleteParametroCache(String key) {
    parametroCache.remove(key);
  }

  public void deleteParametroCache() {
    parametroCache.removeAll();
  }
}
