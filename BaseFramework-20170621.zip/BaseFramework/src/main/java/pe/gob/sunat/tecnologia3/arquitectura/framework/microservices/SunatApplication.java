package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices;

import com.arjuna.ats.internal.jta.transaction.arjunacore.TransactionManagerImple;
import com.arjuna.ats.internal.jta.transaction.arjunacore.TransactionSynchronizationRegistryImple;
import com.arjuna.ats.internal.jta.transaction.arjunacore.UserTransactionImple;
import com.arjuna.ats.jta.common.jtaPropertyManager;
import com.codahale.metrics.ConsoleReporter;
import com.codahale.metrics.MetricRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lambdaworks.redis.RedisClient;
import com.lambdaworks.redis.RedisURI;
import com.lambdaworks.redis.api.StatefulRedisConnection;
import com.lambdaworks.redis.support.ConnectionPoolSupport;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.elasticsearch.metrics.ElasticsearchReporter;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.*;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.lettuce.LettuceConfig;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception.*;
//import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.filtro.modelo.Configuracion;
//import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.filtro.servicio.JavaFiltro;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.cdi.CdiResource;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.jackson.JacksonFactory;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.jersey.ServiceDataFilter;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.metrics.DataHealthCheck;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.metrics.MetricsCdi;

import javax.naming.InitialContext;
import javax.servlet.DispatcherType;
import javax.transaction.TransactionManager;
import javax.transaction.TransactionSynchronizationRegistry;
import javax.transaction.UserTransaction;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;

import static com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES;
import static java.util.Collections.unmodifiableMap;
import static java.util.Optional.ofNullable;
import static java.util.concurrent.TimeUnit.MILLISECONDS;
import static java.util.concurrent.TimeUnit.SECONDS;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Stream.of;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.PersistenceConfig.JNDI_CONFIG;
import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.CollectionsUtil.entriesToMap;
import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.CollectionsUtil.entry;
import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.JndiUtils.bind;

/**
 * Created by domix on 11/4/16.
 */
@Slf4j
public abstract class SunatApplication<T extends MicroserviceConfig> extends BaseApplication<T> {
  public static final String CURRENT_VERSION = SunatApplication.class.getPackage().getImplementationVersion();

  @Override
  public final void run(T configuration, Environment environment) throws Exception {
    InitialContext initialContext = new InitialContext();

    configureObjectMapper(environment);
    configureApplication(configuration);
    bind(JNDI_CONFIG, configuration, configuration.getClass(), initialContext);
    configureTransactionInfrastructure(initialContext);
    configureDataSources(configuration, environment, initialContext);
    configureRedis(configuration, environment, initialContext);
    configureMetrics(configuration, environment);
    configureServiceDataHealthChecks(configuration, environment);
    configureDefaultExceptionsMappers(environment);
    configureCdiDebugComponents(configuration, environment);

    SecurityFilterConfig securityConfig = configuration.getSecurity();
    if (securityConfig != null && securityConfig.getActivateSecurityFilter()) {
    	/*
      Configuracion configuracionJavaFilter = new Configuracion();
      configuracionJavaFilter.setReintentoInvocacionGestorSesion(securityConfig.getReintentosInvocacionGestorSesiones());
      environment.servlets().addFilter("JavaFilter", new JavaFiltro(configuracionJavaFilter)).addMappingForUrlPatterns(EnumSet.of(DispatcherType.REQUEST), true, "/*");
      */
    }

    //invocar el metodo del microservicio
    onRun(configuration, environment);
  }

  private void configureCdiDebugComponents(T configuration, Environment environment) {
    if (configuration.getCdiResource()) {
      environment.jersey().register(CdiResource.class);
    }

    if (configuration.getIncludeServiceInfoInResponses()) {
      environment.jersey().register(ServiceDataFilter.class);
    }
  }

  private void configureServiceDataHealthChecks(T configuration, Environment environment) {
    if (configuration.getRegisterServiceDataHealthChecks()) {
      environment.healthChecks().register("serviceName", new DataHealthCheck(configuration.getServiceName()));
      environment.healthChecks().register("serviceVersion", new DataHealthCheck(configuration.getVersion()));
      environment.healthChecks().register("serviceEnvironment", new DataHealthCheck(configuration.getEnvironment()));
      environment.healthChecks().register("serviceInstanceId", new DataHealthCheck(configuration.getInstanceId()));
    }
  }

  private void configureApplication(T configuration) {
    String instanceId = randomAlphabetic(configuration.getMetricsConfig().getLenghtRandomReplicaId());
    configuration.setInstanceId(instanceId);
    configuration.setVersion(CURRENT_VERSION);
  }

  private void configureObjectMapper(Environment environment) {
    ObjectMapper objectMapper = environment.getObjectMapper();
    objectMapper.configure(FAIL_ON_UNKNOWN_PROPERTIES, false);
    JacksonFactory.setObjectMapper(objectMapper);
  }

  private void configureDataSources(T configuration, Environment environment, InitialContext initialContext) {
    ofNullable(configuration.getDataSources())
      .ifPresent(dataSourceConfigs -> dataSourceConfigs.stream().forEach(dataSourceConfig -> {
        if (dataSourceConfig.getXaDataSourceClassName() != null) {
          createXADataSource(environment, initialContext, dataSourceConfig);
        } else {
          createNonXADataSource(environment, initialContext, dataSourceConfig);
        }
      }));
  }

  private void configureTransactionInfrastructure(InitialContext initialContext) {
    String transactionManagerJNDIContext = jtaPropertyManager.getJTAEnvironmentBean().getTransactionManagerJNDIContext();
    TransactionManager transactionManager = new TransactionManagerImple();
    bind(transactionManagerJNDIContext, transactionManager, transactionManager.getClass(), initialContext);

    UserTransaction userTransaction = new UserTransactionImple();
    bind(jtaPropertyManager.getJTAEnvironmentBean().getUserTransactionJNDIContext(), userTransaction, userTransaction.getClass(), initialContext);

    TransactionSynchronizationRegistry transactionSynchronizationRegistry = new TransactionSynchronizationRegistryImple();
    bind(jtaPropertyManager.getJTAEnvironmentBean().getTransactionSynchronizationRegistryJNDIContext(), transactionSynchronizationRegistry, transactionSynchronizationRegistry.getClass(), initialContext);
  }

  private void configureDefaultExceptionsMappers(Environment environment) {
    of(
      RecursoNotFoundExceptionMapper.class,
      RecursoForbiddenExceptionMapper.class,
      RecursoBadRequestExceptionMapper.class,
      RecursoNotAllowedExceptionMapper.class,
      MensajeValidationExceptionMapper.class,
      UsuarioBeanNotFoundExceptionMapper.class,
      RecursoNotSupportedExceptionMapper.class,
      RecursoNotAcceptableExceptionMapper.class,
      RecursoNotAuthorizedExceptionMapper.class,
      RecursoServiceUnavailableExceptionMapper.class,
      RecursoInternalServerErrorExceptionMapper.class
    ).forEach(environment.jersey()::register);

  }

  private void configureMetrics(T configuration, Environment environment) {
    MetricRegistry registry = environment.metrics();

    log.info("Guardando el registry en CDI");
    MetricsCdi.setRegistry(registry);

    MetricsConfig metricsConfig = configuration.getMetricsConfig();

    if (metricsConfig != null) {
      configureMetricsReporters(configuration, registry, metricsConfig);
    }
  }

  private void configureRedis(T configuration, Environment environment, InitialContext initialContext) {
    RedisCluster redisCluster = configuration.getRedis();
    if (redisCluster != null && redisCluster.getClusters() != null && !redisCluster.getClusters().isEmpty()) {
      log.info("Configurando Lettuce");

      List<LettuceConfig> lettuceConfigs = redisCluster.getClusters().stream()
        .map((RedisConfig redisConfig) -> {

          RedisNode redisNode = redisConfig.getNodes().stream()
            .findFirst().orElseThrow(() ->
              new GenericException("No se pudo obtener algo."));

          List<RedisNode> nodeList = redisConfig.getNodes().stream()
            .filter(redisNode1 ->
              !redisNode1.getHost().equals(redisNode.getHost()))
            .collect(toList());

          RedisURI.Builder sentinel = RedisURI.Builder
            .sentinel(redisNode.getHost(), redisNode.getPort(),
              redisConfig.getMasterName());

          nodeList.forEach(redisNode1 ->
            sentinel.withSentinel(redisNode1.getHost(), redisNode1.getPort()));

          RedisURI uri = sentinel.withDatabase(redisConfig.getDatabase())
            .withPassword(redisConfig.getPassword())
            .withTimeout(redisConfig.getTimeout(), MILLISECONDS)
            .build();

          log.info(uri.toString());

          RedisClient client = RedisClient.create(uri);

          LettuceConfig config = new LettuceConfig();
          GenericObjectPoolConfig redisPool = createRedisPool(redisConfig);

          GenericObjectPool<StatefulRedisConnection<String, String>> pool =
            ConnectionPoolSupport.createGenericObjectPool(client::connect, redisPool);


          config.setUri(uri);
          config.setClient(client);
          config.setPriority(redisConfig.getPriority());
          try {
            config.setConnect(config.getClient().connect());
          } catch (Throwable t) {
            log.warn("No se pudo conectar por ahora", t);
          }

          return config;
        }).collect(toList());

      RedisPoolRegistry.getInstance().setLettuceConfigs(lettuceConfigs);

    } else {
      log.warn("No esta configurado el soporte de Redis.");
    }
  }

  private void configureMetricsReporters(T configuration, MetricRegistry registry, MetricsConfig metricsConfig) {
    int period = metricsConfig.getPeriodToReportInSeconds();
    if (!metricsConfig.getElasticsearchNodes().isEmpty()) {
      configureReportMetricsToElasticsearch(configuration, registry, metricsConfig, period);
    }

    if (metricsConfig.getIncludeConsoleReporter()) {
      ConsoleReporter
        .forRegistry(registry)
        .build().start(period, SECONDS);
    }
  }

  private void configureReportMetricsToElasticsearch(T configuration, MetricRegistry registry, MetricsConfig metricsConfig, int period) {
    log.info("Configurando el envio de métricas al cluster de Elasticsearch: {}", metricsConfig.getElasticsearchNodes());

    try {

      String[] elasticsearchHosts = metricsConfig
        .getElasticsearchNodes()
        .toArray(new String[metricsConfig.getElasticsearchNodes().size()]);

      Map<String, Object> additionalFields =
        unmodifiableMap(
          of(
            entry("serviceName", configuration.getServiceName()),
            entry("instanceId", configuration.getInstanceId()),
            entry("serviceVersion", configuration.getVersion()),
            entry("environment", configuration.getEnvironment())
          ).collect(entriesToMap()));

      ElasticsearchReporter.Builder builder = ElasticsearchReporter
        .forRegistry(registry)
        .hosts(elasticsearchHosts)
        .additionalFields(additionalFields);

      if (metricsConfig.getIndex() != null) {
        builder.index(metricsConfig.getIndex());
      }

      builder.build()
        .start(period, SECONDS);

    } catch (Exception t) {
      log.error("No se pudo registrar el exporter", t);
    }
  }

  @Override
  public final void initialize(Bootstrap<T> bootstrap) {
    // Enable variable substitution with environment variables
    bootstrap.setConfigurationSourceProvider(
      new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
        new EnvironmentVariableSubstitutor(true, true)
      )
    );
    bootstrap.addBundle(new WeldBundle());
    onInitialize(bootstrap);
  }

  @Override
  public void onInitialize(Bootstrap<T> bootstrap) {
    //Empty implementation for default
  }

}
