package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.service;

import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.JsonUtilParser;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.MensajeDetalladoBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.MensajePersonalizadoBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.ParametroBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.cache.MensajeConfiguracionCache;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.client.Servicio;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.util.EstatusRespuesta;

import javax.inject.Inject;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
public class MensajeServiceImpl implements MensajeService {

  @Inject
  private MensajeConfiguracionCache mensajeConfiguracionCache;

  @Inject
  private JsonUtilParser jsonUtilParser;
  @Inject
  private Servicio servicio;

  @Override
  public ParametroBean obtenerMensaje(String codTabla) {
    ParametroBean parametroBean = obtenerParametrodeCache(codTabla).orElseGet(() ->
      servicio.obtenerMensajeCabecera(codTabla));
    return parametroBean;
  }

  @Override
  public MensajeDetalladoBean obtenerMensajeDetalle(String codTabla, RuntimeException exc) {
    ParametroBean parametroBean = obtenerParametrodeCache(codTabla).orElseGet(() ->
      servicio.obtenerMensajeCabecera(codTabla));
    String error = getStackTraceFromException(exc);
    return new MensajeDetalladoBean(parametroBean, error);
  }

  @Override
  public ParametroBean obtenerMensajeDetalle(String codTabla, String codParam) {
    String key = codTabla.concat(codParam);
    ParametroBean parametroBean = obtenerParametrodeCache(key).orElseGet(() ->
      servicio.obtenerMensajeDetalle(codTabla, codParam));
    return parametroBean;
  }

  @Override
  public MensajePersonalizadoBean obtenerListaMensaje(String codTabla, List<String> listaCodParam) {
    List<ParametroBean> listaEncontradosRedis = new ArrayList<>();
    List<String> listaNoEncotradosRedis = new ArrayList<>();
    StringBuilder codErrores = new StringBuilder();
    String key;
    MensajePersonalizadoBean mensajePersonalizadoBean;
    for (String codParam : listaCodParam) {
      log.info("codParam [{}]", codParam);
      key = codTabla.concat(codParam);
      Optional<ParametroBean> parametroBean = obtenerParametrodeCache(key);
      codErrores.append(codParam);
      codErrores.append("-");
      if (parametroBean.isPresent()) {
        parametroBean.get().setCod(codParam);
        listaEncontradosRedis.add(parametroBean.get());
      } else {
        listaNoEncotradosRedis.add(codParam);
      }
    }

    String errores = codErrores.toString();
    if (!errores.isEmpty()) {
      errores = errores.substring(0, errores.length() - 1);
    }

    if (listaNoEncotradosRedis.isEmpty()) {
      log.info("listaNoEncotradosRedis es vacio  ");
      Optional<ParametroBean> parametroBean = obtenerParametrodeCache(codTabla);
      if (parametroBean.isPresent()) {
        log.info("Encontro el codTabla  ");
        mensajePersonalizadoBean = new MensajePersonalizadoBean(codTabla, parametroBean.get().getMsg(), listaEncontradosRedis);
        return mensajePersonalizadoBean;
      }
    }
    log.info("invocando al servicio  ");
    log.info("errores  [{}]", errores);
    MensajePersonalizadoBean mensajePersonalizadoBean1 = servicio.obtenerListaMensajes(codTabla, errores);
    mensajePersonalizadoBean = verificarResultado(mensajePersonalizadoBean1, listaCodParam);
    return mensajePersonalizadoBean;
  }

  private Optional<ParametroBean> obtenerParametrodeCache(String key) {
    return mensajeConfiguracionCache.getParametroCache(key);
  }

  public String getStackTraceFromException(Exception e) {
    StringWriter stringWriter = new StringWriter();
    e.printStackTrace(new PrintWriter(stringWriter, true));
    return stringWriter.toString();
  }

  private MensajePersonalizadoBean verificarResultado(MensajePersonalizadoBean mensajePersonalizadoBean, List<String> listaCodParam) {
//    if (mensajePersonalizadoBean.getErrors() == null) {
//      mensajePersonalizadoBean.setMsg(MensajeUtil.obtenerMensaje(mensajePersonalizadoBean.getCod()));
//    List<ParametroBean> listaParametroBean = new ArrayList<>();
//    ParametroBean parametroBean;
//    for (String codParam : listaCodParam) {
//      parametroBean = new ParametroBean(codParam, MensajeUtil.obtenerMensaje(codParam));
//      listaParametroBean.add(parametroBean);
//    }
//    mensajePersonalizadoBean.setErrors(listaParametroBean);
//  }
    if (mensajePersonalizadoBean.getErrors() == null) {
      mensajePersonalizadoBean.setMsg(EstatusRespuesta.obtenerMensaje(mensajePersonalizadoBean.getCod()));
      List<ParametroBean> listaParametroBean = new ArrayList<>();
      ParametroBean parametroBean;
      for (String codParam : listaCodParam) {
        parametroBean = new ParametroBean(codParam, EstatusRespuesta.obtenerMensaje(codParam));
        listaParametroBean.add(parametroBean);
      }
      mensajePersonalizadoBean.setErrors(listaParametroBean);
    }
    return mensajePersonalizadoBean;
  }

}
