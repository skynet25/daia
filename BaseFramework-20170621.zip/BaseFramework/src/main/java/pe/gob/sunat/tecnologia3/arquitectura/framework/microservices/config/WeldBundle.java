package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config;

import io.dropwizard.Bundle;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import lombok.extern.slf4j.Slf4j;
import org.jboss.weld.environment.servlet.BeanManagerResourceBindingListener;
import org.jboss.weld.environment.servlet.Listener;

import javax.enterprise.inject.Vetoed;

@Slf4j
@Vetoed
public class WeldBundle implements Bundle {

  @Override
  public void initialize(Bootstrap<?> bootstrap) {
    log.debug("Inicializando el WeldBundle");
  }

  @Override
  public void run(Environment environment) {
    environment.getApplicationContext().addEventListener(new BeanManagerResourceBindingListener());
    environment.getApplicationContext().addEventListener(new Listener());
  }
}
