package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception;

import lombok.extern.slf4j.Slf4j;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.cdi.CdiService;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.MensajePersonalizadoBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.service.MensajeService;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.util.EstatusRespuesta;

import javax.enterprise.inject.Vetoed;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static javax.ws.rs.core.Response.status;

@Vetoed
@Provider
@Slf4j
public class MensajeValidationExceptionMapper implements ExceptionMapper<MensajeValidationException> {

  @Override
  public Response toResponse(MensajeValidationException e) {
    Optional<MensajeService> facade = CdiService.getFacade(MensajeService.class);
    int codTabla = e.getCodTabla();
    List<EstatusRespuesta> listaCodErrores = e.getListaCodError();

    MensajePersonalizadoBean mensajePersonalizadoBean = facade
      .map(servicio ->
        servicio.obtenerListaMensaje(String.valueOf(codTabla), convertirListaString(listaCodErrores)))
      .orElse(new MensajePersonalizadoBean(String.valueOf(codTabla), ""));

    return status(codTabla)
      .entity(mensajePersonalizadoBean)
      .build();
  }

  private List<String> convertirListaString(List<EstatusRespuesta> listaCodErrores) {
    List<String> listaCodigos= new ArrayList<>();
    for (EstatusRespuesta status :listaCodErrores) {
      listaCodigos.add(status.getCodigo().toString());
    }
    return listaCodigos;
  }

}
