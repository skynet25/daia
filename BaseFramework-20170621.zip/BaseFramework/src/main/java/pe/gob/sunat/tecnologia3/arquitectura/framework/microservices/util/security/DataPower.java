package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.security;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Clase modelo que representa toda la configuracion del DataPower.
 *
 * @author Sapia
 * @version 1.0
 * @since 22-01-2016
 */
@Getter
@Setter
@ToString
public class DataPower implements Serializable {
	
	private static final long serialVersionUID = 2307336228447115459L;
	private ServicioGenerarToken servicioGenerarToken = new ServicioGenerarToken();
	private ServicioValidarToken servicioValidarToken = new ServicioValidarToken();
	private ServicioAutorizacion servicioAutorizacion = new ServicioAutorizacion();
	private ServicioRefreshToken servicioRefreshToken = new ServicioRefreshToken();

	private Integer connectTimeoutSeg = 10;
	private Integer readTimeoutSeg = 10;
	private Integer writeTimeoutSeg = 10;

}
