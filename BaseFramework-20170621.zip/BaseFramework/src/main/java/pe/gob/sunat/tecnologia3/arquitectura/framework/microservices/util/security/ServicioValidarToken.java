package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.security;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Clase modelo que representa toda la configuracion del DataPower.
 *
 * @author Sapia
 * @version 1.0
 * @since 22-01-2016
 */
@Getter
@Setter
@ToString
public class ServicioValidarToken {

	private String protocolo;
	private String host;
	private Puerto puerto = new Puerto();
	private String path;

	@Getter
	@Setter
	@ToString
	public class Puerto {
		private String clientCredentials;
		private String accessCode;
	}

}
