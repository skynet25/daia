package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.client;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.ConfigService;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception.GenericException;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.JsonUtilParser;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.RemoteServiceLocation;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.MensajeBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.MensajePersonalizadoBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.ParametroBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.jackson.JacksonFactory;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.jackson.JacksonConverterFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.io.IOException;

import static java.lang.String.format;
import static java.util.concurrent.TimeUnit.SECONDS;

@Slf4j
public class ConfigServiceRestClient {
  private ObjectMapper objectMapper = JacksonFactory.getObjectMapper();

  @Inject
  private ConfigService configService;
  private ServicioConfiguracionRemoto servicioConfiguracionRemoto;
  @Inject
  private JsonUtilParser jsonUtilParser;

  @PostConstruct
  public void init() {
    RemoteServiceLocation remoteServiceLocation = configService
      .getConfig().getRemoteServiceLocation();
    String baseUri = format(
      "%s%s", remoteServiceLocation.getServiceBase(),
      remoteServiceLocation.getBaseUrlForConfiguracionService());
    Retrofit retrofit = this.obtenerRetrofit(baseUri);
    this.servicioConfiguracionRemoto = retrofit.create(ServicioConfiguracionRemoto.class);
  }

  private Retrofit obtenerRetrofit(final String baseUri) {
    Integer connectTimeout = 1;
    Integer readTimeout = 10;
    Integer writeTimeout = 10;
    log.info("connectTimeout: [{}], readTimeout: [{}], writeTimeout: [{}] ", connectTimeout, readTimeout, writeTimeout);
    OkHttpClient okHttpClient = new OkHttpClient().newBuilder()
      .connectTimeout(connectTimeout, SECONDS)
      .readTimeout(readTimeout, SECONDS)
      .writeTimeout(writeTimeout, SECONDS)
      .build();

    return new Retrofit.Builder()
      .baseUrl(baseUri)
      .client(okHttpClient)
      .addConverterFactory(JacksonConverterFactory.create(objectMapper))
      .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
      .build();
  }

  private MensajePersonalizadoBean procesarObtenerListaMensaje(String codTabla, String codParam) {
    return
      new ConfigListaMensajeCommand(
        servicioConfiguracionRemoto, jsonUtilParser, codTabla, codParam)
        .execute();
  }

  public MensajePersonalizadoBean consumirObtenerListaMensaje(String codTabla, String codParam) {
    return this.procesarObtenerListaMensaje(codTabla, codParam);
  }

  private ParametroBean procesarObtenerMensajeCabecera(String codTabla) {
    return
      new ConfigMensajeCabeceraCommand(
        servicioConfiguracionRemoto, jsonUtilParser, codTabla)
        .execute();
  }

  public ParametroBean consumirObtenerMensajeCabecera(String codTabla) {
    return this.procesarObtenerMensajeCabecera(codTabla);
  }

  private ParametroBean procesarObtenerMensajeDetalle(String codTabla, String codParam) {
    return
      new ConfigMensajeDetalleCommand(
        servicioConfiguracionRemoto, jsonUtilParser, codTabla, codParam)
        .execute();
  }

  public ParametroBean consumirObtenerMensajeDetalle(String codTabla, String codParam) {
    return this.procesarObtenerMensajeDetalle(codTabla, codParam);
  }

  public static ParametroBean getParametroBean(Call<ParametroBean> callResumen) throws IOException {
    log.info("Haciendo peticion con Retrofit, getParametroBean");
    Response<ParametroBean> response = callResumen.execute();
    if (response.isSuccessful()) {
      return response.body();
    }
    log.info(">>>>> getString resultado [{}]", response.errorBody().string());
    throw new GenericException(response.errorBody().string());
  }

  public static MensajePersonalizadoBean getMensajePersonalizadoBean(Call<MensajePersonalizadoBean> callResumen) throws IOException {
    log.info("Haciendo peticion con Retrofit, getMensajePersonalizadoBean");
    Response<MensajePersonalizadoBean> response = callResumen.execute();
    if (response.isSuccessful()) {
      return response.body();
    }
    log.info(">>>>> getString resultado [{}]", response.errorBody().string());
    throw new GenericException(response.errorBody().string());
  }
}