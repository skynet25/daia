package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.jpa;

import javax.inject.Qualifier;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * Created by domix on 5/5/17.
 */
@Qualifier
@Retention(RUNTIME)
@Target({FIELD, PARAMETER, METHOD, TYPE})
public @interface JpaEntityManagerFactory {
  String value() default "";
  String emName() default "";
}
