package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config;

import java.util.Collections;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.security.DataPower;

@Setter
@Getter
public class SecurityFilterConfig {
	/** Configuraciones para el JavaFilter */
	private Integer reintentosInvocacionGestorSesiones = 1;
	private Boolean activateSecurityFilter =  true;
	private List<String> exclusiones = Collections.EMPTY_LIST;
	
	private DataPower datapower = new DataPower();
}
