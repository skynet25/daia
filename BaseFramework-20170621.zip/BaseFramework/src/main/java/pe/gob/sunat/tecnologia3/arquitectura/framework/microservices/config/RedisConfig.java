package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config;

import lombok.Getter;
import lombok.Setter;

import javax.enterprise.inject.Vetoed;
import java.io.Serializable;
import java.util.List;

import static org.apache.commons.pool2.impl.BaseObjectPoolConfig.DEFAULT_BLOCK_WHEN_EXHAUSTED;
import static org.apache.commons.pool2.impl.BaseObjectPoolConfig.DEFAULT_EVICTION_POLICY_CLASS_NAME;
import static org.apache.commons.pool2.impl.BaseObjectPoolConfig.DEFAULT_JMX_ENABLE;
import static org.apache.commons.pool2.impl.BaseObjectPoolConfig.DEFAULT_JMX_NAME_PREFIX;
import static org.apache.commons.pool2.impl.BaseObjectPoolConfig.DEFAULT_LIFO;
import static org.apache.commons.pool2.impl.BaseObjectPoolConfig.DEFAULT_MAX_WAIT_MILLIS;
import static org.apache.commons.pool2.impl.BaseObjectPoolConfig.DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS;
import static org.apache.commons.pool2.impl.BaseObjectPoolConfig.DEFAULT_NUM_TESTS_PER_EVICTION_RUN;
import static org.apache.commons.pool2.impl.BaseObjectPoolConfig.DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS;
import static org.apache.commons.pool2.impl.BaseObjectPoolConfig.DEFAULT_TEST_ON_BORROW;
import static org.apache.commons.pool2.impl.BaseObjectPoolConfig.DEFAULT_TEST_ON_RETURN;
import static org.apache.commons.pool2.impl.BaseObjectPoolConfig.DEFAULT_TEST_WHILE_IDLE;
import static org.apache.commons.pool2.impl.BaseObjectPoolConfig.DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS;
import static org.apache.commons.pool2.impl.GenericObjectPoolConfig.*;
import static redis.clients.jedis.Protocol.DEFAULT_DATABASE;
import static redis.clients.jedis.Protocol.DEFAULT_TIMEOUT;

@Getter
@Setter
@Vetoed
public class RedisConfig implements Serializable {
  private String masterName = null;
  private Integer priority = 0;
  private transient List<RedisNode> nodes;
  private String sentinelUri;

  private Integer timeout = DEFAULT_TIMEOUT;
  private String password;
  private Integer database = DEFAULT_DATABASE;
  private String clientName;

  private Integer maxTotal = DEFAULT_MAX_TOTAL;
  private Integer maxIdle = DEFAULT_MAX_IDLE;
  private Integer minIdle = DEFAULT_MIN_IDLE;
  private Boolean lifo = DEFAULT_LIFO;
  private Long maxWaitMillis = DEFAULT_MAX_WAIT_MILLIS;
  private Long minEvictableIdleTimeMillis = DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS;
  private Long softMinEvictableIdleTimeMillis = DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS;
  private Integer numTestsPerEvictionRun = DEFAULT_NUM_TESTS_PER_EVICTION_RUN;
  private Boolean testOnBorrow = DEFAULT_TEST_ON_BORROW;
  private Boolean testOnReturn = DEFAULT_TEST_ON_RETURN;
  private Boolean testWhileIdle = DEFAULT_TEST_WHILE_IDLE;
  private Boolean testOnCreate = DEFAULT_TEST_ON_CREATE;
  private Long timeBetweenEvictionRunsMillis = DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS;
  private String evictionPolicyClassName = DEFAULT_EVICTION_POLICY_CLASS_NAME;
  private Boolean blockWhenExhausted = DEFAULT_BLOCK_WHEN_EXHAUSTED;
  private Boolean jmxEnabled = DEFAULT_JMX_ENABLE;
  private String jmxNamePrefix = DEFAULT_JMX_NAME_PREFIX;

}
