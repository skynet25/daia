package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config;

import com.arjuna.ats.jta.common.jtaPropertyManager;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.persistence.transaction.JTATransactionController;

import javax.enterprise.inject.Vetoed;
import javax.transaction.TransactionManager;

@Vetoed
@Slf4j
public class AtomikosTransactionController extends JTATransactionController {

  private TransactionManager utm;

  public AtomikosTransactionController() {
    log.debug("Creating the AtomikosTransactionController");
  }

  /**
   * INTERNAL: Obtain and return the JTA TransactionManager on this platform
   */
  @Override
  protected TransactionManager acquireTransactionManager() throws Exception {
    utm = (TransactionManager) jndiLookup(jtaPropertyManager.getJTAEnvironmentBean().getTransactionManagerJNDIContext());
    return utm;
  }

  @Override
  public TransactionManager getTransactionManager() {
    return utm;
  }

}
