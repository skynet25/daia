package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices;

import com.atomikos.jdbc.AbstractDataSourceBean;
import com.atomikos.jdbc.AtomikosDataSourceBean;
import com.atomikos.jdbc.nonxa.AtomikosNonXADataSourceBean;
import com.circulosiete.metrics.health.DataSourceHealthCheck;
import io.dropwizard.Application;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.DataSourceConfig;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.MicroserviceConfig;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.RedisConfig;

import javax.naming.InitialContext;
import java.sql.SQLException;
import java.util.Properties;

import static java.lang.String.format;
import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.JndiUtils.bind;

/**
 * Created by domix on 1/18/17.
 */
@Slf4j
public abstract class BaseApplication<T extends MicroserviceConfig> extends Application<T> {
  public abstract void onRun(T configuration, Environment environment) throws Exception;

  public abstract void onInitialize(Bootstrap<T> bootstrap);

  public GenericObjectPoolConfig createRedisPool(RedisConfig redisConfig) {
    GenericObjectPoolConfig redisPoolConfig = new GenericObjectPoolConfig();
    redisPoolConfig.setMaxIdle(redisConfig.getMaxIdle());
    redisPoolConfig.setMaxTotal(redisConfig.getMaxTotal());
    redisPoolConfig.setMinIdle(redisConfig.getMinIdle());
    redisPoolConfig.setBlockWhenExhausted(redisConfig.getBlockWhenExhausted());
    redisPoolConfig.setEvictionPolicyClassName(redisConfig.getEvictionPolicyClassName());
    redisPoolConfig.setJmxEnabled(redisConfig.getJmxEnabled());
    redisPoolConfig.setJmxNamePrefix(redisConfig.getJmxNamePrefix());
    redisPoolConfig.setLifo(redisConfig.getLifo());
    redisPoolConfig.setMaxWaitMillis(redisConfig.getMaxWaitMillis());
    redisPoolConfig.setMinEvictableIdleTimeMillis(redisConfig.getMinEvictableIdleTimeMillis());
    redisPoolConfig.setNumTestsPerEvictionRun(redisConfig.getNumTestsPerEvictionRun());
    redisPoolConfig.setSoftMinEvictableIdleTimeMillis(redisConfig.getSoftMinEvictableIdleTimeMillis());
    redisPoolConfig.setTestOnBorrow(redisConfig.getTestOnBorrow());
    redisPoolConfig.setTestOnCreate(redisConfig.getTestOnCreate());
    redisPoolConfig.setTestOnReturn(redisConfig.getTestOnReturn());
    redisPoolConfig.setTestWhileIdle(redisConfig.getTestWhileIdle());
    redisPoolConfig.setTimeBetweenEvictionRunsMillis(redisConfig.getTimeBetweenEvictionRunsMillis());
    return redisPoolConfig;
  }

  final void createXADataSource(Environment environment, InitialContext initialContext, DataSourceConfig dataSourceConfig) {
    AtomikosDataSourceBean dataSource = new AtomikosDataSourceBean();
    dataSource.setXaDataSourceClassName(dataSourceConfig.getXaDataSourceClassName());
    Properties xaProps = new Properties();
    xaProps.putAll(dataSourceConfig.getXaProperties());
    dataSource.setXaProperties(xaProps);

    configureDataSource(environment, initialContext, dataSourceConfig, dataSource);
  }

  final void createNonXADataSource(Environment environment, InitialContext initialContext, DataSourceConfig dataSourceConfig) {
    AtomikosNonXADataSourceBean dataSource = new AtomikosNonXADataSourceBean();
    dataSource.setDriverClassName(dataSourceConfig.getDriverClassName());
    dataSource.setPassword(dataSourceConfig.getPassword());
    dataSource.setUrl(dataSourceConfig.getUrl());
    dataSource.setUser(dataSourceConfig.getUser());

    configureDataSource(environment, initialContext, dataSourceConfig, dataSource);
  }

  private void configureDataSource(Environment environment, InitialContext initialContext, DataSourceConfig dataSourceConfig, AbstractDataSourceBean dataSource) {
    dataSource.setBorrowConnectionTimeout(dataSourceConfig.getBorrowConnectionTimeout());
    dataSource.setDefaultIsolationLevel(dataSourceConfig.getDefaultIsolationLevel());
    dataSource.setMaintenanceInterval(dataSourceConfig.getMaintenanceInterval());
    dataSource.setMaxIdleTime(dataSourceConfig.getMaxIdleTime());
    dataSource.setMaxLifetime(dataSourceConfig.getMaxLifetime());
    dataSource.setMaxPoolSize(dataSourceConfig.getMaxPoolSize());
    dataSource.setMinPoolSize(dataSourceConfig.getMinPoolSize());
    dataSource.setReapTimeout(dataSourceConfig.getReapTimeout());
    dataSource.setTestQuery(dataSourceConfig.getTestQuery());
    dataSource.setUniqueResourceName(dataSourceConfig.getUniqueResourceName());

    try {
      dataSource.setLoginTimeout(dataSourceConfig.getLoginTimeout());
    } catch (SQLException e) {
      throw new IllegalArgumentException("El parámetro no es válido para el timeout.", e);
    }

    try {
      bind(dataSourceConfig.getJndiName(), dataSource, dataSource.getClass(), initialContext);
    } catch (Exception e) {
      throw new IllegalStateException("No fue posible guardar en el árbol JNDI el DataSource.", e);
    }

    if (dataSourceConfig.getHealthCheck()) {
      String dataSourceId = format("%s: %s", dataSourceConfig.getUniqueResourceName(), dataSourceConfig.getJndiName());
      environment.healthChecks()
        .register(dataSourceConfig.getJndiName(),
          new DataSourceHealthCheck(dataSourceId, dataSource, dataSource.getTestQuery(), dataSourceConfig.getTimeoutHealthCheckInMilliseconds()));
    }
  }
}
