package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config;

import lombok.Getter;
import lombok.Setter;

import static redis.clients.jedis.Protocol.DEFAULT_PORT;

/**
 * Created by domix on 5/26/17.
 */
@Getter
@Setter
public class RedisNode {
  private String host = "localhost";
  private Integer port = DEFAULT_PORT;
}
