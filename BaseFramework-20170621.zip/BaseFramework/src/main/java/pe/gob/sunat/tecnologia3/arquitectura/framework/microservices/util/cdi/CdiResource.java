package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.cdi;

import lombok.Builder;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import javax.enterprise.inject.Any;
import javax.enterprise.inject.Vetoed;
import javax.enterprise.inject.spi.CDI;
import javax.enterprise.util.AnnotationLiteral;
import javax.naming.NamingException;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

/**
 * Created by domix on 2/9/17.
 */
@Slf4j
@Vetoed
@Path("/_")
public class CdiResource {

  @GET
  @Path("/beans")
  @Produces(APPLICATION_JSON)
  public List<MyBean> getbean() throws NamingException {
    return CDI.current().getBeanManager()
      .getBeans(Object.class,
        new AnnotationLiteral<Any>() {
        }).stream()
      .map(bean -> MyBean.builder()
        .canonicalName(bean.getBeanClass().getCanonicalName())
        .scope(bean.getScope().toString())
        .name(Optional.ofNullable(bean.getName()).orElse("no_name"))
        .build())
      .collect(Collectors.toList());
  }
}

@Getter
@Builder
@Vetoed
class MyBean {
  private String canonicalName;
  private String scope;
  private String name;
}