package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.cdi;

import lombok.extern.slf4j.Slf4j;

import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.inject.Vetoed;
import javax.enterprise.inject.spi.Bean;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.inject.spi.CDI;
import java.lang.annotation.Annotation;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import static java.util.stream.Collectors.toList;

/**
 * Permite acceder a recursos del contenedor de CDI.
 * <p>
 * Created by domix on 2/9/17.
 */
@Vetoed
@Slf4j
public class CdiService {
  private CdiService() {
    log.info("Prevent create instances");
  }

  /**
   * Obtiene una referencia al bean del tipo especificado.
   *
   * @param clazz El tipo del Bean que necesitamos.
   * @param <T>
   * @return
   */
  public static <T> Optional<T> getFacade(Class<T> clazz, Annotation... qualifiers) {
    BeanManager bm = CDI.current().getBeanManager();
    Iterator<Bean<?>> iterator = bm.getBeans(clazz, qualifiers).iterator();

    if (iterator.hasNext()) {
      Bean<T> bean = (Bean<T>) iterator.next();
      CreationalContext<T> ctx = bm.createCreationalContext(bean);
      T object = (T) bm.getReference(bean, clazz, ctx);
      return Optional.ofNullable(object);
    }

    return Optional.empty();
  }

  public static <T> List<T> getFacades(Class<T> clazz, Annotation... qualifiers) {
    BeanManager bm = CDI.current().getBeanManager();
    return bm.getBeans(clazz, qualifiers).stream()
      .map(bean -> (Bean<T>) bean)
      .map(bean -> {
        CreationalContext<T> ctx = bm.createCreationalContext(bean);
        return (T) bm.getReference(bean, clazz, ctx);
      }).collect(toList());
  }
}
