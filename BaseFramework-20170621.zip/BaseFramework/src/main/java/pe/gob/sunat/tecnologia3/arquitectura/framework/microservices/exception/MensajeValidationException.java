package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception;

import lombok.Getter;
import lombok.Setter;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.util.EstatusRespuesta;

import java.util.List;

@Getter
@Setter
public class MensajeValidationException extends RuntimeException {

  private int codTabla;
  private List<EstatusRespuesta> listaCodError;

  public MensajeValidationException(int codTabla, List<EstatusRespuesta> listaCodError) {
    this.codTabla = codTabla;
    this.listaCodError = listaCodError;
  }
}
