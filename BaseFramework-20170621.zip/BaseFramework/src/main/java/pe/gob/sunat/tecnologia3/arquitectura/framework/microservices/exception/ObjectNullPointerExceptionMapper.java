package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception;

import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.model.bean.MensajeExecBean;

import javax.enterprise.inject.Vetoed;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import static javax.ws.rs.core.Response.Status.INTERNAL_SERVER_ERROR;

@Vetoed
@Provider
public class ObjectNullPointerExceptionMapper implements ExceptionMapper<NullPointerException> {
  @Override
  public Response toResponse(NullPointerException exception) {
    MensajeExecBean mensajeExecBean = new MensajeExecBean();
    mensajeExecBean.setCod(INTERNAL_SERVER_ERROR.getStatusCode());
    mensajeExecBean.setMsg("Internal Server Error - Se presento una condicion inesperada que impidio completar el Request");
    mensajeExecBean.setExc(exception.toString());
    return Response.status(INTERNAL_SERVER_ERROR).entity(mensajeExecBean).type(MediaType.APPLICATION_JSON).build();
  }

}
