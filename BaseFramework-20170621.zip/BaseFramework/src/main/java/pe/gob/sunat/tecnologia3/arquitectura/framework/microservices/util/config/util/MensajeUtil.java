package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.util;

import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

@Slf4j
public class MensajeUtil {

  public static final int MENSAJE_ENCONTRADO_BD = 0;
  public static final int MENSAJE_NO_ENCONTRADO_BD = 1;
  public static final String MENSAJE_ELIMINIADO = "El mensaje ha sido eliminado.";
  protected static final Map<String, String> MAP_MENSAJES = new HashMap<>();
  public static final String COD_PREDT = "00000";

  public static final int TIPO_MENSAJE_CABECERA = 1;
  public static final int TIPO_MENSAJE_PERSONALIZADO = 2;

  static {
    MAP_MENSAJES.put(COD_PREDT, "mensaje por default MS");
    MAP_MENSAJES.put("400", "Bad Request - El Request no puede ser entendido por el Servidor debido a errores de Sintaxis, El cliente no debe repetir el Request sin modificaciones MS");
    MAP_MENSAJES.put("401", "Unauthorized - Fallo en la autenticación del Cliente MS");
    MAP_MENSAJES.put("403", "Forbidden - El Cliente no tiene autorización para acceder al Recurso MS");
    MAP_MENSAJES.put("404", "Not Found - El Recurso Solicitado no puede ser encontrado MS");
    MAP_MENSAJES.put("405", "Method Not Allowed - El Metodo HTTP utilizado en el Request no es soportado por el Recurso MS");
    MAP_MENSAJES.put("406", "Not Acceptable - El Recurso no puede responder al Cliente en el Media Type solicitado en el Request MS");
    MAP_MENSAJES.put("415", "Unsupported Media Type - La Entidad en el Body del Request esta en un Media Type que no es soportado por el Recurso MS");
    MAP_MENSAJES.put("500", "Internal Server Error - Se presento una condicion inesperada que impidio completar el Request MS");
    MAP_MENSAJES.put("503", "Service Unavailable - El Servidor no esta disponible temporalmente o esta muy ocupado para responder al Request");
  }

  private MensajeUtil() {
    log.debug("No puedes crearme.");
  }

  public static String obtenerMensaje(String codMensaje) {
    return MAP_MENSAJES
      .getOrDefault(codMensaje, "");
  }

}
