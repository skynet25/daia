package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MensajeBean {

	private String cod;
	private String msg;

	public MensajeBean(String cod, String msg) {
		super();
		this.cod = cod;
		this.msg = msg;
	}

	public MensajeBean() {

	}
}
