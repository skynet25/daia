package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util;

import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;

/**
 * @autor: Cristhian Molina [08/2016]
 * @modificado: Cristhian Molina [08/2016]
 * @descripción: { Clase plantilla que permite realizar reintentos en sectores de codigos seleccionados
 * para las excepciones producidas }
 */
public class RetryUtil<T> implements Callable<T> {

  private Callable<T> tarea;
  public static final int DEFAULT_NUMBER_REINTENTOS = 3;
  public static final long DEFAULT_TIEMPO_ESPERA = 250;

  private int reintentos;
  private int intentosRestantes;
  private long tiempoDeEspera;

  public RetryUtil(Callable<T> tarea) {
    this(DEFAULT_NUMBER_REINTENTOS, DEFAULT_TIEMPO_ESPERA, tarea);
  }

  public RetryUtil(int reintentos, long tiempoEspera,
                   Callable<T> tarea) {
    this.reintentos = reintentos;
    //Inicializa los intentos restantes con el mismo total de reintentos
    this.intentosRestantes = reintentos;
    this.tiempoDeEspera = tiempoEspera;
    this.tarea = tarea;
  }

  public int getNumeroIntentos() {
    return reintentos - intentosRestantes;
  }

  /**
   * @autor: Cristhian Molina [08/2016]
   * @modificado: Cristhian Molina [08/2016]
   * @descripción: {Método que ejecuta la tarea configurada, incluye intentos y timeout}
   */
  @Override
  public T call() throws Exception {
    while (true) {
      try {
        return tarea.call();
      } catch (InterruptedException e) {
        throw e;
      } catch (CancellationException e) {
        throw e;
      } catch (Exception e) {
        intentosRestantes--;
        if (intentosRestantes == 0) {
          throw new IllegalStateException(reintentos +
            " reintentos fallidos en " + tiempoDeEspera +
            " milisegundos", e);
        }
        Thread.sleep(tiempoDeEspera);
      }
    }
  }
}