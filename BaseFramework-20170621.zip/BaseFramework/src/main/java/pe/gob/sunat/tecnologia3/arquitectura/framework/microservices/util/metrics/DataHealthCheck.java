package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.metrics;

import com.codahale.metrics.health.HealthCheck;

import javax.enterprise.inject.Vetoed;

/**
 * Created by domix on 3/16/17.
 */
@Vetoed
public class DataHealthCheck extends HealthCheck {
  private final String value;

  public DataHealthCheck(String value) {
    this.value = value;
  }

  @Override
  protected Result check() throws Exception {
    return Result.healthy(value);
  }
}
