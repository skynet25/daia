package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception;

import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.cdi.CdiService;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.ParametroBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.service.MensajeService;

import javax.enterprise.inject.Vetoed;
import javax.ws.rs.BadRequestException;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.Optional;

import static javax.ws.rs.core.Response.Status.BAD_REQUEST;
import static javax.ws.rs.core.Response.status;
import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.util.MensajeUtil.obtenerMensaje;

@Vetoed
@Provider
public class RecursoBadRequestExceptionMapper implements ExceptionMapper<BadRequestException> {

  @Override
  public Response toResponse(BadRequestException exception) {
    Optional<MensajeService> facade = CdiService.getFacade(MensajeService.class);
    String codStatus = String.valueOf(BAD_REQUEST.getStatusCode());
    ParametroBean parametroBean = facade
      .map(servicio -> servicio
        .obtenerMensaje(codStatus))
      .orElse(new ParametroBean(codStatus, obtenerMensaje(codStatus)));

    return status(BAD_REQUEST)
      .entity(parametroBean)
      .build();
  }

}
