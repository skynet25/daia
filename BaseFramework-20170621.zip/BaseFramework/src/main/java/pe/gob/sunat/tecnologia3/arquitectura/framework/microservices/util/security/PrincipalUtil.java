package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.security;

import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception.UsuarioBeanNotFoundException;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.JsonUtilParser;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import java.util.Optional;

/**
 * Created by domix on 2/23/17.
 */
public class PrincipalUtil {

  private final JsonUtilParser jsonUtilParser;

  @Inject
  public PrincipalUtil(JsonUtilParser jsonUtilParser) {
    this.jsonUtilParser = jsonUtilParser;
  }

  public <T> T getUsuarioBean(HttpServletRequest request, Class<T> clazz, String attributeName) {
    return Optional.ofNullable(request.getAttribute(attributeName))
      .map(Object::toString).map(s -> jsonUtilParser.toObject(s, clazz))
      .orElseThrow(() -> new UsuarioBeanNotFoundException("No se encontro en el request la data del usuario.", attributeName));
  }

  public <T> T getUsuarioBean(HttpServletRequest request, Class<T> clazz) {
    return getUsuarioBean(request, clazz, "UsuarioBean");
  }
}
