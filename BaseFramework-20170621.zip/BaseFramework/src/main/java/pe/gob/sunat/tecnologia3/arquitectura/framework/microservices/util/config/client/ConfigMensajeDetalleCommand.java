package pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.client;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import okhttp3.ResponseBody;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.JsonUtilParser;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.MensajeBean;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.bean.ParametroBean;
import retrofit2.Call;

import static pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.util.config.util.MensajeUtil.obtenerMensaje;

/**
 * Created by domix on 5/15/17.
 */
public class ConfigMensajeDetalleCommand extends HystrixCommand<ParametroBean> {

  private final ServicioConfiguracionRemoto servicioConfiguracionRemoto;
  private final JsonUtilParser jsonUtilParser;
  private final String codTabla;
  private final String codParam;

  public ConfigMensajeDetalleCommand(ServicioConfiguracionRemoto servicioConfiguracionRemoto, JsonUtilParser jsonUtilParser, String codTabla, String codParam) {
    super(HystrixCommandGroupKey.Factory.asKey("ConfigService"));
    this.servicioConfiguracionRemoto = servicioConfiguracionRemoto;
    this.jsonUtilParser = jsonUtilParser;
    this.codTabla = codTabla;
    this.codParam = codParam;
  }

  @Override
  protected ParametroBean run() throws Exception {
    Call<ParametroBean> callResumen = servicioConfiguracionRemoto.obtenerMensajeDetalle(codTabla, codParam);
    return ConfigServiceRestClient.getParametroBean(callResumen);
  }

  @Override
  protected ParametroBean getFallback() {
    return new ParametroBean(codTabla, obtenerMensaje(codParam));
  }
}
