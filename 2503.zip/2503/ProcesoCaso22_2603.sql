--- Pedido 1  ---(402589 row(s) affected) ---------------------- pedido modificado  ---- Inicio
--select * from [db_proc_procesos1].[n570].[memo602]
select * from [db_proc_procesos1].[n570].[memo602Cate]

select [codRegimen],des_Regimen, count(*)
from [db_proc_procesos1].[n570].[memo602Cate]
group by [codRegimen],des_Regimen

--select [codRegimen],des_Regimen, count(*)
--from [db_proc_procesos1].[n570].[memo602]
--group by [codRegimen],des_Regimen

--drop table [db_proc_procesos1].[n570].[memo60_1]
--select RUC, cod_valor,[codRegimen], des_Regimen,tama�o,des_tama�o,a�o
--into [db_proc_procesos1].[n570].[memo60_1]  ---(402589 row(s) affected)
--from [db_proc_procesos1].[n570].[memo602];

select RUC, cod_valor,[codRegimen], des_Regimen,Categoria,DesCategoria,a�o
--into [db_proc_procesos1].[n570].[memo60_1Cate]  ---(402589 row(s) affected)
from  [db_proc_procesos1].[n570].[memo602Cate]

select desCategoria,Categoria, count(Categoria) from [db_proc_procesos1].[n570].[memo60_1Cate]
group by desCategoria,Categoria;

select * from [db_proc_procesos1].[n570].[memo60_1Cate]

select 
DENSE_RANK() over(order by RUC ) RUC_R,RUC, 
ROW_NUMBER() over(order by cod_valor) Nro_Valor, cod_valor,
[codRegimen], des_Regimen,Categoria tama�o, desCategoria des_tama�o,a�o 
--into [db_proc_procesos1].[n570].[memo60_1fCate]  ---(402589 row(s) affected)
from [db_proc_procesos1].[n570].[memo60_1Cate]
order by 1, 2 desc;

--drop table [db_proc_procesos1].[n570].[memo60_1fRegimenGeneral] ;

select      concat('RUC ' ,[RUC_R]) RUC_C
           ,[RUC]
           ,concat('VALOR ' ,[Nro_Valor]) VALOR_C
           ,[cod_valor]
           ,[codRegimen]
           ,[des_Regimen]
           ,[tama�o]
           ,[des_tama�o]
		   , case [codRegimen]
		   when '1' then tama�o
		   else ''
		   end tama�oTG
		   , case [codRegimen]
		   when '1' then des_tama�o
		   else ''
		   end DesTama�oRG
           ,[a�o] 
--into [db_proc_procesos1].[n570].[memo60_1fRegimenGeneral]
from [db_proc_procesos1].[n570].[memo60_1fCate]
order by [RUC_R] asc;

---
select * from [db_proc_procesos1].[n570].[memo60_1fRegimenGeneral]
where  DesTama�oRG in ('SIN SEGMENTO')
order by [RUC] asc;

--update [db_proc_procesos1].[n570].[memo60_1fRegimenGeneral] set tama�oTG =0  where  DesTama�oRG in ('SIN SEGMENTO') and cod_valor in ('2740020003067   ','2740020003069   ','2740020003068   ');
---

select codRegimen,des_Regimen, count(codRegimen) from [db_proc_procesos1].[n570].[memo60_1fRegimenGeneral]
group by codRegimen,des_Regimen

select * 
--into [db_proc_procesos1].[n570].[memo60_1fRegimenGeneralC]
from [db_proc_procesos1].[n570].[memo60_1fRegimenGeneral]
where tama�oTG in (1,2,3,5,6,7,'') 
order by [RUC] asc;
-- 402589- 373470

select * from db_analisis.padron.dim_RegimenContri;
------------------ parte 1 modificado - Inicio
select [RUC_C],[VALOR_C],[codRegimen],[des_Regimen],[tama�oTG] [tama�oRG], [DesTama�oRG],[a�o]
from [db_proc_procesos1].[n570].[memo60_1fRegimenGeneralC]
order by [RUC] asc;

select * from [db_proc_procesos1].[n570].[tipoRegimenT] 
SELECT * into [db_proc_procesos1].[n570].[memo60_1fRegimenGeneralCR] FROM [db_proc_procesos1].[n570].[memo60_1fRegimenGeneralC];

--- con cambios [db_proc_procesos1].[n570].[tipoRegimenT] 

select [RUC_C],[VALOR_C],concat(t3.des_corta,' ',t3.desctrib) as [descripcion tributo],[codRegimen],[des_Regimen],[tama�oTG] [tama�oRG], [DesTama�oRG],
(select top 1 fec_emi from [db_proc_procesos1].[n570].[memo602Cate] t2 where t1.ruc=t2.ruc and t1.cod_valor=t2.cod_valor) as fec_emi
--into [db_proc_procesos1].[n570].[Memo060_Parte1M]  ---(373493 row(s) affected)
from [db_proc_procesos1].[n570].[memo60_1fRegimenGeneralCR] t1 
inner join [db_proc_procesos1].[n570].[memo6022] t2 on t1.ruc=t2.ruc and t1.cod_valor=t2.cod_valor
inner join db_gpgd.dbo.Param_Tributo t3 on t3.cod_trib=t2.[cod_trib]
order by t1.[RUC] asc;

select [RUC_C],[VALOR_C],[descripcion tributo],[codRegimen],[des_Regimen],[tama�oRG], [DesTama�oRG],
year([fec_emi]) a�o
--into [db_proc_procesos1].[n570].[Memo060_Parte1M1] 
from [db_proc_procesos1].[n570].[Memo060_Parte1M] 

--remitir Modificado

select * from [db_proc_procesos1].[n570].[Memo060_Parte1M1]


---373493
select * from [db_proc_procesos1].[n570].[memo6022]

select distinct ruc, cod_valor from [db_proc_procesos1].[n570].[tipoRegimenT]   ---373459
select distinct ruc,cod_valor from [db_proc_procesos1].[n570].[memo6022];  --402577

--- enviar
select * from [db_proc_procesos1].[n570].[Memo060_Parte1];


------------------ parte 1 modificado - Fin
select * 
--into [db_proc_procesos1].[n570].[tipoRegimenT] ---(373470 row(s) affected)
from [db_proc_procesos1].[n570].[memo60_1fRegimenGeneralC]
--where codRegimen=7 ---7931

---regimen PERSONA NATURAL SIN EMPRESA  --- 2463
select *
from [db_proc_procesos1].[n570].[memo60_1fRegimenGeneralCR]
where tama�o=10 and codregimen=7;

--update [db_proc_procesos1].[n570].[memo60_1fRegimenGeneralCR] set des_Regimen ='RENTAS DE CUARTA CATEGORIA'  ---(2463 row(s) affected)
--where tama�o=10 and codregimen=7;

select *
from [db_proc_procesos1].[n570].[memo60_1fRegimenGeneralCR] t1
left join  db_proc_procesos1.qk30.rucRegimenff t2 on t1.ruc=t2.ruc 
where codregimen=7 and des_Regimen in ('SIN REGIMEN RENTA 3RA') and t2.des_tributo is not null

--update [db_proc_procesos1].[n570].[memo60_1fRegimenGeneralCR] set des_Regimen =t2.des_tributo  --- (619 row(s) affected)
--from [db_proc_procesos1].[n570].[memo60_1fRegimenGeneralCR] t1
--left join  db_proc_procesos1.qk30.rucRegimenff t2 on t1.ruc=t2.ruc 
--where codregimen=7 and des_Regimen in ('SIN REGIMEN RENTA 3RA') and t2.des_tributo is not null



select * from  db_proc_procesos1.qk30.rucRegimenff where des_tributo is not null;

select *
from [db_proc_procesos1].[n570].[memo60_1fRegimenGeneralCR] t1
where codregimen=7 and des_Regimen in ('SIN REGIMEN RENTA 3RA')

---- OTROS
--update [db_proc_procesos1].[n570].[memo60_1fRegimenGeneralCR] ---(4849 row(s) affected)
--set  des_Regimen ='PERSONA NATURAL INGRESOS MENORES A 150 UIT'
--where codregimen=7 and des_Regimen in ('SIN REGIMEN RENTA 3RA')

---------

select * from [db_proc_procesos1].[n570].[memo60_1fRegimenGeneral]
where codRegimen=1 and tama�oTG in (1,2,3,5,6,7)
---133866  104747 =29119


--- Pedido 1  ---(402589 row(s) affected) ---------------------- pedido modificado  ---- Fin
select
  ruc,
  cod_valor,
  count(concat(ruc, '-', cod_valor)) as columna1
from
  [db_proc_procesos1].[n570].[tipoRegimenT]
group by
  ruc,
  cod_valor
having
  count(concat(ruc, '-', cod_valor))  > 1


select
  ruc,
  cod_valor,
  count(concat(ruc, '-', cod_valor)) as columna1
from
  [db_proc_procesos1].[n570].[memo6022]
group by
  ruc,
  cod_valor
having
  count(concat(ruc, '-', cod_valor))  > 1

--(402589 row(s) affected)
/*********************************************			parte 2	Modificado inicio				***********************************************/
select * 
from [db_proc_procesos1].[n570].[memo6022]; 
--- 402589
select  * 
from [db_proc_procesos1].[n570].[tipoRegimenT]
--- 373470


select t1.codRegimen, t1.des_Regimen, t1.tama�oTG, t1.DesTama�oRG, t2.* ---t1.ruc, t1.cod_valor, 
--into [db_proc_procesos1].[n570].[memo6022_Parte2]  ---(373493 row(s) affected)
from [db_proc_procesos1].[n570].[tipoRegimenT] t1  --- 373470
left join [db_proc_procesos1].[n570].[memo6022] t2 on t1.ruc=t2.ruc and t1.cod_valor=t2.cod_valor

select * from [db_proc_procesos1].[n570].[memo6022_Parte2]


select t1.cod_trib, t1.codRegimen, t1.des_Regimen, t1.tama�oTG, t1.DesTama�oRG, t1.RUC, t1.cod_valor, t1.imp_insoluto, t1.int_multaE,monto_total_MultaE,t1.total_pagado,t1.Monto_Impugnado
--into [db_proc_procesos1].[n570].[memo6022_Parte21]  ---(373493 row(s) affected)
from [db_proc_procesos1].[n570].[memo6022_Parte2] t1 
--373493

select t1.cod_valor, count(t1.cod_valor) from  [db_proc_procesos1].[n570].[memo6022_Parte21] t1 
inner join [db_proc_procesos1].[n570].[Memo060_a] t2 on t1.ruc=t2.ruc and t1.cod_valor=t2.cod_valor
group by t1.cod_valor 
having count(t1.cod_valor)>1
order by 1 desc;

select * from  [db_proc_procesos1].[n570].[memo6022_Parte21] t1 
inner join [db_proc_procesos1].[n570].[Memo060_aa] t2 on t1.ruc=t2.ruc and t1.cod_valor=t2.cod_valor
where t2.cod_valor in ('1040020041829   ')


select * from [db_proc_procesos1].[n570].[memo6022_Parte21] where cod_valor in ('1040020041829   ');
select * from [db_proc_procesos1].[n570].[Memo060_a] where cod_valor in ('1040020041829   ');

select     [RUC]          
           ,[cod_valor]
           ,[descripcion tributo]
           ,[codRegimen]
           ,[des_Regimen]
           ,[tama�oRG]
           ,[DesTama�oRG]
           ,[a�o] 
into [db_proc_procesos1].[n570].[Memo060_aa]
from [db_proc_procesos1].[n570].[Memo060_a]


----2603
select * from [db_proc_procesos1].[n570].[memo6022_Parte21]; --- 373493
select * from [db_proc_procesos1].[n570].[Memo060_a];---    373345 


select count(distinct cod_valor) from [db_proc_procesos1].[n570].[Memo060_a];

select cod_valor, count(cod_valor) from [db_proc_procesos1].[n570].[Memo060_a] 
group by cod_valor 
having count(cod_valor)>1
order by 1 desc;

select cod_valor, count(cod_valor) from [db_proc_procesos1].[n570].[memo6022_Parte21]
group by cod_valor 
having count(cod_valor)>1
order by 1 desc;

select * from [db_proc_procesos1].[n570].[Memo060_p1];
select t1.cod_trib, t2.codRegimen, t2.des_Regimen, t2.tama�oRG, t2.DesTama�oRG, t2.RUC, t2.cod_valor, t1.imp_insoluto, t1.int_multaE,monto_total_MultaE,t1.total_pagado,t1.Monto_Impugnado
--into [db_proc_procesos1].[n570].[Memo060_p1]
from [db_proc_procesos1].[n570].[Memo060_a] t2
left join  [db_proc_procesos1].[n570].[memo6022_Parte21] t1 on t1.ruc=t2.ruc and t1.cod_valor=t2.cod_valor
where t1.cod_valor not in ('2740020003337   ','1540020009027   ','1040020041853   ','1040020041852   ','1040020041851   ',
'1040020041850   ', '1040020041831   ','1040020041830   ','1040020041829   ','1040020041826   ', 
'0740020041021   ', '0340020082493   ','0340020079419   ')
--- (373479 row(s) affected)
select *
--into [db_proc_procesos1].[n570].[Memo060_p2] 
from [db_proc_procesos1].[n570].[memo6022_Parte21] 
where cod_valor in ('2740020003337   ','1540020009027   ','1040020041853   ','1040020041852   ','1040020041851   ',
'1040020041850   ', '1040020041831   ','1040020041830   ','1040020041829   ','1040020041826   ', 
'0740020041021   ', '0340020082493   ','0340020079419   ')

select * from [db_proc_procesos1].[n570].[Memo060_a] 
where cod_valor in ('2740020003337   ','1540020009027   ','1040020041853   ','1040020041852   ','1040020041851   ',
'1040020041850   ', '1040020041831   ','1040020041830   ','1040020041829   ','1040020041826   ', 
'0740020041021   ', '0340020082493   ','0340020079419   ')

--juntando  datos
insert into [db_proc_procesos1].[n570].[Memo060_p1]
select * from [db_proc_procesos1].[n570].[Memo060_p2]
--- 373345

select * from [db_proc_procesos1].[n570].[Memo060_p1];
--- 373345

select t1.cod_trib, concat(t2.des_corta,' ',t2.desctrib) as [descripcion tributo], t1.codRegimen, t1.des_Regimen, t1.tama�oRG, t1.DesTama�oRG, count(distinct t1.RUC) Cantidad_Contribuyentes, count(t1.cod_valor) Numero_Multas, sum(t1.imp_insoluto) as Importe_Insoluto_ME,
sum(t1.int_multaE) as Interes_multasE, sum(monto_total_MultaE) as Monto_Total_MultaE, sum(t1.total_pagado)as Monto_Pagado_CierreA,
sum(t1.Monto_Impugnado) as Monto_Impugnado_CierreA
--into [db_proc_procesos1].[n570].[Memo060_Parte2]
from [db_proc_procesos1].[n570].[Memo060_p1] t1
inner join db_gpgd.dbo.Param_Tributo t2 on t2.cod_trib=t1.[cod_trib]
group by t1.cod_trib, concat(t2.des_corta,' ',t2.desctrib),t1.codRegimen, t1.des_Regimen, t1.tama�oRG, t1.DesTama�oRG
order by t1.cod_trib
--- cantidad de valores 373345
-- 420









/*********************************************			parte 2	Modificado Fin				***********************************************/
/*********************************************			parte 2	actualizando los nuevos regimenes - inicio			***********************************************/
select * 
from [db_proc_procesos1].[n570].[memo6022]; 
--- 402589
select  * from [db_proc_procesos1].[n570].[tipoRegimenT] order by 1 asc;
--- 373470
---------reemplaza a [db_proc_procesos1].[n570].[tipoRegimenT]
select * from [db_proc_procesos1].[n570].[memo60_1fRegimenGeneralCU]  order by 1 asc;
---- 373470

select t1.codRegimen, t1.des_Regimen, t1.tama�oTG, t1.DesTama�oRG, t2.* ---t1.ruc, t1.cod_valor, 
--into [db_proc_procesos1].[n570].[memo6022_Parte2M]  ---(373493 row(s) affected)
from [db_proc_procesos1].[n570].[memo60_1fRegimenGeneralCU]  t1  --- 373470
left join [db_proc_procesos1].[n570].[memo6022] t2 on t1.ruc=t2.ruc and t1.cod_valor=t2.cod_valor
--- 373493

select * from [db_proc_procesos1].[n570].[memo6022_Parte2M]


select t1.cod_trib, t1.codRegimen, t1.des_Regimen, t1.tama�oTG, t1.DesTama�oRG, t1.RUC, t1.cod_valor, t1.imp_insoluto, t1.int_multaE,monto_total_MultaE,t1.total_pagado,t1.Monto_Impugnado
--into [db_proc_procesos1].[n570].[memo6022_Parte21M]  ---(373493 row(s) affected)
from [db_proc_procesos1].[n570].[memo6022_Parte2M] t1
--373493

select t1.cod_trib, concat(t2.des_corta,' ',t2.desctrib) as [descripcion tributo], t1.codRegimen, t1.des_Regimen, t1.tama�oTG, t1.DesTama�oRG, count(distinct t1.RUC) Cantidad_Contribuyentes, count(t1.cod_valor) Numero_Multas, sum(t1.imp_insoluto) as Importe_Insoluto_ME,
sum(t1.int_multaE) as Interes_multasE, sum(monto_total_MultaE) as Monto_Total_MultaE, sum(t1.total_pagado)as Monto_Pagado_CierreA,
sum(t1.Monto_Impugnado) as Monto_Impugnado_CierreA
--into [db_proc_procesos1].[n570].[Memo060_Parte2M]  (465 row(s) affected)
from [db_proc_procesos1].[n570].[memo6022_Parte21M] t1
inner join db_gpgd.dbo.Param_Tributo t2 on t2.cod_trib=t1.[cod_trib]
group by t1.cod_trib, concat(t2.des_corta,' ',t2.desctrib),t1.codRegimen, t1.des_Regimen, t1.tama�oTG, t1.DesTama�oRG
order by t1.cod_trib
--- 465

select * from [db_proc_procesos1].[n570].[Memo060_Parte2M];
--(465 row(s) affected)


select *
from db_proc_plan_info.N570.[Memo060_Parte2MSinBlancos] 
where DesTama�oRG ='';



/*********************************************			parte 2	actualizando los nuevos regimenes - Fin			***********************************************/






select * from db_gpgd.dbo.Param_Tributo where cod_trib in ('060108');
select * from [db_Data_WH].[decla].[TB_TRIBUTO] where cod_tributo in ('060108');


 











/*********************************************			porque no coinciden la cantidad de contribuyentes del archivo 1 con el del archivo 2			***********************************************/
select * from [db_proc_procesos1].[n570].[memo6022_Parte21]

select cod_trib, ruc, count(ruc)  from [db_proc_procesos1].[n570].[memo6022_Parte21]
group by cod_trib, ruc

select cod_trib,codregimen, count(ruc) from [db_proc_procesos1].[n570].[memo6022_Parte21] group by cod_trib,codregimen

select cod_trib, cod_regimen, count(ruc) from..... group by cod_trib, cod_regimen


select t1.cod_trib, concat(t2.des_corta,' ',t2.desctrib) as [descripcion tributo], t1.codRegimen, t1.des_Regimen, t1.tama�oTG, t1.DesTama�oRG, count(t1.RUC) Cantidad_Contribuyentes, count(t1.cod_valor) Numero_Multas, sum(t1.imp_insoluto) as Importe_Insoluto_ME,
sum(t1.int_multaE) as Interes_multasE, sum(monto_total_MultaE) as Monto_Total_MultaE, sum(t1.total_pagado)as Monto_Pagado_CierreA,
sum(t1.Monto_Impugnado) as Monto_Impugnado_CierreA
--into [db_proc_procesos1].[n570].[Memo060_Parte2p]
from [db_proc_procesos1].[n570].[memo6022_Parte21] t1
inner join db_gpgd.dbo.Param_Tributo t2 on t2.cod_trib=t1.[cod_trib]
group by t1.cod_trib, concat(t2.des_corta,' ',t2.desctrib),t1.codRegimen, t1.des_Regimen, t1.tama�oTG, t1.DesTama�oRG
order by t1.cod_trib


