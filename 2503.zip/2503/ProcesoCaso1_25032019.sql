----25032019
/******************		Obtencion del a�o de emision de la multa del campo fec_emi		*******************************/
select [RUC_C],[VALOR_C],[descripcion tributo],[codRegimen],[des_Regimen],[tama�oRG], [DesTama�oRG],
year([fec_emi]) a�o
--into [db_proc_procesos1].[n570].[Memo060_Parte1MU32]  ---(373462 row(s) affected)
from [db_proc_procesos1].[n570].[Memo060_Parte1MU22]
order by CAST(SUBSTRING([RUC_C] + '0', PATINDEX('%[0-9]%', [RUC_C] + '0'), LEN([RUC_C] + '0')) AS INT) 
--order by CAST(SUBSTRING([VALOR_C] + '0', PATINDEX('%[0-9]%', [VALOR_C] + '0'), LEN([VALOR_C] + '0')) AS INT) 
-----		Resultado a enviar
select * from [db_proc_procesos1].[n570].[Memo060_Parte1MU32] where codregimen=6-- des_regimen ='R�GIMEN 4TA CATEGORIA';;



select [RUC_C],[RUC],[VALOR_C] ,[cod_valor] ,[descripcion tributo] ,[codRegimen] ,[des_Regimen] ,[tama�oRG],[DesTama�oRG] ,year([fec_emi]) a�o
--into [db_proc_procesos1].[n570].[Memo060_a]--(373462 row(s) affected)
from [db_proc_procesos1].[n570].[Memo060_Parte1MU22] ;

select * from [db_proc_procesos1].[n570].[Memo060_a] where des_regimen like('%simpli%');

select * from [db_proc_procesos1].[n570].[Memo060_a] t1 
inner join [db_proc_procesos1].[n570].[RUC_PersonasNaturales150UIT] t2 on t1.ruc=t2.num_ruc 
where t1.des_regimen ='PERSONA NATURAL INGRESOS MENORES A 150 UIT';

--- actualizar R�GIMEN 4TA CATEGORIA
select * from [db_proc_procesos1].[n570].[Memo060_a] where ruc in ('10406166771');
--update [db_proc_procesos1].[n570].[Memo060_a] set des_regimen ='R�GIMEN 4TA CATEGORIA' where ruc in ('10406166771');

--- actualizar  R�GIMEN �NICO SIMPLIFICADO
select * from [db_proc_procesos1].[n570].[Memo060_a] t1 
inner join [db_proc_procesos1].[n570].[26RUC_RUS_VFP] t2 on t1.ruc=t2.vfp_numruc
where t1.des_regimen ='PERSONA NATURAL INGRESOS MENORES A 150 UIT';

--update [db_proc_procesos1].[n570].[Memo060_a] set des_regimen='R�GIMEN �NICO SIMPLIFICADO', codRegimen=6
--from [db_proc_procesos1].[n570].[Memo060_a] t1 
--inner join [db_proc_procesos1].[n570].[26RUC_RUS_VFP] t2 on t1.ruc=t2.vfp_numruc
--where t1.des_regimen ='PERSONA NATURAL INGRESOS MENORES A 150 UIT';  ---(28 row(s) affected)

-- Eliminar los casos que tienen regimen = PERSONA NATURAL INGRESOS MENORES A 150 UIT  --- 117
 select * from [db_proc_procesos1].[n570].[Memo060_a] 
 where des_regimen ='PERSONA NATURAL INGRESOS MENORES A 150 UIT';

 --delete from [db_proc_procesos1].[n570].[Memo060_a] 
 --where des_regimen ='PERSONA NATURAL INGRESOS MENORES A 150 UIT';  ---(117 row(s) affected)


select * from [db_proc_procesos1].[n570].[Memo060_a]

 ---373345 

select 
DENSE_RANK() over(order by RUC ) RUC_R,RUC, 
ROW_NUMBER() over(order by cod_valor) Nro_Valor, cod_valor,
[descripcion tributo],[codRegimen],[des_Regimen],[tama�oRG], [DesTama�oRG],a�o 
--into [db_proc_procesos1].[n570].[Memo060_b]
from [db_proc_procesos1].[n570].[Memo060_a]
order by 1, 2 desc;
--(373345 row(s) affected)

select concat('RUC ' ,[RUC_R]) RUC_C,[RUC],concat('VALOR ' ,[Nro_Valor]) VALOR_C, cod_valor,[descripcion tributo],[codRegimen],[des_Regimen],[tama�oRG], [DesTama�oRG],[a�o] 
--into  [db_proc_procesos1].[n570].[Memo060_C]
from  [db_proc_procesos1].[n570].[Memo060_b]
order by 1, 2 desc

select [RUC_C],[VALOR_C],[descripcion tributo],[codRegimen],[des_Regimen],[tama�oRG], [DesTama�oRG], a�o
--into [db_proc_procesos1].[n570].[Memo060_D]    ---  (373345 row(s) affected)
from [db_proc_procesos1].[n570].[Memo060_C]
order by CAST(SUBSTRING([RUC_C] + '0', PATINDEX('%[0-9]%', [RUC_C] + '0'), LEN([RUC_C] + '0')) AS INT);

---- final 1
select * from [db_proc_procesos1].[n570].[Memo060_D]
--order by CAST(SUBSTRING([RUC_C] + '0', PATINDEX('%[0-9]%', [RUC_C] + '0'), LEN([RUC_C] + '0')) AS INT);
order by CAST(SUBSTRING([VALOR_C] + '0', PATINDEX('%[0-9]%', [VALOR_C] + '0'), LEN([VALOR_C] + '0')) AS INT);

select * from [db_proc_procesos1].[n570].[Memo060_D]
;

-- fin  2603
-- Parte 2









 ------------------- ruc con regimen: personas naturales con ingresos menores a 150 uit
Select num_ruc 
--into [db_proc_procesos1].[n570].[RUC_PersonasNaturales150UIT]
from db_data_wh.padron.TB_CONTRIBUYENTE where num_ruc in   --- SIN REGIMEN RENTA 3RA
('10011580144','10015595456','10017014876','10023751874','10026657879','10027777185','10028180310','10028544206','10032134535','10033233910','10033440974','10034874145',
'10034957881','10035711177','10035844789','10035962056','10036454020','10036509398','10036795625','10036945228','10038290709','10038311684','10038499373','10038536040',
'10038551588','10038884676','10038982333','10062817599','10077243181','10077353025','10081004931','10090138532','10091041567','10106902211','10157614385','10164167530',
'10166439561','10167130793','10167387140','10174049675','10178148881','10179212990','10191931543','10199500266','10251857844','10255404631','10255592781','10266087751',
'10273918685','10279741825','10282115595','10308564814','10329112832','10336683471','10401562996','10402086187','10403767030','10406166771','10410993258','10412671444',
'10413943103','10414537371','10415501949','10418168426','10419863705','10421731000','10422712343','10423965415','10424572565','10435124581','10435325233','10435756161',
'10436930955','10437663110','10438483930','10442756355','10442951549','10443671078','10445156481','10445178611','10447721321','10448208562','10451435651','10458588860',
'10460677641','10461788527','10463972066','10466238169','10466737319','10468506233','10470789471','10471317271','10474956186','10480864030','10481096788','10481798677',
'10485319552','10485971551','10700275782','10700496568','10703460289','10718519069','10732494753','10740852642','10755679360','10757308334','10764300055','10770453939',
'10800647920','10801359090','10802402495','10804191831','17000610003','17000611077');

Select num_ruc 
--into [db_proc_procesos1].[n570].[26RUC_RUS]
from db_data_wh.padron.TB_CONTRIBUYENTE where num_ruc in   --- SIN REGIMEN RENTA 3RA
('10011580144', '10015595456','10038290709','10091041567','10179212990',
'10191931543', '10251857844','10255404631','10282115595','10329112832', 
'10336683471', '10403767030','10410993258','10435124581','10442756355',
'10443671078','10445178611','10451435651','10461788527','10466238169', 
'10468506233', '10481096788','10481798677','10740852642','10764300055', 
'10800647920')
